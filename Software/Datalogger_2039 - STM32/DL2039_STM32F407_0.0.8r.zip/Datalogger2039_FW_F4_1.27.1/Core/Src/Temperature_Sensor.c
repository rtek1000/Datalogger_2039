/*
 * Temperature_Sensor.c
 *
 *  Created on: 3 de ago de 2023
 *      Author: user
 */

#include "Temperature_Sensor.h"

#include "TMP117.h"
#include "TCA9548A.h"
#include "DS18B20.h"

#define NumOfSensors maxChannel

uint8_t sensor_initialized[NumOfSensors] = { 0 };

extern DS18B20_TypeDef SENSORS[NumOfSensors];
extern const uint8_t TMP117_Addr; // 0x48 << 1
extern const uint8_t TCA9548A_Addr; // 0x70 << 1
extern I2C_HandleTypeDef *TCA9548A_I2C_upstream;

extern void beep(uint8_t repetions, uint8_t is_error, char *ref);

extern uint8_t TMP117_initialized[8];

extern int8_t sensor_type[maxChannel];

extern int16_t sensor_offset[maxChannel];

HAL_StatusTypeDef Temperature_Sensor_init(void) {
	uint8_t i = 0;
	IWDG_delay_ms(0);

	for (i = 0; i < maxChannel; i++) {
		if (SENSORS[i].FLAG_ENABLED == 1) {
			for (uint8_t r = 0; r < 5; r++) {
				if (Temperature_Sensor_TMP117_init(i) == HAL_OK) {
					break;
				} else {
					if (r == 4) {
						UsrLog("Error: Temperature_Sensor_TMP117_init (CH%d)",
								i);

						for (uint8_t x = 0; x < 7; x++) {
							SENSORS[i].SERIAL_ID[x] = 0x00;
						}

						SENSORS[i].FLAG_PRESENT = 0;

						SENSORS[i].FLAG_TIMEOUT = 1;

						SENSORS[i].FLAG_ID_ERROR = 1;

						SENSORS[i].TEMPERATURE = 0.0;

						SENSORS[i].TEMPERATURE_RAW = SENSORS[i].TEMPERATURE
								* 16.0;
					}
				}
			}
		}

		IWDG_delay_ms(0);
	}

	if (DS18B20_init() != HAL_OK) {
		UsrLog("Error: DS18B20_init");

		beep(0, 1, "Error: DS18B20_init");
	} else {
		return HAL_OK;
	}

	return HAL_ERROR;
}

HAL_StatusTypeDef Temperature_Sensor_start_conversion(void) {
	return DS18B20_readSensors(DS18B20_START_CONVERSION, SENSORS);
}

HAL_StatusTypeDef Temperature_Sensor_read_all(void) {
	uint8_t i = 0;

	UsrLog("Temperature_Sensor_read_all(void)");

	//UsrLog("Temperature_Sensor_read_all");

	for (i = 0; i < maxChannel; i++) {
		if (SENSORS[i].FLAG_ENABLED == 1) {
			if (sensor_type[i] == sensor_type_DS18B20) {
				DS18B20_readSensors_CH(i, DS18B20_READ, SENSORS);
			} else { // if (sensor_type[channel_0_7] == sensor_type_TMP117) {
				for (uint8_t r = 0; r < 5; r++) {
					if (Temperature_Sensor_TMP117_read(i) == HAL_OK) {
						break;
					}

					if (r == 4) {
						UsrLog("Error: Temperature_Sensor_read_all (CH%d)", i);

						for (uint8_t x = 0; x < 7; x++) {
							SENSORS[i].SERIAL_ID[x] = 0x00;
						}

						SENSORS[i].FLAG_PRESENT = 0;

						SENSORS[i].FLAG_TIMEOUT = 1;

						SENSORS[i].FLAG_ID_ERROR = 1;

						SENSORS[i].TEMPERATURE = 0.0;

						SENSORS[i].TEMPERATURE_RAW = SENSORS[i].TEMPERATURE
								* 16.0;
					}
				}
			}
		}

		IWDG_delay_ms(0);
	}

	uint8_t beep_error = 0;

	for (i = 0; i < maxChannel; i++) {
		if ((SENSORS[i].FLAG_ENABLED == 1) & (SENSORS[i].FLAG_TIMEOUT == 1)) // sensor error
				{
			beep_error = 1;
		}
	}

	if (beep_error == 1) { // sensor error
		//UsrLog("Beep");
		UsrLog("Error: DS18B20_readSensors");

		beep(0, 1, "Error: DS18B20_readSensors");

		return HAL_ERROR;
	}

	return HAL_OK;
}

HAL_StatusTypeDef Temperature_Sensor_read(void) {
	int i = 0;

	//UsrLog("Temperature_Sensor_read(void)");

	uint8_t error_status_ID = 0;
	uint8_t error_status_PRESENT = 0;

	for (i = 0; i < maxChannel; i++) {
		if (sensor_type[i] == sensor_type_DS18B20) {
			if (DS18B20_readSensors_CH(i, DS18B20_READ, SENSORS) != HAL_OK) {
				UsrLog("Error: DS18B20_READ");
			}

			if (DS18B20_readSensors_CH(i, DS18B20_START_CONVERSION, SENSORS)
					!= HAL_OK) {
				UsrLog("Error: DS18B20_START_CONVERSION");
			}
		} else { // if (sensor_type[channel_0_7] == sensor_type_TMP117) {
			for (uint8_t r = 0; r < 5; r++) {
				if (Temperature_Sensor_TMP117_read(i) == HAL_OK) {
					//UsrLog("Temperature_Sensor_TMP117_read(CH%d) (pass: %d)", i, r);
					break;
				}

				if (r == 4) {
					UsrLog("Error: Temperature_Sensor_read (CH%d)", i);

					for (uint8_t x = 0; x < 7; x++) {
						SENSORS[i].SERIAL_ID[x] = 0x00;
					}

					SENSORS[i].FLAG_PRESENT = 0;

					SENSORS[i].FLAG_TIMEOUT = 1;

					SENSORS[i].FLAG_ID_ERROR = 1;

					SENSORS[i].TEMPERATURE = 0.0;

					SENSORS[i].TEMPERATURE_RAW = SENSORS[i].TEMPERATURE * 16.0;
				}
			}
		}

		if (SENSORS[i].FLAG_TIMEOUT == 1) { // sensor error
			SENSORS[i].FLAG_TIMEOUT = 0;

			SENSORS[i].FLAG_ERROR = 1;

			if (SENSORS[i].FLAG_ID_ERROR == 1) {
				error_status_ID = 1;
			}

		} else if ((SENSORS[i].FLAG_ENABLED == 1)
				&& (SENSORS[i].FLAG_TIMEOUT == 0)) {
			SENSORS[i].FLAG_ERROR = 0;
		}

		if ((SENSORS[i].FLAG_ENABLED == 1) && (SENSORS[i].FLAG_PRESENT == 0)) {
			error_status_PRESENT = 1;
		}

		IWDG_delay_ms(0);
	}

	if ((error_status_PRESENT == 1) || (error_status_ID == 1)) {
		return HAL_ERROR;
	} else {
		return HAL_OK;
	}
}

HAL_StatusTypeDef Temperature_Sensor_TMP117_init(uint8_t channel_0_7) {
	uint8_t channel_1_8 = channel_0_7 + 1;

	if (channel_0_7 > 7) {
		UsrLog(
				"Error: Temperature_Sensor_TMP117_init (CH%d), invalid parameter: channel",
				channel_1_8);

		return HAL_ERROR;
	}

	if (HAL_I2C_IsDeviceReady(TCA9548A_I2C_upstream, TCA9548A_Addr, 2, 5)
			!= HAL_OK) {
		UsrLog("Error: Temperature_Sensor_TMP117_init, TCA9548A not found");

		return HAL_ERROR;
	} else {
		//UsrLog("TCA9548A found (select channel: %d)", channel);

		uint8_t pData[1] = { 1 << channel_0_7 };
		uint8_t pDataSize = 1;
		uint32_t Timeout = 10;

		if (HAL_I2C_Master_Transmit(TCA9548A_I2C_upstream, TCA9548A_Addr, pData,
				pDataSize, Timeout) != HAL_OK) {
			UsrLog("Error: TCA9548A Transmit not OK");

			return HAL_ERROR;
		} else {
			//UsrLog("TCA9548A Transmit OK");

			if (TMP117_initialized[channel_0_7] != 1) {
				if (TMP117_begin(TCA9548A_I2C_upstream, TMP117_Addr)
						!= HAL_OK) {
					UsrLog("Error: Temperature_Sensor_TMP117_init, TMP117 begin");

					return HAL_ERROR;
				} else {
					//UsrLog("TMP117 begin ok");

					TMP117_initialized[channel_0_7] = 1;

					SENSORS[channel_0_7].FLAG_PRESENT = 1;

					SENSORS[channel_0_7].FLAG_TIMEOUT = 0;

					SENSORS[channel_0_7].FLAG_ID_ERROR = 0;
				}
			}
		}
	}

	return HAL_OK;
}

HAL_StatusTypeDef Temperature_Sensor_TMP117_read(uint8_t channel_0_7) {
	uint8_t channel_1_8 = channel_0_7 + 1;

	if (channel_0_7 > 7) {
		UsrLog(
				"Error: Temperature_Sensor_TMP117_read (CH%d), invalid parameter: channel",
				channel_1_8);

		return HAL_ERROR;
	}

	if (sensor_type[channel_0_7] != sensor_type_TMP117) {
		//UsrLog("TMP117_read (CH%d) sensor_type != sensor_type_TMP117, skip",
//				channel_1_8);

		return HAL_OK;
	}

	if (SENSORS[channel_0_7].FLAG_ENABLED != 1) {
		//UsrLog("TMP117_read (CH%d) FLAG_ENABLED != 1, skip", channel_1_8);

		return HAL_OK;
	}

	if (HAL_I2C_IsDeviceReady(TCA9548A_I2C_upstream, TCA9548A_Addr, 2, 5)
			!= HAL_OK) {
		UsrLog("Error: TCA9548A not found (TMP117_read) (CH%d)", channel_0_7);

		return HAL_ERROR;
	} else {
		//UsrLog("TCA9548A found (select channel: %d)", channel);

		uint8_t pData[1] = { 1 << (channel_0_7) };
		uint8_t pDataSize = 1;
		uint32_t Timeout = 10;

		if (HAL_I2C_Master_Transmit(TCA9548A_I2C_upstream, TCA9548A_Addr, pData,
				pDataSize, Timeout) != HAL_OK) {
			UsrLog("Error: TCA9548A Transmit not OK (TMP117_read)");

			return HAL_ERROR;
		} else {
			//UsrLog("TCA9548A Transmit OK");

			float _TempC = 0;

			//for (uint8_t r = 0; r < 5; r++) {
			if (TMP117_initialized[channel_0_7] != 1) {
				if (TMP117_begin(TCA9548A_I2C_upstream, TMP117_Addr)
						!= HAL_OK) {
					UsrLog("Error: TMP117 begin (TMP117_read) (CH%d)",
							channel_0_7);

					return HAL_ERROR;
				} else {
					//UsrLog("TMP117 begin ok");

					TMP117_initialized[channel_0_7] = 1;
				}
			} else {
				if (TMP117_setShutdownMode(TMP117_Addr) != HAL_OK) {
					UsrLog("Error: TMP117_setShutdownMode");

					return HAL_ERROR;
				}

				//_TempC = TMP117_readTempC(TMP117_Addr);

				if (TMP117_readTempC(TMP117_Addr, &_TempC) != HAL_OK) {
					UsrLog("Error: TMP117_readTempC");
					return HAL_ERROR;
				}

				if (_TempC == TMP117_ERROR) {
					UsrLog("Error: TMP117_readTempC");

					TMP117_initialized[channel_0_7] = 0;

					return HAL_ERROR;
				} else {
					if (TMP117_readTempC(TMP117_Addr, &_TempC) != HAL_OK) {
						UsrLog("Error: TMP117_readTempC");

						return HAL_ERROR;
					} else {
						float Offset = sensor_offset[channel_0_7] / 10.0;

						SENSORS[channel_0_7].TEMPERATURE = _TempC + Offset;

						SENSORS[channel_0_7].TEMPERATURE_RAW =
								SENSORS[channel_0_7].TEMPERATURE * 16.0;

						uint16_t ID_buffer1[3] = { 0 };
						uint16_t ID_buffer2[3] = { 0 };

						if (TMP117_EEPROM_read_ID(TMP117_Addr, ID_buffer1)
								== HAL_OK) {
							//UsrLog("TMP117_EEPROM_read_ID OK");
							if (TMP117_EEPROM_read_ID(TMP117_Addr, ID_buffer2)
									== HAL_OK) {
								//UsrLog("TMP117_EEPROM_read_ID OK");

								if ((ID_buffer1[0] == ID_buffer2[0])
										&& (ID_buffer1[1] == ID_buffer2[1])
										&& (ID_buffer1[2] == ID_buffer2[2])) {
									SENSORS[channel_0_7].SERIAL_ID[0] = 0x00;

									for (uint8_t x = 0; x < 3; x++) {
										SENSORS[channel_0_7].SERIAL_ID[(x * 2)
												+ 1] = (ID_buffer1[x] >> 8)
												& 0xFF;
										SENSORS[channel_0_7].SERIAL_ID[(x * 2)
												+ 2] = ID_buffer1[x] & 0xFF;
									}

									SENSORS[channel_0_7].SERIAL_ID[7] = 0x17;

									SENSORS[channel_0_7].FLAG_PRESENT = 1;

									SENSORS[channel_0_7].FLAG_TIMEOUT = 0;

									SENSORS[channel_0_7].FLAG_ID_ERROR = 0;

									//return HAL_OK;
								} else {
									UsrLog("Error: ID_buffer1");

									return HAL_ERROR;
								}
							} else {
								UsrLog("Error: TMP117_EEPROM_read_ID");

								return HAL_ERROR;
							}
						} else {
							UsrLog("Error: TMP117_EEPROM_read_ID");

							return HAL_ERROR;
						}

						if (channel_1_8 == 8) {
							UsrLog(" ");
						}
					}
				}

				if (TMP117_setContinuousConversionMode(TMP117_Addr) != HAL_OK) {
					return HAL_ERROR;
				}
			}
		}
	}

	return HAL_OK;
}
