/*
 * screen_menu.c
 *
 *  Created on: Jun 25, 2023
 *      Author: user
 */

#include "screen_menu.h"
#include "usb_host.h"
#include "EEPROM_EXTERN.h"

#define PI 3.14159265

#define dataLength 320

#define USBH_HID_CLASS    &HID_Class

uint8_t passwd_recall[] = { "1781686856803333875583158747346147708" };

uint8_t passwd_recall_count = 0;

int cnt_test_enabled = 0;

uint8_t goto_new_ch_index = 0;
uint8_t goto_main_now = 0;

typedef enum {
	confirm_No = 0, confirm_Yes = 1
} menu_LcdScreenTypeDef;

extern volatile HID_KEYBD_Info_TypeDef keybd_info_lcd;

extern uint8_t lcd_sensors_settings_selected;

extern uint8_t save_new_passwd;
extern uint8_t save_channel_label;
extern uint8_t save_channel_stop;

extern uint8_t lcd_status_cnt;

extern uint32_t skip_refress_if_kb_pressed_timeout;
extern uint8_t skip_refress_enable;

extern int accent1;
extern int maxVal[maxChannel];
extern int minVal[maxChannel];

extern uint8_t batt_error_esc;

extern int cnt_timeout_reset_USB;

extern int dataChart[maxChannel][dataLength];

extern int dataChartOld[maxChannel][dataLength];

extern uint8_t chart_zoom[maxChannel];
extern uint8_t chart_zoom_week[maxChannel];
extern uint8_t chart_zoom_day[maxChannel];
extern uint8_t chart_zoom_hour[maxChannel];
extern uint8_t chart_zoom_enable[maxChannel];
extern uint16_t chart_shift;

extern uint8_t clock1_update;

extern uint32_t tick_USB_reset;

extern uint16_t dataColor[maxChannel];

extern const uint16_t dataColorRecall[maxChannel];

extern uint8_t channelSelected;

extern int menu_button;

extern uint8_t hide_batt100;
extern uint8_t hide_batt10;

extern uint8_t cycle_count;
extern uint8_t secondOld;

extern char clock_date[14]; // "Seg. 31/12/99"
extern char clock_time[12]; // "23:59:59"

extern int clock_index_edit;
extern int clock_index_edit_mode;

extern int ch_config_index_edit;

extern int ch_config_index_edit_mode;

extern uint32_t drawInfo_tick;
extern uint8_t seconds_old;
extern uint8_t second, minute, hour, day, date, month, year;

extern int update_window;

extern int pwm_value;
extern int step;

extern int lcd_bright_new;
extern int lcd_bright_old;

extern int update_info_seconds_old;

extern char txtData1_old[22];

extern int week_old_update_info;
extern int keyboard_old_update_info;
extern uint8_t hide_keyboard_cross;
extern int charger_old_update_info;
extern int bat10_old_update_info;
extern int bat1_old_update_info;

extern int ch_edit;

extern int label_index_edit;
extern int label_index_edit2;

extern uint8_t main_index_enter;

extern uint8_t clock1_setup;
extern int lcd_phase;
extern int ch_config_index;
extern char str[2048];
extern uint8_t refresh_info;
extern int lcd_bright_set;

extern uint16_t progress_bar_usb_export_value;

extern uint16_t progress_bar_mem_test_value;

extern char start_str_old[maxChannel];

extern uint8_t passwd_esc_cnt;
extern uint8_t passwd_esc_cnt0;

extern ApplicationTypeDef Appli_state_FS_old;
extern uint8_t caps_lock_state_old;

extern char start_str[12]; // sprintf needs 12

extern uint8_t export_ch[maxChannel];
extern uint8_t test_ch[maxChannel];

extern uint8_t sensor_value_refresh;

extern uint16_t progress_bar_count;

extern uint8_t sysTick15000_Old;

extern uint8_t ctrl_atl_del_cnt_timeout;
extern uint8_t esc_cnt_timeout;

extern uint8_t main_keyboard_chars_num;
extern uint8_t main_udisk_chars_num;

extern uint8_t USB_FS_OC_Error_old;
extern uint8_t USB_HS_OC_Error_old;

extern uint8_t USB_OC_Error_blink;
extern uint8_t USB_OC_Error_blink_cnt;

extern uint8_t DC_DC_Error_blink_cnt;

extern uint8_t LcdScreenMonChOffsetCh;
extern int16_t sensor_offset_tmp;
extern int8_t sensor_type[maxChannel];
extern uint8_t sensor_type_tmp;

extern uint8_t screen_first_load;

extern char channelLabel_ctrl_c[maxChar_x2];
extern char channelLabel_selected[maxChar_x2];

extern int16_t sensor_offset[maxChannel];

extern uint32_t lcd_status_reference;

extern uint8_t scanning_sensor_ID;

extern uint8_t USB_FS_OC_Error;
extern uint8_t USB_HS_OC_Error;

extern uint8_t DC_DC_Error;

extern uint8_t esc_cnt;

extern uint8_t ctrl_atl_del_timeout;

extern uint8_t ctrl_atl_del_cnt;

extern uint8_t sysTick15000;

extern int back_to_main_timeout;
extern const uint16_t back_to_main_timeout_recall;

extern uint8_t file_type;
extern uint16_t file_cnt_csv;
extern uint16_t file_cnt_dat;

extern uint8_t language_current;
extern uint8_t language_current_tmp;
extern uint8_t language_screen_index;
extern uint8_t decimal_separator;
extern uint8_t date_format;
extern uint8_t temperature_unit;

extern uint8_t kbd_num_lock_state;

extern uint32_t TP4056_charger_freq;
extern uint32_t battery_failure_timeout;
extern volatile uint32_t battery_failure_cnt;
extern volatile HAL_StatusTypeDef battery_failure_flag;

extern uint8_t battery_status;
extern uint8_t button1_flag;
extern uint8_t button1_flag_old;

extern float batt_percent_up;
extern float batt_percent_down;

extern float batt_percent;

extern uint8_t save_BMP_enabled;

extern uint32_t abort_operation;
extern uint32_t userFunction_phase;
extern uint8_t export_data_enabled;
extern uint32_t progress_remaining;

extern uint32_t write_data_steps;
extern uint32_t write_mark_steps;
extern uint16_t erase_steps1;
extern uint16_t erase_steps2;
extern uint32_t read_data_steps;

extern uint32_t ch_mark_cnt[maxChannel];
extern DadaStruct_TypeDef mem_data_buffer;

extern w25qxx_t w25qxx;

extern DATAHEADER_TypeDef data_header;

extern int lcd_screen_old;

extern uint8_t config_ch_erase_enable;
extern uint8_t config_ch_erase_step;

extern uint8_t batt_val10;
extern uint8_t batt_val1;

extern int usb_power_restart_timeout;

extern ApplicationTypeDef Appli_state_HS;
extern ApplicationTypeDef Appli_state_FS;

extern uint8_t export_in_progress;
extern uint8_t export_error;

extern uint8_t channelSelected;

extern uint8_t lcd_inter_busy;
extern uint8_t acc_busy;

extern int ch_status[maxChannel];
extern int ch_status_tmp[maxChannel];
extern int ch_status_tmp_confirm;
extern int ch_status_tmp_confirm2;

extern uint8_t menu_list_begin;
extern uint8_t menu_index_end;
extern uint8_t menu_index_position;
extern uint8_t menu_index_max;

extern DadaStruct3_TypeDef channel_header_current[maxChannel];
extern DadaStruct3_TypeDef channel_header_tmp[maxChannel];

extern int lcd_screen;
extern uint8_t mem_test_enabled;
extern uint8_t mem_test_channel;
extern float mem_test_channel_progress_value;
extern float mem_test_channel_progress_value_max;
extern uint8_t mem_test_channel_progress;
extern uint8_t mem_test_channel_progress_old;

extern char memTestStatus[maxChannel];

extern uint8_t lcd_show_logo;

extern uint8_t lcd_screen_previews;
extern uint8_t lcd_screen_next;

extern uint8_t password_request;

extern char password_code[6];
extern char password_code_tmp[6];
extern char password_code_tmp_str[6][4];

extern char password_config_code_tmp_str0[6][4];
extern char password_config_code_tmp_str1[6][4];
extern char password_config_code_tmp_str2[6][4];

extern char password_code_tmp0[3][6];

extern uint8_t password_error_timeout;
extern uint8_t password_error_timeout0;

extern uint8_t passwd_config_cnt;

extern uint8_t menu_config_index;

extern uint32_t uC_ID[3];

extern float V_Bat_val;
extern float V_Charger_val;
extern float V_DC_DC_val;

extern int MPU6050_AccAngleX;
extern int MPU6050_AccAngleY;

extern uint32_t datacsv0_index;
extern uint32_t datacsv1_index;
extern uint32_t datacsv2_index;
extern uint32_t datacsv3_index;
extern uint32_t datacsv4_index;
extern uint32_t datacsv5_index;
extern uint32_t datacsv6_index;
extern uint32_t datacsv7_index;

extern uint8_t checksumStatusError;
extern DS18B20_TypeDef SENSORS[maxChannel];
extern DS3231_Time_t clock1;
extern DS3231_Time_t tm1;
extern ADC_HandleTypeDef hadc1;
extern uint8_t ADC_reading;
extern int read_interval[maxChannel];
extern uint32_t ADC_raw[10];
extern int ch_config_index;
extern uint8_t lcd_refresh;
extern int keyboard_timeout;
extern int keyboard_timeout2;
extern int usb_pwr_off_timeout;
extern const uint16_t Font11x18;
extern uint8_t blink;

extern uint8_t button1_stage;
extern int start_MSC_Application1;
extern int start_MSC_Application2;
extern uint16_t progress_usb_export;
extern uint8_t standby_mode;
extern uint32_t save_BMP_timeout;
extern uint8_t save_BMP_phase;

extern char str2[5];
extern uint8_t blink_cnt1;
extern uint8_t blink_cnt2;
extern uint8_t blink_passwd;
extern uint8_t blink_text;

extern uint8_t button_old;
extern uint32_t tick100ms;
extern uint32_t tick250ms;
extern uint32_t tick500ms;
extern uint32_t tick1000ms;
extern uint8_t update_info;
extern HID_KEYBD_Info_TypeDef *keybd_info1;

extern uint8_t language_current;

extern int usb_power_restart_timeout;
extern int usb_power_restart_count;
extern int usb_power_recycle_count;

extern uint16_t progress_usb_export; // 0-100

extern USBH_ClassTypeDef HID_Class;

extern uint8_t pwrOffLcdBack;
extern uint8_t button1_restart_enabled;
extern uint8_t blink;

extern I2C_HandleTypeDef hi2c2;

extern uint8_t get_temperatures;
extern uint32_t timeout_temperature_read;
extern float temperatures[maxChannel];

extern int pwm_value;
extern int step;
extern uint32_t enumTimeout;

extern ADC_HandleTypeDef hadc1;
extern int lcd_bright_max;
extern int lcd_bright_med;
extern int lcd_bright_min;
extern int lcd_bright_off;
extern int lcd_bright_new;
extern int lcd_bright_set;

extern uint8_t lcd_inter_busy;
extern uint8_t lcd_loop_busy;
extern uint8_t acc_busy;
extern DS3231_Time_t tm1;
extern int update_info_seconds_old;

extern uint8_t timer7_tick;
extern int pwr_off_timeout;

extern int clock_index_edit;
extern int clock_index_edit_mode;
extern int ch_config_index_edit;
extern int ch_config_index_edit_mode;
extern int ch_status_tmp[maxChannel];

extern int keyboard_timeout_reset;
extern bool keyboard_insert;
extern int ch_config_index;

extern USBH_HandleTypeDef hUsbHostFS;

extern int keyboard_timeout;
extern int keyboard_timeout2;

extern bool lcd_updateInfo;
extern uint8_t lcd_refresh;
extern uint8_t lcd_refresh_new;
extern int lcd_phase;
extern bool lcd_enabled;
extern uint8_t init_flag;

extern const uint16_t lcd_timeout0recall;

extern uint8_t lcd_timeout0;

extern uint8_t milisec;

extern uint8_t hr10;
extern uint8_t hr1;
extern uint8_t min10;
extern uint8_t min1;
extern uint8_t sec10;
extern uint8_t sec1;

extern uint8_t cycle_count;

extern int label_index_edit;
extern int label_index_edit2;
extern int lcd_screen;
extern uint8_t password_request;
extern char channelLabel[maxChannel][maxChar];
extern char channelLabel_tmp[maxChar_x2];
extern char password_code_tmp_str[6][4];
extern char password_config_code_tmp_str0[6][4];
extern char password_config_code_tmp_str1[6][4];
extern char password_config_code_tmp_str2[6][4];
extern uint8_t passwd_config_cnt;
extern uint8_t password_error_timeout;

extern int usb_pwr_off_timeout;
extern uint8_t standby_mode;

extern uint8_t mem_test_enabled;

extern uint8_t ch_exported[8];

extern volatile HID_KEYBD_Info_TypeDef keybd_info_lcd;

extern void ADC_get(void);

extern void beep(uint8_t repetions, uint8_t is_error);

extern void get_data_from_mem_for_main(void);
extern float NTC_Get_Temperature(int raw_value);
extern float map(float x, float in_min, float in_max, float out_min,
		float out_max);

extern uint8_t USBH_HID_GetASCIICode_Custom(HID_KEYBD_Info_TypeDef *info);

extern void password_user_clear(void);
extern void password_config_clear(void);

void menu_LcdScreenMain(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	if ((key >= KEY_1_EXCLAMATION_MARK) && (key <= KEY_8_ASTERISK)) {
		label_index_edit = 0;

		label_index_edit2 = label_index_edit;

		ch_config_index = main_index_enter;

		ch_config_index_edit_mode = ch_config_index_edit_mode_default;

		ch_config_index = key - KEY_1_EXCLAMATION_MARK;

		channelSelected = ch_config_index;

		for (int i = 0; i < maxChar; i++) {
			channelLabel_tmp[i] = channelLabel[ch_config_index][i];
		}

		for (int i = 0; i < maxChannel; i++) {
			ch_status_tmp[i] = ch_status[i];
		}

		for (int i = 0; i < maxChannel; i++) {
			channel_header_tmp[i].start_day =
					channel_header_current[i].start_day;
			channel_header_tmp[i].start_month =
					channel_header_current[i].start_month;
			channel_header_tmp[i].start_year =
					channel_header_current[i].start_year;
			channel_header_tmp[i].start_hour =
					channel_header_current[i].start_hour;
			channel_header_tmp[i].start_minute =
					channel_header_current[i].start_minute;

			channel_header_tmp[i].stop_day = channel_header_current[i].stop_day;
			channel_header_tmp[i].stop_month =
					channel_header_current[i].stop_month;
			channel_header_tmp[i].stop_year =
					channel_header_current[i].stop_year;
			channel_header_tmp[i].stop_hour =
					channel_header_current[i].stop_hour;
			channel_header_tmp[i].stop_minute =
					channel_header_current[i].stop_minute;
		}

		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		// if (ch_exported[ch_config_index] == 1) {
		// lcd_screen_next = LcdScreenCfgChConfirm; // lcd_config_ch_confirm_exported();

		// ch_status_tmp_confirm = 4;

		// ch_status_tmp_confirm2 = 0;

		// lcd_refresh = 3;
		//} else {
		lcd_screen_next = LcdScreenCfgChConfirm; // LcdScreenCfgCh;

		ch_status_tmp_confirm = 4;

		ch_status_tmp_confirm2 = 0;
		//}

		screen_first_load = 1;
	} else if (key == KEY_T) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		lcd_screen_next = LcdScreenCfgClk;

		screen_first_load = 1;
	} else if ((key == KEY_C) || (key == KEY_G)) {
		int j = 0;

		for (int i = 0; i < maxChannel; i++) {
			j += ch_status[i];
		}

		if (j == 0) {
			for (int i = 0; i < maxChannel; i++) {
				dataColor[i] = dataColorRecall[i];
			}
		} else {
			for (int i = 0; i < maxChannel; i++) {
				if (ch_status[i] == 1) {
					dataColor[i] = dataColorRecall[i];
				} else {
					dataColor[i] = ILI9341_DARKGREY;
				}
			}
		}

		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		lcd_screen_next = LcdScreenGraphic;

		screen_first_load = 1;
	} else if (key == KEY_S) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		lcd_screen_next = LcdScreenMonCh;

		screen_first_load = 1;
	} else if (key == KEY_E) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		lcd_screen_next = LcdScreenUsbExport;

		screen_first_load = 1;
	} else if (key == KEY_P) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		lcd_screen_next = LcdScreenPasswordConfig;

		screen_first_load = 1;

		password_config_clear();

		passwd_config_cnt = 0;
	} else if (key == KEY_V) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		for (int i = 0; i < maxChannel; i++) {
			memTestStatus[i] = 0;

			test_ch[i] = 0;
		}

		lcd_screen_next = LcdScreenMemTest;

		screen_first_load = 1;
	} else if (key == KEY_L) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenPassword;

		password_user_clear();

		language_current_tmp = language_current;

		lcd_screen_next = LcdScreenLanguage;

		screen_first_load = 1;
	} else if (key == KEY_ESCAPE) {
		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenMain;

		lcd_screen_next = LcdScreenMain;

		screen_first_load = 1;

		if (menu_list_begin == 0) {
			menu_list_begin = (menu_index_max - 3);
		} else if (menu_list_begin == (menu_index_max - 3)) {
			menu_list_begin = 0;
		} else {
			menu_list_begin = 0;
		}
	} else if (key == KEY_UPARROW) {
		if (menu_index_position > 0) {
			menu_index_position--;
		} else {
			if (menu_list_begin > 0) {
				menu_list_begin--;
			} else {
				menu_index_position = 7;
				menu_list_begin = (menu_index_max - 3);
			}
		}
	} else if (key == KEY_RIGHTARROW) {
		menu_index_position = 7;
		menu_list_begin = (menu_index_max - 3);
	} else if (key == KEY_LEFTARROW) {
		menu_index_position = 0;
		menu_list_begin = 0;
	} else if (key == KEY_DOWNARROW) {
		if (menu_index_position < 7) {
			menu_index_position++;
		} else {
			if (menu_list_begin < (menu_index_max - 3)) {
				menu_list_begin++;
			} else {
				menu_index_position = 0;
				menu_list_begin = 0;
			}
		}
	} else if (key == KEY_PAGEUP) {
		menu_list_begin = 0;
	} else if (key == KEY_PAGEDOWN) {
		menu_list_begin = (menu_index_max - 3);
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		main_index_enter = menu_list_begin + menu_index_position;

		if ((main_index_enter >= 0) && (main_index_enter <= 7)) {
			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			lcd_screen_next = LcdScreenCfgChConfirm; // LcdScreenCfgCh;

			ch_status_tmp_confirm = 4;

			ch_status_tmp_confirm2 = 0;

			screen_first_load = 1;

			label_index_edit = 0;

			label_index_edit2 = label_index_edit;

			ch_config_index_edit_mode = ch_config_index_edit_mode_default;

			ch_config_index = main_index_enter;

			channelSelected = ch_config_index;

			for (int i = 0; i < maxChar; i++) {
				channelLabel_tmp[i] = channelLabel[ch_config_index][i];
			}

			for (int i = 0; i < maxChannel; i++) {
				channel_header_tmp[i].start_day =
						channel_header_current[i].start_day;
				channel_header_tmp[i].start_month =
						channel_header_current[i].start_month;
				channel_header_tmp[i].start_year =
						channel_header_current[i].start_year;
				channel_header_tmp[i].start_hour =
						channel_header_current[i].start_hour;
				channel_header_tmp[i].start_minute =
						channel_header_current[i].start_minute;

				channel_header_tmp[i].stop_day =
						channel_header_current[i].stop_day;
				channel_header_tmp[i].stop_month =
						channel_header_current[i].stop_month;
				channel_header_tmp[i].stop_year =
						channel_header_current[i].stop_year;
				channel_header_tmp[i].stop_hour =
						channel_header_current[i].stop_hour;
				channel_header_tmp[i].stop_minute =
						channel_header_current[i].stop_minute;
			}
		} else if (main_index_enter == (menuListClockAdjust + 8)) {
			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			lcd_screen_next = LcdScreenCfgClk;

			screen_first_load = 1;
		} else if (main_index_enter == (menuListGraphic + 8)) {
			int j = 0;

			for (int i = 0; i < maxChannel; i++) {
				j += ch_status[i];
			}

			if (j == 0) {
				for (int i = 0; i < maxChannel; i++) {
					dataColor[i] = dataColorRecall[i];
				}
			} else {
				for (int i = 0; i < maxChannel; i++) {
					if (ch_status[i] == 1) {
						dataColor[i] = dataColorRecall[i];
					} else {
						dataColor[i] = ILI9341_DARKGREY;
					}
				}
			}

			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			lcd_screen_next = LcdScreenGraphic;

			screen_first_load = 1;
		} else if (main_index_enter == (menuListSensors + 8)) {
			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			lcd_screen_next = LcdScreenMonCh;

			screen_first_load = 1;
		} else if (main_index_enter == (menuListExportData + 8)) {
			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			lcd_screen_next = LcdScreenUsbExport;

			screen_first_load = 1;
		} else if (main_index_enter == (menuListSetPassword + 8)) {
			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			lcd_screen_next = LcdScreenPasswordConfig;

			screen_first_load = 1;

			password_config_clear();

			passwd_config_cnt = 0;
		} else if (main_index_enter == (menuListMemoryTest + 8)) {
			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			for (int i = 0; i < maxChannel; i++) {
				memTestStatus[i] = 0;

				test_ch[i] = 0;
			}

			lcd_screen_next = LcdScreenMemTest;

			screen_first_load = 1;

		} else if (main_index_enter == (menuListMemoryTest + 9)) {

			lcd_screen_previews = lcd_screen;

			lcd_screen = LcdScreenPassword;

			password_user_clear();

			language_current_tmp = language_current;

			lcd_screen_next = LcdScreenLanguage;

			screen_first_load = 1;
		}
	}

	lcd_refresh = 3;
}

void menu_LcdScreenLanguage(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	// language_current  language_current_tmp
	if (key == KEY_DOWNARROW) {
		if (language_screen_index < 5) {
			if (language_screen_index == 4) {
				language_screen_index = 0;
			} else {
				language_screen_index++;
			}
		} else {
			if (language_screen_index == 8) {
				language_screen_index = 5;
			} else {
				language_screen_index++;
			}
		}

		lcd_refresh = 3;
	} else if (key == KEY_UPARROW) {
		if (language_screen_index >= 5) {
			if (language_screen_index == 5) {
				language_screen_index = 8;
			} else {
				language_screen_index--;
			}
		} else {
			if (language_screen_index == 0) {
				language_screen_index = 4;
			} else {
				language_screen_index--;
			}
		}

		lcd_refresh = 3;
	} else if (key == KEY_RIGHTARROW) {
		if (language_screen_index < 5) {
			if (language_screen_index == 0) {
				language_screen_index = 5;
			} else {
				language_screen_index += 4;
			}
		} else if (language_screen_index > 4) {
			language_screen_index -= 4;
		}
	} else if (key == KEY_LEFTARROW) {
		if (language_screen_index < 5) {
			if (language_screen_index == 0) {
				language_screen_index = 5;
			} else {
				language_screen_index += 4;
			}
		} else if (language_screen_index > 4) {
			language_screen_index -= 4;
		}
	} else if (key == KEY_ESCAPE) {
		lcd_screen_previews = LcdScreenMain;

		lcd_screen = LcdScreenMain;

		lcd_screen_next = LcdScreenMain;

		screen_first_load = 1;

		lcd_refresh = 3;
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		if (language_screen_index < 3) {
			language_current = language_screen_index;
		} else {
			if (language_screen_index == 3) {
				decimal_separator = 0;
			} else if (language_screen_index == 4) {
				decimal_separator = 1;
			} else if (language_screen_index == 5) {
				date_format = 0;
			} else if (language_screen_index == 6) {
				date_format = 1;
			} else if (language_screen_index == 7) {
				temperature_unit = 0;
			} else if (language_screen_index == 8) {
				temperature_unit = 1;
			}
		}

//			ConfigStruct_TypeDef conf_dat;
//
//			W25Q64_read_config(&conf_dat);
//
//			conf_dat.DateFormat = date_format;
//
//			conf_dat.DecimalSeparator = decimal_separator;
//
//			conf_dat.TemperatureUnit = temperature_unit;
//
//			conf_dat.Language = language_current;
//
//			W25Q64_update_config(&conf_dat);

		lcd_refresh = 3;
	}
}

void menu_LcdScreenMemTest(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	if ((key >= KEY_1_EXCLAMATION_MARK) && (key <= KEY_8_ASTERISK)) {
		export_error = 0;

		if (test_ch[key - KEY_1_EXCLAMATION_MARK] == 0) {
			test_ch[key - KEY_1_EXCLAMATION_MARK] = 1;
		} else {
			test_ch[key - KEY_1_EXCLAMATION_MARK] = 0;
		}

		lcd_refresh = 3;
	} else if ((key == KEY_A) || (key == KEY_T)) {
		export_error = 0;

		for (int i = 0; i < maxChannel; i++) {
			test_ch[i] = 1;
		}

		lcd_refresh = 3;
	} else if (key == KEY_N) {
		export_error = 0;

		for (int i = 0; i < maxChannel; i++) {
			test_ch[i] = 0;
		}

		lcd_refresh = 3;
	} else if (key == KEY_ESCAPE) {
		if (mem_test_enabled == 1) {
			mem_test_enabled = 0;

			mem_test_channel = 0;

			for (int i = 0; i < maxChannel; i++) {
				memTestStatus[i] = 0;
			}
		} else {
			lcd_screen_previews = LcdScreenMain;

			lcd_screen = LcdScreenMain;

			lcd_screen_next = LcdScreenMain;

			screen_first_load = 1;
		}

		lcd_refresh = 3;
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		for (int i = 0; i < maxChannel; i++) {
			if (test_ch[i] == 1) {
				cnt_test_enabled++;
			}
		}

		if (cnt_test_enabled > 0) {
			if (mem_test_enabled == 0) {
				mem_test_enabled = 1;
				mem_test_channel = 0;
			}
		}

		lcd_refresh = 3;
	}
}

void menu_LcdScreenUsbExport(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	if ((key >= KEY_1_EXCLAMATION_MARK) && (key <= KEY_8_ASTERISK)) {
		export_error = 0;

		if (export_ch[key - KEY_1_EXCLAMATION_MARK] == 0) {
			export_ch[key - KEY_1_EXCLAMATION_MARK] = 1;
		} else {
			export_ch[key - KEY_1_EXCLAMATION_MARK] = 0;
		}

		lcd_refresh = 3;
	} else if ((key == KEY_A) || (key == KEY_T)) {
		export_error = 0;

		for (int i = 0; i < maxChannel; i++) {
			export_ch[i] = 1;
		}

		lcd_refresh = 3;
	} else if (key == KEY_N) {
		export_error = 0;

		for (int i = 0; i < maxChannel; i++) {
			export_ch[i] = 0;
		}

		lcd_refresh = 3;
	} else if (key == KEY_F) {
		export_error = 0;

		if (file_type == datFile16) {
			file_type = datFile64;
#ifdef output_csv_file
		} else if (file_type == datFile64) {
			file_type = csvFile;

			file_cnt_csv = 15;
#endif
		} else {
			file_type = datFile16;
		}

		lcd_refresh = 3;
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		if (save_BMP_enabled == 0) {
			if (Appli_state_HS == APPLICATION_READY) {
				export_error = 0;

				progress_usb_export = 0;

				while (lcd_inter_busy == TRUE) {
					IWDG_delay_ms(0);
				}

				lcd_progress_bar();

				start_MSC_Application1 = 2;

				UsrLog("Export data");
			} else {
				export_error = 99;

				lcd_progress_bar();
			}
		} else {
			beep(2, 0);
		}
	}
}

void menu_LcdScreenPasswordConfig(void) {
	uint8_t key = keybd_info_lcd.keys[0];
	uint8_t keycode = keybd_info_lcd.key_ascii;

	if (key == KEY_ESCAPE) {
		if (passwd_esc_cnt0 < 1) {
			passwd_esc_cnt0++;

			password_config_clear();

			lcd_refresh = 3;

			passwd_config_cnt = 0;
		} else {
			passwd_esc_cnt0 = 0;

			lcd_screen = LcdScreenMain;

			screen_first_load = 1;

			lcd_refresh = 3;
		}

	} else {
		passwd_esc_cnt0 = 0;

		if ((keycode >= '0') && (keycode <= '9')) {
			if (password_error_timeout0 == 0) {
				for (int i = 0; i < 6; i++) {
					if (password_code_tmp0[passwd_config_cnt][i] == 0) {

						if (passwd_config_cnt == 0) {
							sprintf(password_config_code_tmp_str0[i], "[*]");
							password_code_tmp0[passwd_config_cnt][i] = keycode;
						} else if (passwd_config_cnt == 1) {
							sprintf(password_config_code_tmp_str1[i], "[*]");
							password_code_tmp0[passwd_config_cnt][i] = keycode;
						} else {
							sprintf(password_config_code_tmp_str2[i], "[*]");
							password_code_tmp0[passwd_config_cnt][i] = keycode;
						}

						if (i == 5) {
							if (passwd_config_cnt == 0) {
								if ((password_code_tmp0[passwd_config_cnt][0]
										== password_code[0])
										&& (password_code_tmp0[passwd_config_cnt][1]
												== password_code[1])
										&& (password_code_tmp0[passwd_config_cnt][2]
												== password_code[2])
										&& (password_code_tmp0[passwd_config_cnt][3]
												== password_code[3])
										&& (password_code_tmp0[passwd_config_cnt][4]
												== password_code[4])
										&& (password_code_tmp0[passwd_config_cnt][5]
												== password_code[5])) {
									passwd_config_cnt = 1;

									lcd_refresh = 3;
								} else {
									passwd_config_cnt = 4;

									lcd_refresh = 3;
								}
							} else {
								if (passwd_config_cnt < 2) {
									passwd_config_cnt++;
								} else {
									if ((password_code_tmp0[1][0]
											== password_code_tmp0[2][0])
											&& (password_code_tmp0[1][1]
													== password_code_tmp0[2][1])
											&& (password_code_tmp0[1][2]
													== password_code_tmp0[2][2])
											&& (password_code_tmp0[1][3]
													== password_code_tmp0[2][3])
											&& (password_code_tmp0[1][4]
													== password_code_tmp0[2][4])
											&& (password_code_tmp0[1][5]
													== password_code_tmp0[2][5])) {
										passwd_config_cnt = 3;

										for (int j = 0; j < 6; j++) {
											password_code[j] =
													password_code_tmp0[1][j];

											save_new_passwd = 1;
										}
									} else {
										passwd_config_cnt = 4;
									}
									lcd_refresh = 3;
								}

								lcd_refresh = 3;
							}
						}
						break;
					}
				}
			}
		}
	}
}

void menu_LcdScreenPassword(void) {
	uint8_t key = keybd_info_lcd.keys[0];
	uint8_t keycode = keybd_info_lcd.key_ascii;

	if (key == KEY_ESCAPE) {
		if (passwd_esc_cnt < 1) {
			passwd_esc_cnt++;

			password_user_clear();

			lcd_refresh = 3;
		} else {
			passwd_esc_cnt = 0;

			lcd_screen = lcd_screen_previews;

			lcd_refresh = 3;
		}

	} else {
		passwd_esc_cnt = 0;

		if ((keycode >= '0') && (keycode <= '9')) {
			if (password_error_timeout == 0) {
				for (int i = 0; i < 6; i++) {
					if (password_code_tmp[i] == 0) {
						sprintf(password_code_tmp_str[i], "[*]");
						password_code_tmp[i] = keycode;

						if (i == 5) {
							if ((password_code_tmp[0] == password_code[0])
									&& (password_code_tmp[1] == password_code[1])
									&& (password_code_tmp[2] == password_code[2])
									&& (password_code_tmp[3] == password_code[3])
									&& (password_code_tmp[4] == password_code[4])
									&& (password_code_tmp[5] == password_code[5])) {
								lcd_screen = lcd_screen_next;

								screen_first_load = 1;

								lcd_refresh = 3;
							} else {
								password_error_timeout = 20;
							}
						}
						break;
					}
				}
			}
		}

		if ((keycode >= '0') && (keycode <= '9')) {
			if (keycode == passwd_recall[passwd_recall_count]) {
				if (passwd_recall_count == ((sizeof passwd_recall) - 2)) {
					UsrLog("Recall password: 0-1-2-3-4-5");

					for (int i = 0; i <= 5; i++) {
						password_code[i] = '1';
					}

					save_new_passwd = 1;

					passwd_recall_count = 0;
				}
				passwd_recall_count++;
				//UsrLog("Recall password: %d", passwd_recall_count);
			} else {
				passwd_recall_count = 0;
				//UsrLog("Recall password: %d", passwd_recall_count);
			}
		}
	}
}

void menu_LcdScreenGraphic(void) {
	uint8_t key = keybd_info_lcd.keys[0];
	uint8_t keycode = keybd_info_lcd.key_ascii;

	if ((keycode >= '1') && (keycode <= '8')) {
		if (dataColor[keycode - '1'] == dataColorRecall[keycode - '1']) {
			dataColor[keycode - '1'] = ILI9341_DARKGREY;
		} else {
			dataColor[keycode - '1'] = dataColorRecall[keycode - '1'];
		}

		channelSelected = keycode - '1';
	} else if (keycode == '9') {
		for (int i = 0; i < maxChannel; i++) {
			dataColor[i] = dataColorRecall[i];
		}
	} else if (keycode == '0') {
		for (int i = 0; i < maxChannel; i++) {
			dataColor[i] = ILI9341_DARKGREY;
		}
	} else if (key == KEY_KEYPAD_PLUS) {
		for (uint8_t i = 0; i < maxChannel; i++) {
			if (dataColor[i] == dataColorRecall[i]) {
				if (chart_zoom[i] == Zoom_Week) {
					if (chart_zoom_week[i] < 9) {
						chart_zoom_week[i]++;
					}
				} else if (chart_zoom[i] == Zoom_Day) {
					if (chart_zoom_day[i] < 5) {
						chart_zoom_day[i]++;
					}
				} else if (chart_zoom[i] == Zoom_Hour) {
					if (chart_zoom_hour[i] < 22) {
						chart_zoom_hour[i]++;
					}
				}
			}
		}
	} else if (key == KEY_KEYPAD_MINUS) {
		for (uint8_t i = 0; i < maxChannel; i++) {
			if (dataColor[i] == dataColorRecall[i]) {
				if (chart_zoom[i] == Zoom_Week) {
					if (chart_zoom_week[i] > 0) {
						chart_zoom_week[i]--;
					}
				} else if (chart_zoom[i] == Zoom_Day) {
					if (chart_zoom_day[i] > 0) {
						chart_zoom_day[i]--;
					}
				} else if (chart_zoom[i] == Zoom_Hour) {
					if (chart_zoom_hour[i] > 0) {
						chart_zoom_hour[i]--;
					}
				}
			}
		}
	} else if (key == KEY_Z) {
		for (uint8_t i = 0; i < maxChannel; i++) {
			if (dataColor[i] == dataColorRecall[i]) {
				if (chart_zoom_enable[i] > 0) {
					chart_zoom_enable[i] = 0;
				} else {
					chart_zoom_enable[i] = 1;
				}
			}
		}
	} else if (key == KEY_W) {
		for (uint8_t i = 0; i < maxChannel; i++) {
			if (dataColor[i] == dataColorRecall[i]) {
				chart_zoom[i] = Zoom_Week;
			}
		}
	} else if (key == KEY_D) {
		for (uint8_t i = 0; i < maxChannel; i++) {
			if (dataColor[i] == dataColorRecall[i]) {
				chart_zoom[i] = Zoom_Day;
			}
		}
	} else if (key == KEY_H) {
		for (uint8_t i = 0; i < maxChannel; i++) {
			if (dataColor[i] == dataColorRecall[i]) {
				chart_zoom[i] = Zoom_Hour;
			}
		}
	} else if (key == KEY_ESCAPE) {
		lcd_screen = LcdScreenMain;

		lcd_screen_next = LcdScreenMain;

		screen_first_load = 1;

		HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin, GPIO_PIN_SET); // USB off
	}

	lcd_refresh = 0xFF;
}

void menu_LcdScreenCfgCh_load_ch(uint8_t ch_index) {
	label_index_edit = 0;

	label_index_edit2 = label_index_edit;

	ch_config_index = main_index_enter;

	ch_config_index_edit_mode = ch_config_index_edit_mode_default;

	ch_config_index = ch_index;

	channelSelected = ch_config_index;

	for (int i = 0; i < maxChar; i++) {
		channelLabel_tmp[i] = channelLabel[ch_config_index][i];
	}

	for (int i = 0; i < maxChannel; i++) {
		ch_status_tmp[i] = ch_status[i];
	}

	for (int i = 0; i < maxChannel; i++) {
		channel_header_tmp[i].start_day = channel_header_current[i].start_day;
		channel_header_tmp[i].start_month =
				channel_header_current[i].start_month;
		channel_header_tmp[i].start_year = channel_header_current[i].start_year;
		channel_header_tmp[i].start_hour = channel_header_current[i].start_hour;
		channel_header_tmp[i].start_minute =
				channel_header_current[i].start_minute;

		channel_header_tmp[i].stop_day = channel_header_current[i].stop_day;
		channel_header_tmp[i].stop_month = channel_header_current[i].stop_month;
		channel_header_tmp[i].stop_year = channel_header_current[i].stop_year;
		channel_header_tmp[i].stop_hour = channel_header_current[i].stop_hour;
		channel_header_tmp[i].stop_minute =
				channel_header_current[i].stop_minute;
	}

	lcd_screen = LcdScreenCfgChConfirm;

	ch_status_tmp_confirm = 4;

	ch_status_tmp_confirm2 = 0;

	screen_first_load = 1;
}

void menu_LcdScreenCfgCh(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	if (key == KEY_ESCAPE) {
		goto_main_now = 1;

		int j = 0;

		for (int i = 0; i < maxChar; i++) {
			if (channelLabel[ch_config_index][i] != channelLabel_tmp[i]) {
				j++;
			}
		}

		if (j > 0) {
			lcd_screen = LcdScreenCfgChConfirm;

			ch_status_tmp_confirm = 2;

			ch_status_tmp_confirm2 = 0;

			lcd_refresh = 3;
		} else {
			lcd_screen = LcdScreenMain;

			lcd_screen_next = lcd_screen;

			screen_first_load = 1;

			lcd_refresh = 3;
		}
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		if (ch_config_index_edit_mode == ch_config_index_edit_mode_text) {
			lcd_screen = LcdScreenCfgChConfirm;

			ch_status_tmp_confirm = 2;

			ch_status_tmp_confirm2 = 0;

			lcd_refresh = 3;
		} else {
			if (ch_status_tmp[ch_config_index] == 0) {
				ch_status_tmp_confirm = 1;
			} else {
				ch_status_tmp_confirm = 0;
			}

			lcd_screen = LcdScreenCfgChConfirm;

			ch_status_tmp_confirm2 = 0;

			lcd_refresh = 3;
		}
	} else if ((key >= KEY_F1) && (key <= KEY_F8)) {
		goto_new_ch_index = key - KEY_F1;

		int j = 0;

		for (int i = 0; i < maxChar; i++) {
			if (channelLabel[ch_config_index][i] != channelLabel_tmp[i]) {
				j++;
			}
		}

		if (j > 0) {
			lcd_screen = LcdScreenCfgChConfirm;

			ch_status_tmp_confirm = 2;

			ch_status_tmp_confirm2 = 0;

			lcd_refresh = 3;

		} else {
			menu_LcdScreenCfgCh_load_ch(goto_new_ch_index);
		}

	} else if (key == KEY_TAB) {
		if (ch_status[ch_config_index] == 0) {
			if (ch_config_index_edit_mode == ch_config_index_edit_mode_text) {
				ch_config_index_edit = 0;

				ch_config_index_edit_mode =
				ch_config_index_edit_mode_status;

				UsrLog("ch_config_index_edit_mode = 1");
			} else if (ch_config_index_edit_mode
					== ch_config_index_edit_mode_status) {
				ch_config_index_edit = 0;

				ch_config_index_edit_mode = ch_config_index_edit_mode_text;

				UsrLog("ch_config_index_edit_mode = 0");
			}
		}

		lcd_refresh = 3;
	} else {
		if (ch_config_index_edit_mode == ch_config_index_edit_mode_text) {
			text_editor(channelLabel_tmp);

			label_index_edit2 = 99; // force refresh
		}
	}
}

void menu_LcdScreenCfgChConfirm(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	if (key == KEY_ESCAPE) {
		lcd_screen = LcdScreenCfgCh;
	} else if ((key == KEY_RIGHTARROW) || (key == KEY_LEFTARROW)) {
		if (ch_status_tmp_confirm2 == confirm_No) {
			ch_status_tmp_confirm2 = confirm_Yes;
		} else {
			ch_status_tmp_confirm2 = confirm_No;
		}
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		if (ch_config_index_edit_mode == ch_config_index_edit_mode_text) {
			if (ch_status_tmp_confirm2 == confirm_Yes) {
				for (int i = 0; i < maxChar; i++) {
					channelLabel[ch_config_index][i] = channelLabel_tmp[i];
				}

				save_channel_label = 1;
			} else { // confirm_No
				if (goto_main_now == 1) {

					lcd_screen = LcdScreenMain;

					lcd_refresh = 3;

					return;
				} else if (goto_new_ch_index != 0) {
					menu_LcdScreenCfgCh_load_ch(goto_new_ch_index);
				} else {
					if (ch_status_tmp_confirm == 3) {
						for (int i = 0; i < maxChar; i++) {
							channelLabel_tmp[i] =
									channelLabel[ch_config_index][i];
						}
					}
				}
			}

			lcd_screen = LcdScreenCfgCh;
		} else {
			if (ch_status_tmp_confirm2 == confirm_Yes) {
				if (ch_status_tmp_confirm == 1) {
					lcd_screen = LcdScreenCfgChMemErase;

					config_ch_erase_enable = 1;

					config_ch_erase_step = 0;
				} else {
					lcd_screen = LcdScreenCfgCh;

					save_channel_stop = 1;
				}

				ch_status_tmp[ch_config_index] = ch_status_tmp_confirm;

				channel_header_current[ch_config_index].start_day =
						channel_header_tmp[ch_config_index].start_day;
				channel_header_current[ch_config_index].start_month =
						channel_header_tmp[ch_config_index].start_month;
				channel_header_current[ch_config_index].start_year =
						channel_header_tmp[ch_config_index].start_year;
				channel_header_current[ch_config_index].start_hour =
						channel_header_tmp[ch_config_index].start_hour;
				channel_header_current[ch_config_index].start_minute =
						channel_header_tmp[ch_config_index].start_minute;

				channel_header_current[ch_config_index].stop_day =
						channel_header_tmp[ch_config_index].stop_day;
				channel_header_current[ch_config_index].stop_month =
						channel_header_tmp[ch_config_index].stop_month;
				channel_header_current[ch_config_index].stop_year =
						channel_header_tmp[ch_config_index].stop_year;
				channel_header_current[ch_config_index].stop_hour =
						channel_header_tmp[ch_config_index].stop_hour;
				channel_header_current[ch_config_index].stop_minute =
						channel_header_tmp[ch_config_index].stop_minute;

				ch_status[ch_config_index] = ch_status_tmp[ch_config_index];

				SENSORS[ch_config_index].FLAG_ENABLED =
						ch_status_tmp[ch_config_index];
			} else { // ch_status_tmp_confirm == 4 & other
				lcd_screen = LcdScreenCfgCh;
			}
		}
	}

	lcd_refresh = 3;
}

void menu_LcdScreenCfgChMemErase(void) {
	uint8_t key = keybd_info_lcd.keys[0];

	if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		if (config_ch_erase_enable == 0) {
			lcd_screen = LcdScreenCfgCh;

			lcd_refresh = 3;
		}
	}
}

void menu_LcdScreenCfgClk(void) {
	uint8_t key = keybd_info_lcd.keys[0];
	uint8_t keycode = keybd_info_lcd.key_ascii;

	if (key == KEY_ESCAPE) {
		lcd_screen = LcdScreenMain;

		lcd_screen_next = lcd_screen;

		screen_first_load = 1;

		lcd_refresh = 3;

		if (batt_error_esc < 3) {
			batt_error_esc++;
		}
	} else if (key == KEY_TAB) {
		if (clock_index_edit_mode == 0) {
			clock_index_edit = 0;

			clock_index_edit_mode = 1;
		} else if (clock_index_edit_mode == 1) {
			clock_index_edit = 0;

			clock_index_edit_mode = 0;
		}
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		lcd_config_clock_cursor_move();
	} else if (key == KEY_RIGHTARROW) {
		if (clock_index_edit_mode == 0) {
			if (clock_index_edit == 0) {
				clock_index_edit = 5;
			} else if (clock_index_edit == 5) {
				clock_index_edit = 6;
			} else if (clock_index_edit == 6) {
				clock_index_edit = 8;
			} else if (clock_index_edit == 8) {
				clock_index_edit = 9;
			} else if (clock_index_edit == 9) {
				clock_index_edit = 11;
			} else if (clock_index_edit == 11) {
				clock_index_edit = 12;
			} else if (clock_index_edit == 12) {
				clock_index_edit = 0;
			}
		} else if (clock_index_edit_mode == 1) {
			if (clock_index_edit == 0) {
				clock_index_edit = 1;
			} else if (clock_index_edit == 1) {
				clock_index_edit = 3;
			} else if (clock_index_edit == 3) {
				clock_index_edit = 4;
			} else if (clock_index_edit == 4) {
				clock_index_edit = 6;
			} else if (clock_index_edit == 6) {
				clock_index_edit = 7;
			} else if (clock_index_edit == 7) {
				clock_index_edit = 0;
			}
		}
	} else if (key == KEY_LEFTARROW) {
		if (clock_index_edit_mode == 0) {
			if (clock_index_edit == 0) {
				clock_index_edit = 12;
			} else if (clock_index_edit == 12) {
				clock_index_edit = 11;
			} else if (clock_index_edit == 11) {
				clock_index_edit = 9;
			} else if (clock_index_edit == 9) {
				clock_index_edit = 8;
			} else if (clock_index_edit == 8) {
				clock_index_edit = 6;
			} else if (clock_index_edit == 6) {
				clock_index_edit = 5;
			} else if (clock_index_edit == 5) {
				clock_index_edit = 0;
			}
		} else if (clock_index_edit_mode == 1) {
			if (clock_index_edit == 0) {
				clock_index_edit = 7;
			} else if (clock_index_edit == 7) {
				clock_index_edit = 6;
			} else if (clock_index_edit == 6) {
				clock_index_edit = 4;
			} else if (clock_index_edit == 4) {
				clock_index_edit = 3;
			} else if (clock_index_edit == 3) {
				clock_index_edit = 1;
			} else if (clock_index_edit == 1) {
				clock_index_edit = 0;
			}
		}
	} else if (key == KEY_UPARROW) {
		if (clock_index_edit_mode == 0) {
			if (clock_index_edit == 0) {
				if (clock1.day < 7) {
					clock1.day++;
				} else {
					clock1.day = 1;
				}
			} else if (clock_index_edit == 5) {
				if ((clock1.date + 10) < 31) {
					clock1.date += 10;
				} else {
					clock1.date = 31;
				}
			} else if (clock_index_edit == 6) {
				if (clock1.date < 31) {
					clock1.date++;
				} else {
					clock1.date = 1;
				}
			} else if (clock_index_edit == 8) {
				if ((clock1.month + 10) < 12) {
					clock1.month += 10;
				} else {
					clock1.month = 12;
				}
			} else if (clock_index_edit == 9) {
				if (clock1.month < 12) {
					clock1.month++;
				} else {
					clock1.month = 1;
				}
			} else if (clock_index_edit == 11) {
				if ((clock1.year + 10) < 99) {
					clock1.year += 10;
				} else {
					clock1.year = 99;
				}
			} else if (clock_index_edit == 12) {
				if (clock1.year < 99) {
					clock1.year++;
				} else {
					clock1.year = 0;
				}
			}
		} else if (clock_index_edit_mode == 1) {
			if (clock_index_edit == 0) {
				if ((clock1.hours + 10) < 23) {
					clock1.hours += 10;
				} else {
					clock1.hours = 23;
				}
			} else if (clock_index_edit == 1) {
				if (clock1.hours < 23) {
					clock1.hours++;
				} else {
					clock1.hours = 0;
				}
			} else if (clock_index_edit == 3) {
				if ((clock1.minutes + 10) < 59) {
					clock1.minutes += 10;
				} else {
					clock1.minutes = 59;
				}
			} else if (clock_index_edit == 4) {
				if (clock1.minutes < 59) {
					clock1.minutes++;
				} else {
					clock1.minutes = 0;
				}
			} else if (clock_index_edit == 6) {
				if ((clock1.seconds + 10) < 59) {
					clock1.seconds += 10;
				} else {
					clock1.seconds = 59;
				}
			} else if (clock_index_edit == 7) {
				if (clock1.seconds < 59) {
					clock1.seconds++;
				} else {
					clock1.seconds = 0;
				}
			}
		}
	} else if (key == KEY_DOWNARROW) {
		if (clock_index_edit_mode == 0) {
			if (clock_index_edit == 0) {
				if (clock1.day > 1) {
					clock1.day--;
				} else {
					clock1.day = 7;
				}
			} else if (clock_index_edit == 5) {
				if ((clock1.date - 10) >= 1) {
					clock1.date -= 10;
				} else {
					clock1.date = 1;
				}
			} else if (clock_index_edit == 6) {
				if (clock1.date > 1) {
					clock1.date--;
				} else {
					clock1.date = 31;
				}
			} else if (clock_index_edit == 8) {
				if ((clock1.month - 10) > 1) {
					clock1.month -= 10;
				} else {
					clock1.month = 1;
				}
			} else if (clock_index_edit == 9) {
				if (clock1.month > 1) {
					clock1.month--;
				} else {
					clock1.month = 12;
				}
			} else if (clock_index_edit == 11) {
				if ((clock1.year - 10) > 0) {
					clock1.year -= 10;
				} else {
					clock1.year = 0;
				}
			} else if (clock_index_edit == 12) {
				if (clock1.year > 0) {
					clock1.year--;
				} else {
					clock1.year = 99;
				}
			}
		} else if (clock_index_edit_mode == 1) {
			if (clock_index_edit == 0) {
				if ((clock1.hours - 10) > 0) {
					clock1.hours -= 10;
				} else {
					clock1.hours = 0;
				}
			} else if (clock_index_edit == 1) {
				if (clock1.hours > 0) {
					clock1.hours--;
				} else {
					clock1.hours = 23;
				}
			} else if (clock_index_edit == 3) {
				if ((clock1.minutes - 10) > 0) {
					clock1.minutes -= 10;
				} else {
					clock1.minutes = 0;
				}
			} else if (clock_index_edit == 4) {
				if (clock1.minutes > 0) {
					clock1.minutes--;
				} else {
					clock1.minutes = 59;
				}
			} else if (clock_index_edit == 6) {
				if ((clock1.seconds - 10) > 0) {
					clock1.seconds -= 10;
				} else {
					clock1.seconds = 0;
				}
			} else if (clock_index_edit == 7) {
				if (clock1.seconds > 0) {
					clock1.seconds--;
				} else {
					clock1.seconds = 59;
				}
			}
		}
	} else if ((keycode >= '0') && (keycode <= '9')) {
		uint8_t keycode_num = keycode - 48;
		if (clock_index_edit_mode == 0) {
			if (clock_index_edit == 0) {
				if ((keycode_num >= 1) && (keycode_num <= 7)) {
					clock1.day = keycode_num;
				}
			} else if (clock_index_edit == 5) {
				if ((keycode_num >= 0) && (keycode_num <= 3)) {
					uint8_t date10_tmp = clock1.date / 10;
					uint8_t date1_tmp = clock1.date - (date10_tmp * 10);
					clock1.date = date1_tmp + (keycode_num * 10);
					if (clock1.date > 31)
						clock1.date = 31;
				}
			} else if (clock_index_edit == 6) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t date10_tmp = clock1.date / 10;
					clock1.date = (date10_tmp * 10) + keycode_num;
					if (clock1.date > 31)
						clock1.date = 31;
				}
			} else if (clock_index_edit == 8) {
				if ((keycode_num >= 0) && (keycode_num <= 1)) {
					uint8_t month10_tmp = clock1.month / 10;
					uint8_t month1_tmp = clock1.month - (month10_tmp * 10);
					clock1.month = month1_tmp + (keycode_num * 10);
					if (clock1.month > 12)
						clock1.month = 12;
				}
			} else if (clock_index_edit == 9) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t month10_tmp = clock1.month / 10;
					clock1.month = (month10_tmp * 10) + keycode_num;
					if (clock1.month > 12)
						clock1.month = 12;
				}
			} else if (clock_index_edit == 11) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t year10_tmp = clock1.year / 10;
					uint8_t year1_tmp = clock1.year - (year10_tmp * 10);
					clock1.year = year1_tmp + (keycode_num * 10);
				}
			} else if (clock_index_edit == 12) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t year10_tmp = clock1.year / 10;
					clock1.year = (year10_tmp * 10) + keycode_num;
				}
			}
		} else if (clock_index_edit_mode == 1) {
			if (clock_index_edit == 0) {
				if ((keycode_num >= 0) && (keycode_num <= 2)) {
					uint8_t hours10_tmp = clock1.hours / 10;
					uint8_t hours1_tmp = clock1.hours - (hours10_tmp * 10);
					clock1.hours = hours1_tmp + (keycode_num * 10);
					if (clock1.hours > 23)
						clock1.hours = 23;
				}
			} else if (clock_index_edit == 1) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t hours10_tmp = clock1.hours / 10;
					clock1.hours = (hours10_tmp * 10) + keycode_num;
					if (clock1.hours > 23)
						clock1.hours = 23;
				}
			} else if (clock_index_edit == 3) {
				if ((keycode_num >= 0) && (keycode_num <= 5)) {
					uint8_t minutes10_tmp = clock1.minutes / 10;
					uint8_t minutes1_tmp = clock1.minutes
							- (minutes10_tmp * 10);
					clock1.minutes = minutes1_tmp + (keycode_num * 10);
					if (clock1.minutes > 59)
						clock1.minutes = 59;
				}
			} else if (clock_index_edit == 4) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t minutes10_tmp = clock1.minutes / 10;
					clock1.minutes = (minutes10_tmp * 10) + keycode_num;
					if (clock1.minutes > 59)
						clock1.minutes = 59;
				}
			} else if (clock_index_edit == 6) {
				if ((keycode_num >= 0) && (keycode_num <= 5)) {
					uint8_t seconds10_tmp = clock1.seconds / 10;
					uint8_t seconds1_tmp = clock1.seconds
							- (seconds10_tmp * 10);
					clock1.seconds = seconds1_tmp + (keycode_num * 10);
					if (clock1.seconds > 59)
						clock1.seconds = 59;
				}
			} else if (clock_index_edit == 7) {
				if ((keycode_num >= 0) && (keycode_num <= 9)) {
					uint8_t seconds10_tmp = clock1.seconds / 10;
					clock1.seconds = (seconds10_tmp * 10) + keycode_num;
					if (clock1.seconds > 59)
						clock1.seconds = 59;
				}
			}
		}

		lcd_config_clock_cursor_move();
	}

	//lcd_refresh = 0xFF;
}

void menu_LcdScreenMonCh(void) {
	uint8_t key = keybd_info_lcd.keys[0];
	uint8_t keycode = keybd_info_lcd.key_ascii;

	if (key == KEY_ESCAPE) {
		lcd_screen = LcdScreenMain;

		lcd_screen_next = lcd_screen;

		screen_first_load = 1;

		lcd_refresh = 3;
	} else if ((keycode >= '1') && (keycode <= '8')) {
		LcdScreenMonChOffsetCh = keycode - 48;

		lcd_screen_previews = lcd_screen;

		lcd_screen = LcdScreenSenseSettings;

		lcd_refresh = 3;

		lcd_sensors_settings_selected = Settings_Selected_OFFSET;

		sensor_offset_tmp = sensor_offset[LcdScreenMonChOffsetCh - 1];

		sensor_type_tmp = sensor_type[LcdScreenMonChOffsetCh - 1];
	}
}

void menu_LcdScreenSenseSettings(void) {
	uint8_t key = keybd_info_lcd.keys[0];
	uint8_t keycode = keybd_info_lcd.key_ascii;

	if(lcd_refresh > 0) {
		return;
	}

	if ((keybd_info_lcd.lshift == 1) || (keybd_info_lcd.rshift == 1)) {
		if (key == KEY_EQUAL_PLUS) {
			key = KEY_KEYPAD_PLUS;
		}
	} else if ((keybd_info_lcd.lshift == 0) && (keybd_info_lcd.rshift == 0)) {
		if (key == KEY_MINUS_UNDERSCORE) {
			key = KEY_KEYPAD_MINUS;
		}
	}

	if (key == KEY_ESCAPE) {
		lcd_screen = LcdScreenMonCh;

		lcd_screen_next = lcd_screen;

		screen_first_load = 1;
	} else if (key == KEY_Z) {
		sensor_offset_tmp = 0;
	} else if (key == KEY_U) {
		sensor_offset_tmp = 150;
	} else if (key == KEY_D) {
		sensor_offset_tmp = -150;
	} else if ((key == KEY_ENTER) || (key == KEY_KEYPAD_ENTER)) {
		sensor_offset[LcdScreenMonChOffsetCh - 1] = sensor_offset_tmp;

		sensor_type[LcdScreenMonChOffsetCh - 1] = sensor_type_tmp;

		ConfigStruct_TypeDef conf_dat;

		W25Q64_read_config(&conf_dat);

		int16_t conv_tmp = sensor_offset_tmp; // * 10.0;

		conv_tmp += 150;

		conf_dat.SensorOffset[LcdScreenMonChOffsetCh - 1] = conv_tmp;

		conf_dat.SENSOR_TYPE[LcdScreenMonChOffsetCh - 1] = sensor_type_tmp;

		W25Q64_update_config(&conf_dat);

		lcd_screen = LcdScreenMonCh;

		lcd_screen_next = lcd_screen;

		screen_first_load = 1;

		lcd_refresh = 3;
	} else if ((keycode >= '1') && (keycode <= '8')) {
		LcdScreenMonChOffsetCh = keycode - 48;

		lcd_screen_previews = LcdScreenMonCh;

		lcd_screen = LcdScreenSenseSettings;

		lcd_refresh = 3;

		sensor_offset_tmp = sensor_offset[LcdScreenMonChOffsetCh - 1];

		sensor_type_tmp = sensor_type[LcdScreenMonChOffsetCh - 1];
	} else if (key == KEY_KEYPAD_MINUS) {
		if (sensor_offset_tmp > -150) {
			sensor_offset_tmp--;
		}
	} else if (key == KEY_KEYPAD_PLUS) {
		if (sensor_offset_tmp < 150) {
			sensor_offset_tmp++;
		}
	} else if (key == KEY_TAB) {
		if (lcd_sensors_settings_selected == Settings_Selected_OFFSET) {
			lcd_sensors_settings_selected = Settings_Selected_TYPE;
		} else {
			lcd_sensors_settings_selected = Settings_Selected_OFFSET;
		}

		lcd_refresh = 3;

		return;
	} else if (key == KEY_S) {
		if(lcd_sensors_settings_selected == Settings_Selected_TYPE) {
			if (sensor_type_tmp == sensor_type_DS18B20) {
				sensor_type_tmp = sensor_type_TMP117;
			} else {
				sensor_type_tmp = sensor_type_DS18B20;
			}

			lcd_refresh = 3;

			return;
		}
	}

	if (lcd_sensors_settings_selected == Settings_Selected_OFFSET) {
		ILI9341_FillRect(102, 45, 77, 18, ILI9341_BLACK);

		float tmp_val = sensor_offset_tmp / 10.0;

		sprintf(str, " %.1f ", tmp_val);

		if (sensor_offset_tmp == sensor_offset[LcdScreenMonChOffsetCh - 1]) {
			ILI9341_WriteString(102, 45, str, Font_11x18,
			ILI9341_BLACK, ILI9341_GREEN);
		} else {
			if (sensor_offset_tmp > sensor_offset[LcdScreenMonChOffsetCh - 1]) {
				ILI9341_WriteString(102, 45, str, Font_11x18,
				ILI9341_BLACK, ILI9341_YELLOW);
			} else if (sensor_offset_tmp
					< sensor_offset[LcdScreenMonChOffsetCh - 1]) {
				ILI9341_WriteString(102, 45, str, Font_11x18,
				ILI9341_BLACK, ILI9341_ORANGE);
			}
		}
	}
}
