/*
 * IWDG_Delay.h
 *
 *  Created on: Jun 21, 2021
 *      Author: r
 */

#ifndef INC_IWDG_DELAY_H_
#define INC_IWDG_DELAY_H_

void IWDG_delay_ms(uint32_t delay);
void IWDG_reset(void);

#endif /* INC_IWDG_DELAY_H_ */
