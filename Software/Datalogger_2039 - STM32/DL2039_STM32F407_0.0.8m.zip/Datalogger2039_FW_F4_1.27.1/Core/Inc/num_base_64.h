/*
 * num_base_64.h
 *
 *  Created on: 9 de mai de 2022
 *      Author: r
 */

#ifndef INC_NUM_BASE_64_H_
#define INC_NUM_BASE_64_H_

void conv_b10_b64(int64_t input, char *output);

#endif /* INC_NUM_BASE_64_H_ */
