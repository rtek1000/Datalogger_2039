/*
 * AES_func.h
 *
 *  Created on: 15 de mai de 2022
 *      Author:
 *
 *      Ref.: https://github.com/kokke/tiny-AES-c
 */

#ifndef INC_AES_FUNC_H_
#define INC_AES_FUNC_H_

int test_xcrypt_ctr(const char *xcrypt);

#endif /* INC_AES_FUNC_H_ */
