/*
 * Temperature_Sensor.c
 *
 *  Created on: 3 de ago de 2023
 *      Author: user
 */

#include "Temperature_Sensor.h"

#include "TMP117.h"
#include "TCA9548A.h"
#include "DS18B20.h"

#define NumOfSensors maxChannel

uint8_t sensor_initialized[NumOfSensors] = { 0 };

extern DS18B20_TypeDef SENSORS[NumOfSensors];
extern const uint8_t TMP117_Addr; // 0x48 << 1
extern const uint8_t TCA9548A_Addr; // 0x70 << 1
extern I2C_HandleTypeDef *TCA9548A_I2C_upstream;

extern void beep(uint8_t repetions, uint8_t is_error, char *ref);

extern uint8_t TMP117_initialized[8];

extern int8_t sensor_type[maxChannel];

extern int16_t sensor_offset[maxChannel];

HAL_StatusTypeDef Temperature_Sensor_init(void) {
	IWDG_delay_ms(2);

	for (uint8_t t = 0; t < maxChannel; t++) {
		if(Temperature_Sensor_TMP117_init(t) != HAL_OK) {
			UsrLog("ERROR: Temperature_Sensor_TMP117_init(%d)", t);
		}
	}

	if (DS18B20_init() != HAL_OK) {
		UsrLog("ERROR: DS18B20_init");

		beep(0, 1, "ERROR: DS18B20_init");
	} else {
		return HAL_OK;
	}

	return HAL_ERROR;
}

HAL_StatusTypeDef Temperature_Sensor_start_conversion(void) {
	//DS18B20_start_conversion(SENSORS, NumOfSensors);
	return DS18B20_readSensors(DS18B20_START_CONVERSION, SENSORS);
}

HAL_StatusTypeDef Temperature_Sensor_read_all(void) {
	uint8_t i = 0;

	UsrLog("Temperature_Sensor_read_all");

	for (i = 0; i < maxChannel; i++) {
		if (sensor_type[i] == sensor_type_DS18B20) {
			DS18B20_readSensors_CH(i, DS18B20_READ, SENSORS);
		} else { // if (sensor_type[channel_0_7] == sensor_type_TMP117) {
			Temperature_Sensor_TMP117_read(i);
		}
	}

	uint8_t beep_error = 0;

	for (i = 0; i < maxChannel; i++) {
		if ((SENSORS[i].FLAG_ENABLED == 1) & (SENSORS[i].FLAG_TIMEOUT == 1)) // sensor error
				{
			beep_error = 1;
		}
	}

	if (beep_error == 1) { // sensor error
		//UsrLog("Beep");
		UsrLog("ERROR: DS18B20_readSensors");

		beep(0, 1, "ERROR: DS18B20_readSensors");

		return HAL_ERROR;
	}

	return HAL_OK;
}

HAL_StatusTypeDef Temperature_Sensor_read(void) {
	uint8_t error_status_ID = 0;
	uint8_t error_status_PRESENT = 0;

	for (int i = 0; i < maxChannel; i++) {
		if (sensor_type[i] == sensor_type_DS18B20) {
			if (DS18B20_readSensors_CH(i, DS18B20_READ, SENSORS) != HAL_OK) {
				UsrLog("DS18B20_READ ERROR");
			}

			if (DS18B20_readSensors_CH(i, DS18B20_START_CONVERSION, SENSORS)
					!= HAL_OK) {
				UsrLog("DS18B20_START_CONVERSION ERROR");
			}
		} else { // if (sensor_type[channel_0_7] == sensor_type_TMP117) {
			Temperature_Sensor_TMP117_read(i);
		}

		if (SENSORS[i].FLAG_TIMEOUT == 1) { // sensor error
			SENSORS[i].FLAG_TIMEOUT = 0;

			SENSORS[i].FLAG_ERROR = 1;

			if (SENSORS[i].FLAG_ID_ERROR == 1) {
				error_status_ID = 1;
			}

		} else if ((SENSORS[i].FLAG_ENABLED == 1)
				&& (SENSORS[i].FLAG_TIMEOUT == 0)) {
			SENSORS[i].FLAG_ERROR = 0;
		}

		if ((SENSORS[i].FLAG_ENABLED == 1) && (SENSORS[i].FLAG_PRESENT == 0)) {
			error_status_PRESENT = 1;
		}
	}

	if ((error_status_PRESENT == 1) || (error_status_ID == 1)) {
		return HAL_ERROR;
	} else {
		return HAL_OK;
	}
}

HAL_StatusTypeDef Temperature_Sensor_TMP117_init(uint8_t channel_0_7) {
	uint8_t channel_1_8 = channel_0_7 + 1;

	if (channel_0_7 > 7) {
		UsrLog(
				"Temperature_Sensor_TMP117_init (CH%d) - ERROR, invalid parameter: channel",
				channel_1_8);

		return HAL_ERROR;
	}

	if (HAL_I2C_IsDeviceReady(TCA9548A_I2C_upstream, TCA9548A_Addr, 2, 5)
			!= HAL_OK) {
		UsrLog("TCA9548A not found");

		return HAL_ERROR;
	} else {
		//UsrLog("TCA9548A found (select channel: %d)", channel);

		uint8_t pData[1] = { 1 << channel_0_7 };
		uint8_t pDataSize = 1;
		uint32_t Timeout = 10;

		if (HAL_I2C_Master_Transmit(TCA9548A_I2C_upstream, TCA9548A_Addr, pData,
				pDataSize, Timeout) != HAL_OK) {
			UsrLog("TCA9548A Transmit not OK");

			return HAL_ERROR;
		} else {
			//UsrLog("TCA9548A Transmit OK");

			for (uint8_t r = 0; r < 5; r++) {
				if (TMP117_initialized[channel_0_7] != 1) {
					if (TMP117_begin(TCA9548A_I2C_upstream, TMP117_Addr)
							!= HAL_OK) {
						UsrLog("TMP117 begin error");
					} else {
						//UsrLog("TMP117 begin ok");

						TMP117_initialized[channel_0_7] = 1;
					}
				} else {
					break;
				}
			}
		}
	}

	return HAL_OK;
}

HAL_StatusTypeDef Temperature_Sensor_TMP117_read(uint8_t channel_0_7) {
	uint8_t channel_1_8 = channel_0_7 + 1;

	if (channel_0_7 > 7) {
		UsrLog(
				"Temperature_Sensor_TMP117_read (CH%d) - ERROR, invalid parameter: channel",
				channel_1_8);

		return HAL_ERROR;
	}

	if (sensor_type[channel_0_7] != sensor_type_TMP117) {
		//UsrLog("TMP117_read (CH%d) sensor_type != sensor_type_TMP117, skip",
//				channel_1_8);

		return HAL_OK;
	}

	if (SENSORS[channel_0_7].FLAG_ENABLED != 1) {
		//UsrLog("TMP117_read (CH%d) FLAG_ENABLED != 1, skip", channel_1_8);

		return HAL_OK;
	}

	if (HAL_I2C_IsDeviceReady(TCA9548A_I2C_upstream, TCA9548A_Addr, 2, 5)
			!= HAL_OK) {
		UsrLog("TCA9548A not found");

		SENSORS[channel_0_7].FLAG_TIMEOUT = 1;

		return HAL_ERROR;
	} else {
		//UsrLog("TCA9548A found (select channel: %d)", channel);

		uint8_t pData[1] = { 1 << (channel_0_7) };
		uint8_t pDataSize = 1;
		uint32_t Timeout = 10;

		if (HAL_I2C_Master_Transmit(TCA9548A_I2C_upstream, TCA9548A_Addr, pData,
				pDataSize, Timeout) != HAL_OK) {
			UsrLog("TCA9548A Transmit not OK");

			SENSORS[channel_0_7].FLAG_TIMEOUT = 1;

			return HAL_ERROR;
		} else {
			//UsrLog("TCA9548A Transmit OK");

			float _TempC = 0;

			for (uint8_t r = 0; r < 5; r++) {
				if (TMP117_initialized[channel_0_7] != 1) {
					if (TMP117_begin(TCA9548A_I2C_upstream, TMP117_Addr)
							!= HAL_OK) {
						UsrLog("TMP117 begin error");

						SENSORS[channel_0_7].FLAG_TIMEOUT = 1;
					} else {
						//UsrLog("TMP117 begin ok");

						TMP117_initialized[channel_0_7] = 1;
					}
				} else {
					if (TMP117_setShutdownMode(TMP117_Addr) != HAL_OK) {
						UsrLog("TMP117_setShutdownMode error");

						SENSORS[channel_0_7].FLAG_TIMEOUT = 1;
					}

					_TempC = TMP117_readTempC(TMP117_Addr);

					if (_TempC == TMP117_ERROR) {
						UsrLog("TMP117_readTempC error");

						TMP117_initialized[channel_0_7] = 0;

						SENSORS[channel_0_7].FLAG_TIMEOUT = 1;

						//return HAL_ERROR;
					} else {
						if (TMP117_readTempC(TMP117_Addr) != _TempC) {
							UsrLog("TMP117_readTempC error");

							SENSORS[channel_0_7].FLAG_PRESENT = 0;
						} else {
							float Offset = sensor_offset[channel_0_7] / 10.0;

							SENSORS[channel_0_7].TEMPERATURE = _TempC + Offset;

							SENSORS[channel_0_7].TEMPERATURE_RAW =
									SENSORS[channel_0_7].TEMPERATURE * 16.0;

//							UsrLog("TMP117_read (CH%d) Temp *C: %0.5f",
//									channel_1_8,
//									SENSORS[channel_0_7].TEMPERATURE);

							uint16_t ID_buffer1[3] = { 0 };
							uint16_t ID_buffer2[3] = { 0 };

							if (TMP117_EEPROM_read_ID(TMP117_Addr, ID_buffer1)
									== HAL_OK) {
								//UsrLog("TMP117_EEPROM_read_ID OK");
								if (TMP117_EEPROM_read_ID(TMP117_Addr,
										ID_buffer2) == HAL_OK) {
									//UsrLog("TMP117_EEPROM_read_ID OK");

									if ((ID_buffer1[0] == ID_buffer2[0])
											&& (ID_buffer1[1] == ID_buffer2[1])
											&& (ID_buffer1[2] == ID_buffer2[2])) {
										SENSORS[channel_0_7].SERIAL_ID[0] =
												0x00;

										for (uint8_t x = 0; x < 3; x++) {
											SENSORS[channel_0_7].SERIAL_ID[(x
													* 2) + 1] = (ID_buffer1[x] >> 8)
													& 0xFF;
											SENSORS[channel_0_7].SERIAL_ID[(x
													* 2) + 2] = ID_buffer1[x]
													& 0xFF;
										}

										SENSORS[channel_0_7].SERIAL_ID[7] = 0x17;

										SENSORS[channel_0_7].FLAG_PRESENT = 1;

										SENSORS[channel_0_7].FLAG_TIMEOUT = 0;

										SENSORS[channel_0_7].FLAG_ID_ERROR = 0;

										break;
									}
								}
							}

							UsrLog("TMP117_EEPROM_read_ID error");

							SENSORS[channel_0_7].FLAG_PRESENT = 0;

							SENSORS[channel_0_7].FLAG_TIMEOUT = 1;

							SENSORS[channel_0_7].FLAG_ID_ERROR = 1;

							if (channel_1_8 == 8) {
								UsrLog(" ");
							}
						}
					}

					if (TMP117_setContinuousConversionMode(TMP117_Addr)
							!= HAL_OK) {
						UsrLog("TMP117_setContinuousConversionMode error");
					}
				}
			}
		}
	}

	return HAL_OK;
}
