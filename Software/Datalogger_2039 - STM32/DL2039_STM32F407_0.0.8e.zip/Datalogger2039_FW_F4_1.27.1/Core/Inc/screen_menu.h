/*
 * screen_menu.h
 *
 *  Created on: Jun 25, 2023
 *      Author: user
 */

#ifndef INC_SCREEN_MENU_H_
#define INC_SCREEN_MENU_H_

#include "main.h"
#include "SCREEN.h"

void menu_LcdScreenMain(uint8_t key);
void menu_LcdScreenLanguage(uint8_t key);
void menu_LcdScreenMemTest(uint8_t key);
void menu_LcdScreenUsbExport(uint8_t key);
void menu_LcdScreenPasswordConfig(uint8_t key, uint8_t keycode);
void menu_LcdScreenPassword(uint8_t key, uint8_t keycode);
void menu_LcdScreenGraphic(uint8_t key, uint8_t keycode);
void menu_LcdScreenCfgCh(uint8_t key);
void menu_LcdScreenCfgChConfirm(uint8_t key);
void menu_LcdScreenCfgChMemErase(uint8_t key);
void menu_LcdScreenCfgClk(uint8_t key, uint8_t keycode);
void menu_LcdScreenMonCh(uint8_t key, uint8_t keycode);
void menu_LcdScreenMonChOffset(uint8_t key, uint8_t keycode);

#endif /* INC_SCREEN_MENU_H_ */
