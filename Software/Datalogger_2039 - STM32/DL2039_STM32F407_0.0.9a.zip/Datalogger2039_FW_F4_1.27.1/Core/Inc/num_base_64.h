/*
 * num_base_64.h
 *
 *  Created on: 9 de mai de 2022
 *      Author: r
 */

#ifndef INC_NUM_BASE_64_H_
#define INC_NUM_BASE_64_H_

void conv_b10_b64(int64_t input, char *output);
int64_t conv_b64_b10(char *input);
void print_int64(int64_t in_num, char *out_char);

#endif /* INC_NUM_BASE_64_H_ */
