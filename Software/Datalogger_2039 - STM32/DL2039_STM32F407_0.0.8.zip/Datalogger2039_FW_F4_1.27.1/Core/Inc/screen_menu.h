/*
 * screen_menu.h
 *
 *  Created on: Jun 25, 2023
 *      Author: user
 */

#ifndef INC_SCREEN_MENU_H_
#define INC_SCREEN_MENU_H_

#include "main.h"

#endif /* INC_SCREEN_MENU_H_ */
