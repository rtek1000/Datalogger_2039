/*
 * Temperature_Sensor.h
 *
 *  Created on: 3 de ago de 2023
 *      Author: user
 */

#ifndef INC_TEMPERATURE_SENSOR_H_
#define INC_TEMPERATURE_SENSOR_H_

#include "main.h"

HAL_StatusTypeDef Temperature_Sensor_init(void);
HAL_StatusTypeDef Temperature_Sensor_start_conversion(void);
HAL_StatusTypeDef Temperature_Sensor_read_all(void);
HAL_StatusTypeDef Temperature_Sensor_read(void);

HAL_StatusTypeDef Temperature_Sensor_TMP117_init(uint8_t channel);
HAL_StatusTypeDef Temperature_Sensor_TMP117_read(uint8_t channel);

#endif /* INC_TEMPERATURE_SENSOR_H_ */
