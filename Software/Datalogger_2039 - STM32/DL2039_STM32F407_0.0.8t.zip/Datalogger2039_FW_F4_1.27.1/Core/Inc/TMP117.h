/*
 **SparkFun code, firmware, and software is released under the MIT License(http://opensource.org/licenses/MIT).**

 The MIT License (MIT)

 Copyright (c) 2016 SparkFun Electronics

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 */

/******************************************************************************
 SparkFunTMP117.h
 SparkFunTMP117 Library Header File
 Madison Chodikov @ SparkFun Electronics
 Original Creation Date: April 29, 2016
 https://github.com/sparkfunX/Qwiic_TMP117

 This file prototypes the TMP117 class, implemented in SparkFunTMP117.cpp.

 Development environment specifics:
 IDE: Arduino 1.8.9
 Hardware Platform: Arduino Uno
 TMP117 Breakout Version: 1.0.0

 This code is beerware; if you see me (or any other SparkFun employee) at the
 local, and you've found our code helpful, please buy us a round!

 Distributed as-is; no warranty is given.
 ******************************************************************************/

#ifndef __TMP117_H__
#define __TMP117_H__

#include "main.h"

//#include <Wire.h>
//#include <Arduino.h>
//#include "TMP117_Registers.h"
/*
 TMP117 Registers as defined in Table 3 from datasheet (pg 24)
 Features of the TMP117:
 - ±0.1°C (Maximum) From –20°C to +50°C
 - ±0.15°C (Maximum) From –40°C to +70°C
 - ±0.2°C (Maximum) From –40°C to +100°C
 - ±0.25°C (Maximum) From –55°C to +125°C
 - ±0.3°C (Maximum) From –55°C to +150°C
 - Low Power Consumption 3.5-µA, 1-Hz Conversion Cycle
 */

// Address of the registers. This can be found on page 23 of the datasheet
enum TMP117_Register {
	TMP117_TEMP_RESULT = 0X00,
	TMP117_CONFIGURATION = 0x01,
	TMP117_T_HIGH_LIMIT = 0X02,
	TMP117_T_LOW_LIMIT = 0X03,
	TMP117_EEPROM_UL = 0X04,
	TMP117_EEPROM1 = 0X05,
	TMP117_EEPROM2 = 0X06,
	TMP117_TEMP_OFFSET = 0X07,
	TMP117_EEPROM3 = 0X08,
	TMP117_DEVICE_ID = 0X0F
};

enum TMP117_Averaged_Conversions_Mode
{
	AVG_No_Averaging = 0,
	AVG_8_Averaged_Conversions = 1,
	AVG_32_Averaged_Conversions = 2,
	AVG_64_Averaged_Conversions = 3
};

enum TMP117_ConversionCycleBit
{
	CONV_000 = 0,
	CONV_001 = 1,
	CONV_010 = 2,
	CONV_011 = 3,
	CONV_100 = 4,
	CONV_101 = 5,
	CONV_110 = 6,
	CONV_111 = 7
};



#define DEVICE_ID_VALUE 0x0117			// Value found in the device ID register on reset (page 24 Table 3 of datasheet)
#define TMP117_RESOLUTION 0.0078125f	// Resolution of the device, found on (page 1 of datasheet)
#define CONTINUOUS_CONVERSION_MODE 0b00 // Continuous Conversion Mode
#define ONE_SHOT_MODE 0b11				// One Shot Conversion Mode
#define SHUTDOWN_MODE 0b01				// Shutdown Conversion Mode

#define TMP117_ERROR -257

// Configuration register found on page 25 Figure 26 and Table 6
typedef union {
	struct {
		uint8_t EMPTY :1;			// Empty bit in register
		uint8_t TMP_SOFT_RESET :1; // Software reset bit
		uint8_t DR_ALERT :1;		// ALERT pin select bit
		uint8_t POL :1;			// ALERT pin polarity bit
		uint8_t T_NA :1;			// Therm/alert mode select
		uint8_t AVG :2;			// Conversion averaging modes
		uint8_t CONV1 :3;			// Conversion cycle bit
		uint8_t MOD :2;			// Set conversion mode
		uint8_t EEPROM_BUSY :1;	// EEPROM busy flag
		uint8_t DATA_READY :1;		// Data ready flag
		uint8_t LOW_ALERT :1;		// Low Alert flag
		uint8_t HIGH_ALERT :1;		// High Alert flag
	} CONFIGURATION_FIELDS;
	uint16_t CONFIGURATION_COMBINED;
} CONFIGURATION_REG;

// Device ID Register used for checking if the device ID is the same as declared
// This register is found on Page 30 of the datasheet in Table 15 and Figure 34
typedef union {
	struct {
		uint16_t DID :12; // Indicates the device ID
		uint8_t REV :4;   // Indicates the revision number
	} DEVICE_ID_FIELDS;
	uint16_t DEVICE_ID_COMBINED;
} DEVICE_ID_REG;

//class TMP117
//{
//public:
//	TMP117(); // Constructor

HAL_StatusTypeDef TMP117_begin(I2C_HandleTypeDef *i2cPort, uint8_t _addr); // Checks for ACK over I2C, and sets the device ID of the TMP and chooses the wire port
//uint8_t TMP117_getAddress(uint8_t channel);				// Returns the address of the device
HAL_StatusTypeDef TMP117_readTempC(uint8_t _addr, float *finalTempC);	// Returns the temperature in degrees C
HAL_StatusTypeDef TMP117_readTempF(uint8_t _addr, float *finalTempF);	// Converts readTempC result to degrees F
HAL_StatusTypeDef TMP117_softReset(uint8_t _addr);// Performs a software reset on the Configuration Register Field bits
HAL_StatusTypeDef TMP117_getTemperatureOffset(uint8_t _addr, float *offSet);// Reads the temperature offset
HAL_StatusTypeDef TMP117_setTemperatureOffset(uint8_t _addr, float offset);// Writes to the temperature offset
HAL_StatusTypeDef TMP117_getLowLimit(uint8_t _addr, float *lowLimit);	// Returns the low limit register
HAL_StatusTypeDef TMP117_setLowLimit(uint8_t _addr, float lowLimit);	// Sets the low limit temperature for the low limit register
HAL_StatusTypeDef TMP117_getHighLimit(uint8_t _addr, float *highLimit);	// Returns the high limit register
HAL_StatusTypeDef TMP117_setHighLimit(uint8_t _addr, float highLimit);// Sets the low limit temperature for the low limit register
uint16_t TMP117_getConfigurationRegister(uint8_t channel);// Get Configuration Register
uint8_t TMP117_getHighLowAlert(uint8_t _addr);// Reads in Alert mode for high and low alert flags
uint8_t TMP117_getHighAlert(uint8_t _addr);	// Reads in Alert mode for a high alert flag
uint8_t TMP117_getLowAlert(uint8_t _addr);// Reads in Alert mode for a low alert flag
HAL_StatusTypeDef TMP117_setAlertFunctionMode(uint8_t _addr, uint8_t setAlertMode);// Set alert or therm mode
uint8_t TMP117_getAlertFunctionMode(uint8_t _addr);	// Check to see if in alert or therm mode
uint8_t TMP117_getConversionMode(uint8_t _addr);// Checks to see the Conversion Mode the device is currently in
HAL_StatusTypeDef TMP117_setContinuousConversionMode(uint8_t _addr);	// Sets the Conversion Mode of the Device to be Continuous
HAL_StatusTypeDef TMP117_setOneShotMode(uint8_t _addr);// Sets the Conversion Mode of the Device to be One Shot
HAL_StatusTypeDef TMP117_setShutdownMode(uint8_t _addr);	// Sets the Conversion Mode of the Device to be Shutdown
HAL_StatusTypeDef TMP117_setConversionAverageMode(uint8_t _addr, uint8_t convMode);// Sets the conversion averaging mode
uint8_t TMP117_getConversionAverageMode(uint8_t _addr);	// Returns the Conversion Averaging Mode
HAL_StatusTypeDef TMP117_setConversionCycleBit(uint8_t _addr, uint8_t convTime);	// Sets the conversion cycle time bit
uint8_t TMP117_getConversionCycleBit(uint8_t _addr);// Returns the conversion cycle time bit value
uint16_t TMP117_getConversionCycleTime(uint8_t _addr);// Returns the conversion cycle time (ms) value
uint8_t TMP117_dataReady(uint8_t _addr);// Checks to see if there is data ready from the device
uint8_t TMP117_EEPROM_read_ID(uint8_t _addr, uint16_t *data_buffer);
void TMP117_get_hex_id(uint8_t *sensor_ID, char *str_buff);
void TMP117_b64_id(uint8_t *sensor_ID, char *str_buff);

//private:
//uint8_t sensorAddress = 0x48;
//I2C_HandleTypeDef *_i2cPort = NULL; //The generic connection to user's chosen I2C hardware
//uint8_t _deviceAddress;   // Address of Temperature sensor

HAL_StatusTypeDef TMP117_readRegister(uint8_t _addr, uint8_t reg, uint16_t *data_out);// Reads 2 register bytes from sensor
HAL_StatusTypeDef TMP117_writeRegister(uint8_t _addr, uint8_t reg,
		uint16_t data); // Wires single byte of data to the sensor
//};

#endif // #ifndef __TMP117_H__
