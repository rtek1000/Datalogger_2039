/*
 * screen_menu.h
 *
 *  Created on: Jun 25, 2023
 *      Author: user
 */

#ifndef INC_SCREEN_MENU_H_
#define INC_SCREEN_MENU_H_

#include "main.h"
#include "SCREEN.h"

void menu_LcdScreenMain(void);
void menu_LcdScreenLanguage(void);
void menu_LcdScreenMemTest(void);
void menu_LcdScreenUsbExport(void);
void menu_LcdScreenPasswordConfig(void);
void menu_LcdScreenPassword(void);
void menu_LcdScreenGraphic(void);
void menu_LcdScreenCfgCh_load_ch(uint8_t ch_index);
void menu_LcdScreenCfgCh(void);
void menu_LcdScreenCfgChConfirm(void);
void menu_LcdScreenCfgChMemErase(void);
void menu_LcdScreenCfgClk(void);
void menu_LcdScreenMonCh(void);
void menu_LcdScreenSenseSettings(void);

#endif /* INC_SCREEN_MENU_H_ */
