/*
 * num_base_64.c
 *
 *  Created on: 9 de mai de 2022
 *      Author: r
 */
#include "main.h"
#include "num_base_64.h"
#include <math.h>
//#include <stdio.h>

static uint8_t indexOfMap(char *map, char input);

void conv_b10_b64(int64_t input, char *output) {
	int64_t num10 = input;
	int64_t R;
	int64_t Q;
	int J = 0;
	int k = 0;
	uint8_t is_negative = 0;
	char map[] =
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	char tmp[20];

	if (num10 < 0) {
		is_negative = 1;
		num10 = num10 * (-1);
	}

	if (num10 != 0) {
		Q = num10;

		while (Q > 0) {
			Q = 0;

			while (num10 >= 64) {
				num10 = num10 - 64;
				Q = Q + 1;
			}

			R = num10;

			tmp[J] = map[R];

			num10 = Q;

			J++;
		}

		tmp[J] = 0;

		if (is_negative == 1) {
			output[0] = 45; // "-"
		}

		k = 0;

		while (tmp[k] != 0) {
			k++;
		}

		for (int i = 0; i < k; i++) {
			if (is_negative != 1) {
				output[i] = tmp[(k - 1) - i];
			} else {
				output[i + 1] = tmp[(k - 1) - i];
			}
		}

		if (is_negative != 1) {
			output[J] = 0;
		} else {
			output[J + 1] = 0;
		}
	} else {
		output[0] = map[0];
		output[1] = 0;
	}
}

int64_t conv_b64_b10(char *input) {
	int64_t result = 0;
//	int64_t tmp1 = 0;
	uint8_t is_negative = 0;
//	char input_tmp[11] = {0};

	char map[] =
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	uint8_t input_Length = 0;

	while (input_Length < 255) {
		if (input[input_Length] != 0) {
			input_Length++;
		} else {
			break;
		}
	}

	if (input_Length > 11) {
		UsrLog("error, input_Length > 11");

		return result;
	}

	if ((input[0] == 0) || ((input[0] == map[0]) && (input[1] == 0))) {
		result = 0;
		UsrLog("return 0");
		return result;
	}

	if (input[0] == 45) {
		is_negative = 1;
	}

	for (int8_t i = 0; i < input_Length; i++) {
		int64_t multiplier = pow(64, (input_Length - 1) - i);

		char str_buff2[32];

		print_int64(multiplier, str_buff2);
		UsrLog("conv_b64_b10: multiplier = %s", str_buff2);

		int64_t map_index = (int64_t) indexOfMap(map, input[i]);

		print_int64(map_index, str_buff2);
		UsrLog("conv_b64_b10: map_index = %s", str_buff2);

		int64_t calc_tmp = map_index * multiplier;

		print_int64(calc_tmp, str_buff2);
		UsrLog("conv_b64_b10: calc_tmp = %s", str_buff2);

		result = result + calc_tmp;
	}

	if (is_negative == 1) {
		result *= (int64_t) -1;
	}

	return result;
}

static uint8_t indexOfMap(char *map, char input) {
	uint8_t map_size = 0;
	uint8_t result = 0;

	while (map_size < 255) {
		if (map[map_size] != 0) {
			map_size++;
		} else {
			break;
		}
	}

	for (uint8_t i = 0; i < map_size; i++) {
		if (input == map[i]) {
			result = i;
			break;
		}
	}

	return result;
}

void print_int64(int64_t in_num, char *out_char) {
	uint8_t index = 0;
	int64_t divider = 1000000000000000000;

	if (in_num < 0) {
		out_char[index] = '-';
		index++;
	}

	if (in_num >= 10) {
		while (in_num >= 1) {
			out_char[index] = in_num / divider;

			in_num -= ((int64_t) out_char[index] * divider);

			out_char[index] += (int64_t) 48;

			divider /= 10;

			index++;

			IWDG_delay_ms(0);
		}

		out_char[index] = 0;
	} else {
		sprintf(out_char, "%d", (int8_t) in_num);
	}
}
