/*
 **SparkFun code, firmware, and software is released under the MIT License(http://opensource.org/licenses/MIT).**

 The MIT License (MIT)

 Copyright (c) 2016 SparkFun Electronics

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 */

/******************************************************************************
 SparkFunTMP117.cpp
 SparkFunTMP117 Library Source File
 Madison Chodikov @ SparkFun Electronics
 Original Creation Date: April 22, 2019
 https://github.com/sparkfun/SparkFun_TMP117_Arduino_Library

 This file implements all functions of the TMP117 class. Functions here range
 from reading the temperature from the sensor, to reading and writing various
 settings in the sensor.

 Development environment specifics:
 IDE: Arduino 1.8.9
 Hardware Platform: Arduino Uno
 TMP117 Breakout Version: 1.0.0

 This code is beerware; if you see me (or any other SparkFun employee) at the
 local, and you've found our code helpful, please buy us a round!

 Distributed as-is; no warranty is given.
 ******************************************************************************/

/*
 NOTE: Read for use for the most accurate readings from the sensor
 - Avoid heavy bypass traffic on the I2C bus for most accurate temperature readings
 - Use the highest available communication speeds
 - Use the minimal supply voltage acceptable for the system
 - Place device horizontally and out of any airflow when storing
 For more information on reaching the most accurate readings from the sensor,
 reference the "Precise Temperature Measurements with TMP116" datasheet that is
 linked on Page 35 of the TMP117's datasheet
 */

#include "TMP117.h"
#include "num_base_64.h"

// From Arduino.h:
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitToggle(value, bit) ((value) ^= (1UL << (bit)))
#define bitWrite(value, bit, bitvalue) ((bitvalue) ? bitSet(value, bit) : bitClear(value, bit))

uint8_t TCA9548A_I2C_Switch_Addr = 0x70; // ADR2:0; ADR1:0; ADR0:0;

uint8_t TMP117_initialized[8] = { 0 };

const uint8_t TMP117_Addr = 0x90; // 0x48 << 1
//uint8_t sensorAddress = 0x48;
I2C_HandleTypeDef *_i2cPort = NULL; //The generic connection to user's chosen I2C hardware
//uint8_t _deviceAddress;   // Address of Temperature sensor

/* BEGIN
 This function checks if the TMP will ACK over I2C, and
 if the TMP will correctly self-identify with the proper
 device ID. This will set the address of the device along
 with setting the wire for the I2C Communication.
 This will return true if both checks pass.
 */

extern I2C_HandleTypeDef hi2c3;

HAL_StatusTypeDef TMP117_begin(I2C_HandleTypeDef *i2cPort, uint8_t _addr) {
	_i2cPort = i2cPort; // Chooses the wire port of the device

	//make sure the TMP will acknowledge over I2C
	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		//UsrLog("Error: TMP117_begin, device not found");
		return HAL_ERROR;
	} else {
		uint16_t deviceID = 0;

		if (TMP117_readRegister(_addr, TMP117_DEVICE_ID, &deviceID) != HAL_OK) { // reads registers into rawData
			return HAL_ERROR;
		}

		//make sure the device ID reported by the TMP is correct
		//should always be 0x0117
		if (deviceID != DEVICE_ID_VALUE) {
			UsrLog("Error: deviceID: 0x%04Xl", deviceID);

			return HAL_ERROR;
		}

		if (TMP117_softReset(_addr) != HAL_OK) {
			return HAL_ERROR;
		}

		// When set to 1 it triggers software reset with a duration of 2 ms
		// This bit will always read back 0
		HAL_Delay(2);

		if (TMP117_setShutdownMode(_addr) != HAL_OK) {
			return HAL_ERROR;
		}

		if (TMP117_setConversionAverageMode(_addr, AVG_32_Averaged_Conversions)
				!= HAL_OK) {
			return HAL_ERROR;
		}

		if (TMP117_setConversionCycleBit(_addr, CONV_000) != HAL_OK) {
			return HAL_ERROR;
		}

		if (TMP117_setOneShotMode(_addr) != HAL_OK) {
			return HAL_ERROR;
		}
	}

	return HAL_OK; //returns true if all the checks pass
}

///* GET ADDRESS
// This function returns the address of the device once
// called upon. This address can only be 0x48 (GND),
// 0x49 (V+), 0x4A (SDA), and 0x4B (SCL)
// */
//uint8_t TMP117_getAddress(uint8_t channel) {
//	return _deviceAddress;
//}

/* READ REGISTER
 This function reads the register bytes from the sensor when called upon.
 This reads 2 bytes of information from the 16-bit registers.
 */
HAL_StatusTypeDef TMP117_readRegister(uint8_t _addr, uint8_t reg,
		uint16_t *data_out) // originally TMP117_Register reg
{
	uint8_t data[2] = { 0 };		// Declares an array of length 2 to be empty
	int16_t datac = 0;				// Declares the return variable to be 0
	uint16_t Size = 2;
	uint32_t Timeout = 100;

	data[0] = reg;

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) == HAL_OK) {
		if (HAL_I2C_Master_Transmit(_i2cPort, _addr, data, 1, Timeout)
				!= HAL_OK) {
			UsrLog("TMP117: HAL_I2C_Master_Transmit() NOT OK");

			*data_out = 0;

			return HAL_ERROR;
		} else {
			if (HAL_I2C_Master_Receive(_i2cPort, _addr, data, Size, Timeout)
					== HAL_OK) {
				datac = ((data[0] << 8) | data[1]);
			} else {
				UsrLog("TMP117: HAL_I2C_Master_Receive() NOT OK");

				*data_out = 0;

				return HAL_ERROR;
			}
		}
	} else {
		UsrLog("TMP117: Device is not Ready; ERROR");

		*data_out = 0;

		return HAL_ERROR;
	}

	IWDG_delay_ms(0);

	*data_out = datac;

	return HAL_OK;
}

/* WRITE REGISTER
 Wire data to a TMP117 register
 */
HAL_StatusTypeDef TMP117_writeRegister(uint8_t _addr, uint8_t reg,
		uint16_t data) // originally TMP117_Register reg
{
	uint8_t _dat[2] = { (data >> 8) & 0xFF, data & 0xFF }; // Declares an array of length 2 to be empty
	uint16_t Size = 2;
	uint32_t Timeout = 100;

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) == HAL_OK) {
		if (HAL_I2C_Master_Transmit(_i2cPort, _addr, _dat, Size, Timeout)
				!= HAL_OK) {
			UsrLog("TMP117: HAL_I2C_Master_Transmit() NOT OK");

			return HAL_ERROR;
		}
	} else {
		UsrLog("TMP117: Device is not Ready; ERROR");

		return HAL_ERROR;
	}

	return HAL_OK;
}

/* READ TEMPERATURE CELSIUS
 This function reads the temperature reading from the sensor
 and returns the value in degrees celsius.

 NOTE: The data type of digitalTemp is a signed integer, meaning that the
 value of the binary number being read will be negative if the MSB is 1,
 and positive if the bit is 0.
 */
HAL_StatusTypeDef TMP117_readTempC(uint8_t _addr, float *finalTempC) {
	//float finalTempC = 0;

	//UsrLog("TMP117_readTempC(uint8_t _addr, float *finalTempC)");

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		*finalTempC = TMP117_ERROR;

		return HAL_ERROR;
	}

	uint16_t digitalTempC = 0;

	if (TMP117_readRegister(_addr, TMP117_TEMP_RESULT, &digitalTempC) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		*finalTempC = TMP117_ERROR;

		return HAL_ERROR;
	}

	if (digitalTempC == 0xFFFF) {
		*finalTempC = TMP117_ERROR;

		return HAL_ERROR;
	}

	*finalTempC = digitalTempC * TMP117_RESOLUTION; // Multiplies by the resolution for digital to final temp

	return HAL_OK;
}

/* READ TEMPERATURE FAHRENHEIT
 This function calculates the fahrenheit reading from the
 celsius reading initially found.
 The device reads in celsius unless this function is called.
 */
HAL_StatusTypeDef TMP117_readTempF(uint8_t _addr, float *finalTempF) {
	float tempC = 0.0;

	if (TMP117_readTempC(_addr, &tempC) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		*finalTempF = TMP117_ERROR;

		return HAL_ERROR;
	}

	//TMP117_readTempC(_addr, &tempC);

	if (tempC == TMP117_ERROR) {
		*finalTempF = TMP117_ERROR * 9.0 / 5.0 + 32.0; // Conversion from °C to °F (-257°C)

		return HAL_ERROR;
	} else {
		*finalTempF = tempC * 9.0 / 5.0 + 32.0; // Conversion from °C to °F
	}

	return HAL_OK;
}

/* GET TEMPERATURE OFFSET
 This function reads the temperature offset. This reads from the register
 value 0x07 (TMP117_TEMP_OFFSET). This can be found on page 23 of the
 datasheet.
 */
HAL_StatusTypeDef TMP117_getTemperatureOffset(uint8_t _addr, float *offSet) {
	//int16_t _offset = 0;

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		*offSet = TMP117_ERROR;

		return HAL_ERROR;
	}

	uint16_t _offset = 0;

	if (TMP117_readRegister(_addr, TMP117_TEMP_OFFSET, &_offset) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//_offset = TMP117_readRegister(_addr, TMP117_TEMP_OFFSET); // Reads from the temperature offset register
	float finalOffset = (float) _offset * TMP117_RESOLUTION; // Multiplies by the resolution for correct offset temperature
	*offSet = finalOffset;

	return HAL_OK;
}

/* SET TEMPERATURE OFFSET
 This function sets the offset temperature of the device. The user
 can write to this to set any desired offset within the temperature range.
 This writes to the register value 0x07 (TMP117_TEMP_OFFSET)
 */
HAL_StatusTypeDef TMP117_setTemperatureOffset(uint8_t _addr, float offset) {
	int16_t resolutionOffset = offset / TMP117_RESOLUTION; // Divides by the resolution to send the correct value to the sensor
	if (TMP117_writeRegister(_addr, TMP117_TEMP_OFFSET, resolutionOffset)
			!= HAL_OK) { // Writes to the offset temperature register with the new offset value
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* GET LOW LIMIT
 This function reads the low limit register that is set by the user.
 The values are signed integers since they can be negative.
 */
HAL_StatusTypeDef TMP117_getLowLimit(uint8_t _addr, float *lowLimit) {
	//int16_t lowLimit = 0;

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		*lowLimit = TMP117_ERROR;

		return HAL_ERROR;
	}

	uint16_t _lowLimit = 0;

	if (TMP117_readRegister(_addr, TMP117_T_LOW_LIMIT, &_lowLimit) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//lowLimit = TMP117_readRegister(_addr, TMP117_T_LOW_LIMIT); // Calls to read register to pull all the bits to store in a variable
	float finalLimit = (float) _lowLimit * TMP117_RESOLUTION; // Multiplies by the resolution for correct offset temperature
	*lowLimit = finalLimit;

	return HAL_OK;
}

/* SET LOW LIMIT
 This function allows the user to set the low limit register to whatever
 specified value, as long as in the range for the temperature sensor. This
 function can be used as a threshold for Therm mode and or Alert mode.
 The values are signed integers since they can be negative.
 */
HAL_StatusTypeDef TMP117_setLowLimit(uint8_t _addr, float lowLimit) {
	int16_t finalLimit = lowLimit / TMP117_RESOLUTION; // Divides by the resolution to send the correct value to the sensor

	if (TMP117_writeRegister(_addr, TMP117_T_LOW_LIMIT, finalLimit) != HAL_OK) { // Writes to the low limit temperature register with the new limit value
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* GET HIGH LIMIT
 This function reads the high limit register that is set by the user.
 The values are signed integers since they can be negative.
 */
HAL_StatusTypeDef TMP117_getHighLimit(uint8_t _addr, float *highLimit) {
	//int16_t highLimit = 0;

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		*highLimit = TMP117_ERROR;

		return HAL_ERROR;
	}

	uint16_t _highLimit = 0;

	if (TMP117_readRegister(_addr, TMP117_T_HIGH_LIMIT, &_highLimit) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		*highLimit = TMP117_ERROR;

		return HAL_ERROR;
	}

	//highLimit = TMP117_readRegister(_addr, TMP117_T_HIGH_LIMIT); // Calls to read registers to pull all the bits to store in an array
	float finalLimit = (float) _highLimit * TMP117_RESOLUTION; // Multiplies by the resolution for correct offset temperature
	*highLimit = finalLimit;

	return HAL_OK;
}

/* SET HIGH LIMIT
 This function allows the user to set the high limit register to whatever
 specified value, as long as in the range for the temperature sensor. This
 function can be used as a threshold for Therm mode and or Alert mode
 The values are signed integers since they can be negative.
 */
HAL_StatusTypeDef TMP117_setHighLimit(uint8_t _addr, float highLimit) {
	int16_t finalLimit = highLimit / TMP117_RESOLUTION; // Divides by the resolution to send the correct value to the sensor

	if (TMP117_writeRegister(_addr, TMP117_T_HIGH_LIMIT, finalLimit)
			!= HAL_OK) { // Writes to the high limit temperature register with the new limit value
		return HAL_ERROR;
	}

	return HAL_OK;

}

/*GET CONFIGURATION REGISTER
 This function reads configuration register. Use this function if you need to read
 certain flags before they are cleared. This can be found on page 25 of the
 datasheet.
 */
uint16_t TMP117_getConfigurationRegister(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION);

	return configReg;
}

/*GET HIGH AND LOW ALERT
 This function reads configuration register and saves the high and low alert flags.
 Use this function if you need to read the alert flags before they are cleared.
 This can be found on page 25 of the datasheet.
 */
uint8_t TMP117_getHighLowAlert(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); //Grab what is in the configuration register

	uint8_t highlowAlert = 0; //temporary variable to hold high and low alert flags
	//Get high alert flag from 15th bit of the configuration register,
	//    then write bit to highlowAlert's 2nd position from the right
	bitWrite(highlowAlert, 1, bitRead(configReg, 15));

	//Get high alert flag from 14th bit of the configuration register,
	//    then write bit to highlowAlert's 1st position from the right
	bitWrite(highlowAlert, 0, bitRead(configReg, 14));

	return highlowAlert; //return high and low alert flags
}

/*GET HIGH ALERT
 This function reads the 15th bit of the configuration register to
 tell if the conversion result is higher than the high limit. This
 is set as a High Alert flag. This can be found on page 25 of the
 datasheet.
 */
uint8_t TMP117_getHighAlert(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); //Grab what is in the configuration register

	uint8_t highAlert = bitRead(configReg, 15); // Fills with the 15th bit of the configuration register

	if (highAlert == 1) {
		return true;
	} else {
		return false;
	}
}

/*GET LOW ALERT
 This function reads the 14th bit of the configuration register to
 tell if the conversion result is lower than the low limit. This
 is set as a Low Alert flag. This can be found on page 25 of the
 datasheet.
 */
uint8_t TMP117_getLowAlert(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); //Grab what is in the configuration register

	uint8_t lowAlert = bitRead(configReg, 14); // Fills with the 14th bit of the configuration register

	if (lowAlert == 1) {
		return true;
	} else {
		return false;
	}
}

/*SET ALERT FUNCTION MODE
 This function sets the alert function mode to either "alert" or
 "therm" mode. This can be found on page 25 of the datasheet.
 */
HAL_StatusTypeDef TMP117_setAlertFunctionMode(uint8_t _addr,
		uint8_t setAlertMode) {
	uint16_t AlertFunctionMode = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &AlertFunctionMode) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//AlertFunctionMode = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills mode to be the config register

	if (setAlertMode == 1) // 1: Therm mode
			{
		bitSet(AlertFunctionMode, 4); //set register bit to be 1
		if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, AlertFunctionMode)
				!= HAL_OK) {
			return HAL_ERROR;
		}
	} else // 0: alert mode
	{
		bitClear(AlertFunctionMode, 4); //set register bit to be 0
		if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, AlertFunctionMode)
				!= HAL_OK) {
			return HAL_ERROR;
		}
	}

	return HAL_OK;
}

/*GET ALERT FUNCTION MODE
 This function gets the alert function mode to either "alert" or
 "therm" mode. This can be found on page 25 of the datasheet.
 */
uint8_t TMP117_getAlertFunctionMode(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fill configReg with the configuration register

	uint8_t currentAlertMode = bitRead(configReg, 4); //Get the value from the Therm/alert mode ("T/nA") select field

	if (currentAlertMode == 1) //if "therm" mode
			{
		return 1;
	} else //if "alert" mode
	{
		return 0;
	}
}

/* SOFTWARE RESET
 This function performs a software reset, loading all the default
 values into the configuration register. A table of the configuration
 register can be found on page 25 of the datasheet.
 */
HAL_StatusTypeDef TMP117_softReset(uint8_t _addr) {
	uint16_t reset = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &reset) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//reset = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills mode to be the configuration register

	bitSet(reset, 1);
	if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, reset) != HAL_OK) {
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* SET CONTINUOUS CONVERSION MODE
 This function sets the conversion mode of the sensor to be
 continuous. This can be found in the datasheet on Page 25 Table 6.
 The TMP117 defaults to Continuous Conversion Mode on reset.
 */
HAL_StatusTypeDef TMP117_setContinuousConversionMode(uint8_t _addr) {
	uint16_t mode = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &mode) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//mode = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills mode to be the configuration register

	bitClear(mode, 10); // Clears bit 10
	bitClear(mode, 11); // Clears bit 11
	if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, mode) != HAL_OK) {
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* SET SHUTDOWN MODE
 This function sets the conversion mode of the sensor to be
 in shutdown mode. This can be found in the datasheet on Page
 25 Table 6. The TMP117 defaults to Continuous Conversion Mode
 on reset.
 */
HAL_StatusTypeDef TMP117_setShutdownMode(uint8_t _addr) {
	uint16_t mode = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &mode) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//mode = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills mode to be the configuration register

	bitClear(mode, 11);	// Clears bit 11
	bitSet(mode, 10); // Sets bit 10 to 1
	if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, mode) != HAL_OK) {
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* SET ONE SHOT MODE
 This function sets the conversion mode of the sensor to be
 in one shot mode. This can be found in the datasheet on Page
 25 Table 6. The TMP117 defaults to Continuous Conversion Mode
 on reset.
 */
HAL_StatusTypeDef TMP117_setOneShotMode(uint8_t _addr) {
	uint16_t mode = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &mode) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//mode = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills mode to be the configuration register

	bitSet(mode, 10); // Sets bit 10 to 1
	bitSet(mode, 11); // Sets bit 11 to 1
	if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, mode) != HAL_OK) {
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* GET CONVERSION MODE
 This function reads the mode for the conversions, then
 prints it to the Serial Monitor in the Arduino IDE.
 This can be found in the datasheet on Page 25 Table 6.
 This function can return Continuous Conversion Mode (1),
 Shutdown Mode (2), and One-Shot Mode (3). This should never
 return 4 (the other continuous conversion) since there is
 no function for writing to the value.
 */
uint8_t TMP117_getConversionMode(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fill configReg with the configuration register

	uint8_t currentMode1 = bitRead(configReg, 11); // Left most conversion bit
	uint8_t currentMode2 = bitRead(configReg, 10); // Right most conversion bit

	if ((currentMode1 == 0) && (currentMode2 == 0)) // 0b00, Continuous Conversion Mode
			{
		return 1; // Actually 0, but return 1 for the example sketch
	} else if ((currentMode1 == 1) && (currentMode2 == 0)) // 0b10, should not be set this
			{
		return 4; // This value should never be returned
	} else if ((currentMode1 == 0) && (currentMode2 == 1)) // 0b01, Shutdown Mode
			{
		return 2; // Actually 0b01, but return 2 for the example sketch
	} else if ((currentMode1 == 1) && (currentMode2 == 1)) // 0b11, One-Shot Mode
			{
		return 3;
	} else {
		return 1; //Default
	}
}

/*SET CONVERSION AVERAGE MODE 
 This function sets the conversion averaging mode of the device
 when in Continuous Conversion Mode. This can be found on page
 25 of the TMP117 datasheet.
 */
HAL_StatusTypeDef TMP117_setConversionAverageMode(uint8_t _addr,
		uint8_t convMode) {
	uint16_t mode = 0;

	if (convMode > 0x03) {
		return HAL_ERROR;
	}

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &mode) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//mode = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills to be the config register

	mode &= 0xFF9F; // Clear bits: 6, 5

	mode |= convMode << 5;

	if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, mode) != HAL_OK) {
		return HAL_ERROR;
	}

	return HAL_OK;
}

/*GET CONVERSION AVERAGE MODE
 This function reads for the averaging mode of the conversions,
 then prints it to the Serial Monitor in the Arduino IDE.
 This can be found in the datasheet on Page 25 Table 6.
 */
uint8_t TMP117_getConversionAverageMode(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills configReg with config register values

	return (configReg >> 5) & 0x03; // bits 6, 5
}

/* SET CONVERSION CYCLE BIT
 This function sets the conversion cycle time bit in
 Continuous Conversion mode. The times for the conversions
 can be found below or in the datasheet on Page 25 Table
 6 or on Page 27 Table 7. The user puts in 0-7 and it will
 return the cycle time accoring to the values in the chart.

 Conversion Cycle Time in CC Mode (found on the datasheet page 26 table 6)
 AVG       0       1       2       3
 CONV  averaging  (0)     (8)     (32)   (64)
 0             15.5ms  125ms   500ms    1s
 1             125ms   125ms   500ms    1s
 2             250ms   250ms   500ms    1s
 3             500ms   500ms   500ms    1s
 4             1s      1s      1s       1s
 5             4s      4s      4s       4s
 6             8s      8s      8s       8s
 7             16s     16s     16s      16s
 */
HAL_StatusTypeDef TMP117_setConversionCycleBit(uint8_t _addr, uint8_t convTime) {
	uint16_t mode = 0;

	if (convTime > 0x07) {
		return HAL_ERROR;
	}

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &mode) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//mode = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills in time to be the config register

	mode &= 0xFC7F; // Clears bit 9, 8, 7

	mode |= (convTime & 0x07) << 7;

	if (TMP117_writeRegister(_addr, TMP117_CONFIGURATION, mode) != HAL_OK) {
		return HAL_ERROR;
	}

	return HAL_OK;
}

/* GET CONVERSION CYCLE BIT
 This function returns the Conversion Cycle Bit value that the
 device is currently in at the time. This bit can help determine
 the conversion cycle time that the device is in while being in
 continuous conversion mode.

 Conversion Cycle Time in CC Mode (found on the datasheet page 26 table 6)
 AVG       0       1       2       3
 CONV  averaging  (0)     (8)     (32)   (64)
 0             15.5ms  125ms   500ms    1s
 1             125ms   125ms   500ms    1s
 2             250ms   250ms   500ms    1s
 3             500ms   500ms   500ms    1s
 4             1s      1s      1s       1s
 5             4s      4s      4s       4s
 6             8s      8s      8s       8s
 7             16s     16s     16s      16s
 */
uint8_t TMP117_getConversionCycleBit(uint8_t _addr) {
	uint16_t configReg = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills configReg with config register values

	configReg = (configReg >> 7) & 0x07;

	return configReg;
}

/* GET CONVERSION CYCLE TIME
 This function returns the Conversion Cycle Time (ms) value that the
 device is currently in at the time. This value determine
 the conversion cycle time that the device is in while being in
 continuous conversion mode.

 Conversion Cycle Time in CC Mode (found on the datasheet page 26 table 6)
 AVG				0		1		2		3
 CONV	averaging	(0)		(8)		(32)	(64)
 0					15.5ms	125ms	500ms	1s
 1					125ms	125ms	500ms	1s
 2					250ms	250ms	500ms	1s
 3					500ms	500ms	500ms	1s
 4					1s		1s		1s		1s
 5					4s		4s		4s		4s
 6					8s		8s		8s		8s
 7					16s		16s		16s		16s
 */
uint16_t TMP117_getConversionCycleTime(uint8_t _addr) {
	uint16_t configReg = 0;
	const uint8_t AVG_bit_LSb = 5;
	const uint8_t CONV_bit_LSb = 7;

	uint8_t _AVG = 0;
	uint8_t _CONV = 0;

	const uint16_t result[8] = { 15, 125, 250, 500, 1000, 4000, 8000, 16000 };

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &configReg) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//configReg = TMP117_readRegister(_addr, TMP117_CONFIGURATION); // Fills configReg with config register values

	_AVG = (configReg >> AVG_bit_LSb) & 0x07;
	_CONV = (configReg >> CONV_bit_LSb) & 0x03;

	switch (_CONV) {
	case 0:
		return result[_AVG];
		break;
	case 1:
		if (_AVG < 1) {
			return result[1];
		} else {
			return result[_AVG];
		}
		break;
	case 2:
		if (_AVG < 3) {
			return result[3];
		} else {
			return result[_AVG];
		}
		break;
	case 3:
		if (_AVG < 4) {
			return result[4];
		} else {
			return result[_AVG];
		}
		break;
	default:
		break;
	}

	return 0;
}

/* DATA READY
 This function checks to see if there is data ready to be sent
 from the TMP117. This can be found in Page 25 Table 6 of the
 data sheet.
 */
uint8_t TMP117_dataReady(uint8_t _addr) {
	uint16_t response = 0;

	if (TMP117_readRegister(_addr, TMP117_CONFIGURATION, &response) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
		return HAL_ERROR;
	}

	//TMP117_readRegister(_addr, TMP117_CONFIGURATION);

	// If statement to see if the 13th bit of the register is 1 or not
	if (response & 1 << 13) {
		return true;
	} else {
		return false;
	}
}

/* EEPROM Read ID (data_buffer[3])
 This function read data from EEPROM (do not overwrite data,
 the data are unique traceable (NIST) serial numbers).
 */
HAL_StatusTypeDef TMP117_EEPROM_read_ID(uint8_t _addr, uint16_t *data_buffer) {
	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		UsrLog("Error: TMP117_begin, device not found");

		data_buffer[0] = 0;

		return HAL_ERROR;
	} else {

		if (TMP117_readRegister(_addr, TMP117_EEPROM1, &data_buffer[0]) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
			return HAL_ERROR;
		}

		//data_buffer[0] = TMP117_readRegister(_addr, TMP117_EEPROM1);
	}

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		UsrLog("Error: TMP117_begin, device not found");

		data_buffer[1] = 0;

		return HAL_ERROR;
	} else {

		if (TMP117_readRegister(_addr, TMP117_EEPROM2, &data_buffer[1]) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
			return HAL_ERROR;
		}

		//data_buffer[1] = TMP117_readRegister(_addr, TMP117_EEPROM2);
	}

	if (HAL_I2C_IsDeviceReady(_i2cPort, _addr, 2, 5) != HAL_OK) {
		UsrLog("Error: TMP117_begin, device not found");

		data_buffer[2] = 0;

		return HAL_ERROR;
	} else {

		if (TMP117_readRegister(_addr, TMP117_EEPROM3, &data_buffer[2]) != HAL_OK) { // Calls to read registers to pull all the bits to store in an array
			return HAL_ERROR;
		}

		//data_buffer[2] = TMP117_readRegister(_addr, TMP117_EEPROM3);
	}

	return HAL_OK;
}

void TMP117_get_hex_id(uint8_t *sensor_ID, char *str_buff) {
	sprintf(str_buff, "%02X%02X%02X%02X%02X%02X%02X", (uint8_t) sensor_ID[0],
			(uint8_t) sensor_ID[1], (uint8_t) sensor_ID[2],
			(uint8_t) sensor_ID[3], (uint8_t) sensor_ID[4],
			(uint8_t) sensor_ID[5], (uint8_t) sensor_ID[6]);
}

void TMP117_b64_id(uint8_t *sensor_ID, char *str_buff) {
	int64_t sens_ID = 0;

	// Without sensor_ID[0]: 0x00:

	sens_ID = sensor_ID[7]; // 0x17
	sens_ID += sensor_ID[6] * 0x100;			// << 8
	sens_ID += sensor_ID[5] * 0x10000;			// << 16
	sens_ID += sensor_ID[4] * 0x1000000;		// << 24
	sens_ID += sensor_ID[3] * 0x100000000;		// << 32
	sens_ID += sensor_ID[2] * 0x10000000000;	// << 40
	sens_ID += sensor_ID[1] * 0x1000000000000;	// << 48

//	UsrLog("sensor_ID: %02X %02X %02X %02X %02X %02X %02X",
//			sensor_ID[1], sensor_ID[2], sensor_ID[3],
//			sensor_ID[4], sensor_ID[5], sensor_ID[6],
//			sensor_ID[7]);

//	UsrLog("sens_ID:");

//	char str_buff2[32];
//
//	print_int64(sens_ID, str_buff2);
//	UsrLog("TMP117_b64_id: sens_ID = %s", str_buff2);

	conv_b10_b64(sens_ID, str_buff);

//	UsrLog("TMP117_b64_id: str_buff(64) = %s", str_buff);

//	int64_t tmp_sens_ID = 0;

//	tmp_sens_ID = conv_b64_b10(str_buff);

//	print_int64(tmp_sens_ID, str_buff2);
//	UsrLog("TMP117_b64_id: tmp_sens_ID = %s", str_buff2);
//
//	uint8_t sensor_ID_tmp[9] = { 0 };
//	int64_t calc1 = 0;
//
//	sensor_ID_tmp[0] = 48; // 0
//
//	sensor_ID_tmp[1] = tmp_sens_ID / (int64_t) 0x1000000000000;
//	calc1 = (int64_t) 0x1000000000000 * (int64_t) sensor_ID_tmp[1];
//	tmp_sens_ID = tmp_sens_ID - calc1;
//
//	sensor_ID_tmp[2] = tmp_sens_ID / (int64_t) 0x10000000000;
//	calc1 = (int64_t) 0x10000000000 * (int64_t) sensor_ID_tmp[2];
//	tmp_sens_ID = tmp_sens_ID - calc1;
//
//	sensor_ID_tmp[3] = tmp_sens_ID / (int64_t) 0x100000000;
//	calc1 = (int64_t) 0x100000000 * (int64_t) sensor_ID_tmp[3];
//	tmp_sens_ID = tmp_sens_ID - calc1;
//
//	sensor_ID_tmp[4] = tmp_sens_ID / 0x1000000;
//	calc1 = (int64_t) 0x1000000 * (int64_t) sensor_ID_tmp[4];
//	tmp_sens_ID = tmp_sens_ID - calc1;
//
//	sensor_ID_tmp[5] = tmp_sens_ID / 0x10000;
//	calc1 = (int64_t) 0x10000 * (int64_t) sensor_ID_tmp[5];
//	tmp_sens_ID = tmp_sens_ID - calc1;
//
//	sensor_ID_tmp[6] = tmp_sens_ID / 0x100;
//	calc1 = (int64_t) 0x100 * (int64_t) sensor_ID_tmp[6];
//	tmp_sens_ID = tmp_sens_ID - calc1;
//
//	sensor_ID_tmp[7] = tmp_sens_ID;
//
//	UsrLog("sensor_ID_tmp: %02X %02X %02X %02X %02X %02X %02X",
//			sensor_ID_tmp[1], sensor_ID_tmp[2], sensor_ID_tmp[3],
//			sensor_ID_tmp[4], sensor_ID_tmp[5], sensor_ID_tmp[6],
//			sensor_ID_tmp[7]);
}
