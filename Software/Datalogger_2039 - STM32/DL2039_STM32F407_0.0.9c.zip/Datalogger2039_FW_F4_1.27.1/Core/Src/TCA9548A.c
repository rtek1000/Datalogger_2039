/*
 * TCA9548A.c
 *
 *  Created on: 2 de ago de 2023
 *      Author: user
 */

#include "TCA9548A.h"
#include "TMP117.h"

#define NumOfSensors maxChannel

float TMP117_fData[NumOfSensors] = { 0 };

const uint8_t TCA9548A_Addr = 0xE0; // 0x70 << 1
extern const uint8_t TMP117_Addr; // 0x48 << 1
extern I2C_HandleTypeDef hi2c3;

I2C_HandleTypeDef *TCA9548A_I2C_upstream = &hi2c3;

HAL_StatusTypeDef TCA9548A_select_port(uint8_t _I2C_downstream_port) {
	uint8_t pData[1] = { 1 << _I2C_downstream_port }; // select 1 of 8
	uint8_t pDataSize = 1;
	uint32_t Timeout = 10;

	if (HAL_I2C_IsDeviceReady(TCA9548A_I2C_upstream, TCA9548A_Addr, 2, 5)
			!= HAL_OK) {
		UsrLog("Error: TCA9548A_select_port, device not found");
	} else {
		//UsrLog("TCA9548A found");

		if (HAL_I2C_Master_Transmit(TCA9548A_I2C_upstream, TCA9548A_Addr, pData,
							pDataSize, Timeout) == HAL_OK) {
			return HAL_OK;
		}
	}

	return HAL_ERROR;
}

