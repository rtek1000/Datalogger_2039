/*
 * t-rex.h
 *
 *  Created on: 23 de nov de 2023
 *      Author: user
 */

#ifndef SRC_GAME1_T_REX_H_
#define SRC_GAME1_T_REX_H_

void game_t_rex_keyboard(void);
void game_t_rex_init(void);
void game_t_rex_run(void);


#endif /* SRC_GAME1_T_REX_H_ */
