/*
 *
 * t-rex game
 *
 */

#include "ILI9341.h"
#include "usbh_hid_keybd.h"

uint32_t game1_score = 0;

uint32_t game1_score_tick1 = 0;

uint8_t game1_score_tick2 = 0;

uint32_t game1_run_tick1 = 0;

int16_t horizontal_position = 0;

uint8_t vertical_position = 200;
uint8_t vertical_position_prev = 0;

uint8_t jump_cmd = 0;

uint16_t cmd_timeout = 0;

uint8_t game1_exit = 0;

const uint8_t t_rex_h = 46;
const uint8_t t_rex_w = 32;

const uint8_t t_rex_px = 20;

const uint8_t obj1_h = 26;
const uint8_t obj1_w = 16;
const uint8_t obj1_py = 200;

const uint8_t t_rex_py1 = obj1_py - (t_rex_h - obj1_h);
const uint8_t t_rex_py2 = t_rex_py1 - t_rex_h;

volatile uint8_t game1_keybd_info;

extern char str[2048];

extern int lcd_screen;

extern uint8_t screen_first_load;

extern uint8_t lcd_refresh;

extern USBH_HandleTypeDef hUsbHostFS;

extern void IWDG_reset(void);

extern void MX_USB_HOST_Process_FS(void);

extern USBH_StatusTypeDef USBH_Process(USBH_HandleTypeDef *phost);

void game_t_rex_keyboard(void) {
	uint8_t key = game1_keybd_info;
	//uint8_t keycode = keybd_info_lcd.key_ascii;

	if (key == KEY_UPARROW) {
		jump_cmd = 1;

		cmd_timeout = 500;
	} else if (key == KEY_DOWNARROW) {
		//game1_score--;
	} else if (key == 0x00) {
		cmd_timeout = 0;
	} else if (key == KEY_ESCAPE) {
		game1_exit = 1;
	}

	game1_keybd_info = 0xFF;
}

void game_t_rex_init(void) {

}

void game_t_rex_run(void) {
	while (game1_exit == 0) {
		//MX_USB_HOST_Process_FS();
		USBH_Process(&hUsbHostFS);

		//HAL_Delay(1);

		if((HAL_GetTick() - game1_run_tick1) > 0) {
			game1_run_tick1 = HAL_GetTick();

			IWDG_reset();

			game_t_rex_keyboard();

			if ((HAL_GetTick() - game1_score_tick1) >= 100) {
				game1_score_tick1 = HAL_GetTick();

				if (game1_score_tick2 == 0) {
					game1_score_tick2 = 1;

					uint32_t game1_score_tmp = game1_score / 100;

					// uint16_t max: 0xFFFF
					if (game1_score_tmp > 0xFFFF) {
						game1_score_tmp = 0;

						game1_score = 0;
					}

					sprintf(str, "Score: %05lu", game1_score_tmp);
				} else {
					game1_score_tick2 = 0;

					// 319 - (12x 16px) = 127
					ILI9341_WriteString(127, 0, str, Font_16x26,
					ILI9341_BLUE, ILI9341_BLACK);
				}
			}

			if (jump_cmd == 1) {
				// Image erasure
				ILI9341_DrawLineV(horizontal_position + obj1_w, 200, obj1_h,
				ILI9341_BLACK);

				if (vertical_position_prev != 0) {
					ILI9341_FillRect(t_rex_px, vertical_position_prev, t_rex_w,
							t_rex_h,
							ILI9341_BLACK);

					vertical_position_prev = 0;
				}
			} else {
				if (((horizontal_position + obj1_w) >= (t_rex_px + t_rex_w))
						|| ((horizontal_position + obj1_w) < t_rex_px)) {
					// Image erasure
					ILI9341_DrawLineV(horizontal_position + obj1_w, 200, obj1_h,
					ILI9341_BLACK);
				}

				if (vertical_position_prev != 0) {
					ILI9341_FillRect(t_rex_px, vertical_position_prev, t_rex_w,
							t_rex_h,
							ILI9341_BLACK);

					vertical_position_prev = 0;
				}
			}

			if (horizontal_position > -16) {
				horizontal_position--;
			} else {
				horizontal_position = 319;
			}

			if (cmd_timeout > 0) {
				cmd_timeout--;
			} else {
				jump_cmd = 0;
			}

			if (jump_cmd == 1) {
				if (horizontal_position >= 0) {
					// Image creation
					ILI9341_DrawLineV(horizontal_position, obj1_py, obj1_h,
					ILI9341_GREEN);
				}

				if (vertical_position != t_rex_py2) {
					vertical_position_prev = vertical_position;

					vertical_position = t_rex_py2;

					ILI9341_FillRect(t_rex_px, vertical_position, t_rex_w, t_rex_h,
					ILI9341_ORANGE);
				}
			} else {
				if ((horizontal_position >= (t_rex_px + t_rex_w))
						|| (horizontal_position < t_rex_px)) {
					if (horizontal_position >= 0) {
						// Image creation
						ILI9341_DrawLineV(horizontal_position, obj1_py, obj1_h,
						ILI9341_GREEN);
					}
				}

				if (vertical_position != t_rex_py1) {
					vertical_position_prev = vertical_position;

					vertical_position = t_rex_py1;

					ILI9341_FillRect(t_rex_px, vertical_position, t_rex_w, t_rex_h,
					ILI9341_ORANGE);
				}
			}

			game1_score++;
		}
	}

	if (game1_exit != 0) {
		game1_exit = 0;

		lcd_screen = LcdScreenMain;

		screen_first_load = 1;

		lcd_refresh = 3;
	}
}

