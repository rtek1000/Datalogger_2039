/*
 * TCA9548A.h
 *
 *  Created on: 2 de ago de 2023
 *      Author: user
 */

#ifndef INC_TCA9548A_H_
#define INC_TCA9548A_H_

#include "main.h"

HAL_StatusTypeDef TCA9548A_select_port(uint8_t _port);

#endif /* INC_TCA9548A_H_ */
