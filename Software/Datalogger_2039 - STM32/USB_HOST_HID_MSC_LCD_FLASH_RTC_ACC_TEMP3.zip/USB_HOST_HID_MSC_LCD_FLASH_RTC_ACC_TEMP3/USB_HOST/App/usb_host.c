/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file            : usb_host.c
 * @version         : v1.0_Cube
 * @brief           : This file implements the USB Host
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under Ultimate Liberty license
 * SLA0044, the "License"; You may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 *                             www.st.com/SLA0044
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "usb_host.h"
#include "usbh_core.h"
#include "usbh_msc.h"
#include "usbh_hid.h"

/* USER CODE BEGIN Includes */
#include "DS3231.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "fatfs.h"
#include "ILI9341.h"
#include "SCREEN.h"
#include "usbh_hid_keybd.h"
#include "EEPROM_EXTERN.h"
#include "BMP_to_USB.h"
#include "num_base_64.h"
//#include "language.h"

/* USER CODE END Includes */

/* USER CODE BEGIN PV */

/*
 //#define  UsrLog(...)   do { \
//		printf(__VA_ARGS__); \
//		printf("\r\n"); \
//} while (0)
 */

/* Private variables ---------------------------------------------------------*/
//#define hide_using_base64 1
#define hide_index 1
#define compact_using_num_base_64 1
//#define compact_using_num_base_16 1
#define output_dat_file 1

#define sepChr 59  	// 9: horizontal tab "	", 59: char ";"
#define degChr '*' //42 	// deg symbol "°"

#define lcd_bright_max 1023
#define lcd_bright_min 100

#define KEY_CAPS_LOCK                          0x39
#define KEY_SCROLL_LOCK                        0x47

#define grave_accent 96
#define acute_accent 180
#define circumflex_accent 94
#define tilde_accent 126
#define diaeresis_accent 168

#define A_grave_accent 192
#define A_acute_accent 193
#define A_circumflex_accent 194
#define A_tilde_accent 195
#define A_diaeresis_accent 196

#define C_cedil 199

#define E_grave_accent 200
#define E_acute_accent 201
#define E_circumflex_accent 202
#define E_diaeresis_accent 203

#define I_grave_accent 204
#define I_acute_accent 205
#define I_circumflex_accent 206
#define I_diaeresis_accent 207

#define O_grave_accent 210
#define O_acute_accent 211
#define O_circumflex_accent 212
#define O_tilde_accent 213
#define O_diaeresis_accent 214

#define U_grave_accent 217
#define U_acute_accent 218
#define U_circumflex_accent 219
#define U_diaeresis_accent 220

#define a_grave_accent 224
#define a_acute_accent 225
#define a_circumflex_accent 226
#define a_tilde_accent 227
#define a_diaeresis_accent 228

#define c_cedil 231

#define e_grave_accent 232
#define e_acute_accent 233
#define e_circumflex_accent 234
#define e_diaeresis_accent 235

#define i_grave_accent 236
#define i_acute_accent 237
#define i_circumflex_accent 238
#define i_diaeresis_accent 239

#define o_grave_accent 242
#define o_acute_accent 243
#define o_circumflex_accent 244
#define o_tilde_accent 245
#define o_diaeresis_accent 246

#define u_grave_accent 249
#define u_acute_accent 250
#define u_circumflex_accent 251
#define u_diaeresis_accent 252

HID_KEYBD_Info_TypeDef *keybd_info1;
int keyboard_timeout_reset = 5; // 5
int keyboard_timeout = 0; // 60
int keyboard_timeout2 = 0;  // 60
int usb_pwr_off_timeout = 0;

int usb_power_restart_timeout = 0;
int usb_power_restart_count = 0;
int usb_power_recycle_count = 0;

int keyboard_status = 0;
int keyboard_status2 = 0;

uint8_t caps_lock_state = 0;
uint8_t key_insert_accent = FALSE;

//int accent1 = 0;
uint8_t key_grave_accent = FALSE;
uint8_t key_acute_accent = FALSE;
uint8_t key_circumflex_accent = FALSE;
uint8_t key_tilde_accent = FALSE;
uint8_t key_diaeresis_accent = FALSE;

uint8_t keyboard_insert = FALSE;

uint32_t enumTimeout = 0;

uint32_t progress_remaining = 0;
uint8_t progress_usb_export = 0; // 0-10
uint8_t progress_usb_export_old = 0; // 0-10
uint32_t progress_tick = 0;

uint32_t usb_write_data_steps = 0;
//uint32_t usb_read_data_steps = 0;
uint8_t export_data_step = 0;
uint8_t export_in_progress = 0;
uint8_t export_error = 0;

//uint8_t save_BMP_in_progress = 0;
uint8_t save_BMP_error = 0;

const uint8_t HID_KEYBRD_Codes_Custom[] = { 0, 0, 0, 0, 31, 50, 48, 33, 19, 34,
		35, 36, 24, 37, 38, 39, /* 0x00 - 0x0F */
		52, 51, 25, 26, 17, 20, 32, 21, 23, 49, 18, 47, 22, 46, 2, 3, /* 0x10 - 0x1F */
		4, 5, 6, 7, 8, 9, 10, 11, 43, 110, 15, 16, 61, 12, 13, 27, /* 0x20 - 0x2F */
		28, 29, 42, 40, 41, 1, 53, 54, 55, 30, 112, 113, 114, 115, 116, 117, /* 0x30 - 0x3F */
		118, 119, 120, 121, 122, 123, 124, 125, 126, 75, 80, 85, 76, 81, 86, 89, /* 0x40 - 0x4F */
		79, 84, 83, 90, 95, 100, 105, 106, 108, 93, 98, 103, 92, 97, 102, 91, /* 0x50 - 0x5F */
		96, 101, 99, 104, 45, 129, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x60 - 0x6F */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x70 - 0x7F */
		0, 0, 0, 0, 0, 107, 0, 56, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x80 - 0x8F */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x90 - 0x9F */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xA0 - 0xAF */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xB0 - 0xBF */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xC0 - 0xCF */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0xD0 - 0xDF */
		58, 44, 60, 127, 64, 57, 62, 128 /* 0xE0 - 0xE7 */
};

static const uint8_t HID_KEYBRD_Key_Custom[] = { '\0', '\'', '1', '2', '3', '4',
		'5', '6', '7', '8', '9', '0', '-', '=', '\0', '\r', '\t', 'q', 'w', 'e',
		'r', 't', 'y', 'u', 'i', 'o', 'p', acute_accent, '[',
		']',		// 180:´
		'\0', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', c_cedil,
		tilde_accent, '\0',
		'\n',					// 231:ç 94:^
		'\0', '\0', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', ';', '\0',
		'\0', '\0', '\0', '\0', ' ', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\r',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '7', '4',
		'1', '\0', '/', '8', '5', '2', '0', '*', '9', '6', '3', '.', '-', '+',
		'\0', '\n', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' };

const uint8_t HID_KEYBRD_ShiftKey_Custom[] = { '\0', '\"', '!', '@', '#', '$',
		'%', '^', '&', '*', '(', ')', '_', '+', '\0', '\0', '\0', 'Q', 'W', 'E',
		'R', 'T', 'Y', 'U', 'I', 'O', 'P', grave_accent, '{', '}', '\0', 'A',
		'S', 'D', 'F',
		'G',			// 96:`
		'H', 'J', 'K', 'L', C_cedil, circumflex_accent, '\0', '\n', '\0', '\0',
		'Z',
		'X',		// 199:Ç 126:~
		'C', 'V', 'B', 'N', 'M', '<', '>', ':', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0',
		'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' };

FATFS USBDISKFatHs; /* File system object for USB disk logical drive */
FIL MyFile; /* File object */
char USBDISKPath[4] = { 48, 58, 47, 0 }; /* USB Host logical drive path */
USBH_HandleTypeDef hUSB_Host; /* USB Host handle */

uint8_t kbd_LED_status[1] = { 0B001 }; // kbd_num_lock_state = 1
uint8_t kbd_LED_status_old = 0;
uint32_t keyboard_led_status_tick = 0;
uint8_t kbd_num_lock_state = 1;
uint8_t kbd_scroll_lock_state = 0;

uint32_t userFunction_tick = 0;
uint32_t userFunction_phase = 0;
uint32_t userFunction_index1 = 0;
//uint32_t bytesread = 0;
//uint32_t byteswrote = 0;
uint32_t line_count = 0;
//int32_t j = 0;
uint32_t br = 0;
uint32_t highest_cnt = 0;
uint32_t abort_operation = 0;

uint8_t export_date = 0;
uint8_t export_month = 0;
uint8_t export_year = 0;
uint8_t export_hours = 0;
uint8_t export_minutes = 0;

uint32_t ch_mark_cnt_export[maxChannel];

uint8_t esc_cnt = 0;

uint8_t ctrl_atl_del_cnt = 0;
uint8_t ctrl_atl_del_restart = 0;
uint8_t ctrl_atl_del_timeout = 0;

/* USER CODE END PV */

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
USBH_StatusTypeDef USB_Set_Keyboard_LED_Status(uint8_t *LED_status);

USBH_StatusTypeDef DeInitStateMachine(USBH_HandleTypeDef *phost);
USBH_StatusTypeDef USBH_HandleEnum(USBH_HandleTypeDef *phost);

FRESULT set_timestamp(char *obj); /* Pointer to the file name */
FRESULT file_exists(char *filename);
void MX_USB_HOST_Process_HS(void);
void MX_USB_HOST_Process_FS(void);
void keyboardMain(HID_KEYBD_Info_TypeDef *keybd_info);

uint8_t userFunctionExport(void);
HAL_StatusTypeDef save_BMP_Export(void);
HAL_StatusTypeDef save_BMP_function(void);
void get_data_header(void);
void get_data_header2(void);
void replace_char(char *char_array, uint8_t find, uint8_t replace);
void get_data(uint32_t posit);
uint8_t userFunction(void);
void update_exported_data(void);

extern uint8_t file_type;
extern uint16_t file_cnt_csv;
extern uint16_t file_cnt_dat;

extern uint8_t language_current;

extern uint8_t decimal_separator;

extern uint32_t uC_ID[3];
extern uint8_t MEM_ID[8];

extern int cnt_timeout_reset_USB;
extern uint8_t temperature_unit;
extern uint8_t date_format;
extern uint32_t read_data_steps;
//extern char str[80];
//uint16_t max_index_tab_desc_event = 256;
//extern uint32_t ch_mark_cnt[maxChannel];
extern int ch_status[maxChannel];
extern uint8_t export_ch[maxChannel];
extern DadaStruct3_TypeDef canal_header[maxChannel];

extern uint32_t sizeof_array(const char *input);
extern void BASE64_encode(const char *input, char *output);
extern void beep(uint8_t repetions);
extern void BMP_to_USB_header(uint8_t *header_buf);
extern float DS18B20_celsius_to_fahrenheit(float celsius);
extern USBH_StatusTypeDef USBH_HandleEnum(USBH_HandleTypeDef *phost);
//extern USBH_StatusTypeDef  DeInitStateMachine(USBH_HandleTypeDef *phost);
//extern void lcd_config_ch_label(void);
extern void lcd_menu_keyboard(HID_KEYBD_Info_TypeDef *keybd_info);
extern void user_pwm_setvalue(uint16_t value);
extern void lcd_config_clock_load(void);
extern uint8_t lcd_progress_bar(void);
extern uint8_t lcd_progress_barX10(void);

extern USBH_StatusTypeDef DeInitStateMachine(USBH_HandleTypeDef *phost);
extern USBH_StatusTypeDef USBH_ReEnumerate(USBH_HandleTypeDef *phost);

USBH_HandleTypeDef hUsbHostHS;
USBH_HandleTypeDef hUsbHostFS;
ApplicationTypeDef Appli_state_HS = APPLICATION_IDLE;
ApplicationTypeDef Appli_state_FS = APPLICATION_IDLE;
/* USER CODE END PFP */

/* USB Host core handle declaration */
//USBH_HandleTypeDef hUsbHostHS;
//USBH_HandleTypeDef hUsbHostFS;
ApplicationTypeDef Appli_state = APPLICATION_IDLE;

/*
 * -- Insert your variables declaration here --
 */
/* USER CODE BEGIN 0 */
#define NumOfSensors 8
extern DS18B20_TypeDef SENSORS[NumOfSensors];
extern uint32_t ch_mark_cnt[maxChannel];
extern const uint16_t lcd_timeout0recall;
extern const uint16_t lcd_timeout0recall2;
extern uint8_t button1_stage;

extern uint8_t lcd_timeout0;
extern uint8_t lcd_restart;
//extern uint32_t datacsv0_size;
extern int keyboard_timeout_reset;
extern bool lcd_enabled;
//extern bool clock1_setup;
extern DS3231_Time_t clock1;
extern int clock_index_edit_mode;
//extern bool key_insert_accent;

//extern bool keyboard_insert;
extern int ch_config_index;
//extern int keyboard_status;
extern int keyboard_timeout;
extern int keyboard_timeout2;

uint8_t uart_tx_buffer[100];
extern HID_MOUSE_Info_TypeDef mouse_info;
//extern void keyboardMain(uint8_t key);
extern bool USB_FS_restart;
extern int lcd_screen;
extern int label_index_edit;
extern int label_index_edit2;

extern char channelLabel[maxChannel][57];
extern uint8_t lcd_refresh;
extern int menu_button;
extern uint8_t timeout0;
//extern bool standby_mode;

extern int lcd_bright_set;
//extern bool lcd_restart;
extern int lcd_bright_new;
extern const uint16_t dataColorRecall[maxChannel];
extern uint16_t dataColor[maxChannel];
extern uint8_t channelSelected;
extern int start_MSC_Application1;
extern int start_MSC_Application2;
extern uint32_t cnt0;
extern uint32_t cnt1;
//extern bool caps_lock_state;
//extern const int maxChar;

extern const uint8_t HID_KEYBRD_ShiftKey[];
extern const uint8_t HID_KEYBRD_Codes[];

extern int accent1;
//extern const float datacsv0[];
//extern float get_data0(uint32_t addr);

extern int clock_index_edit;
extern uint8_t standby_mode;

extern uint8_t save_BMP_enabled;
extern uint8_t save_BMP_step;
extern uint8_t save_BMP_phase;

extern uint8_t export_data_enabled;
//extern uint32_t cnt0;
//extern uint32_t cnt1;
extern DS3231_Time_t tm1;

extern uint8_t ch_exported[8];

/* USER CODE END 0 */

/*
 * user callback declaration
 */
static void USBH_UserProcess1(USBH_HandleTypeDef *phost, uint8_t id);
static void USBH_UserProcess2(USBH_HandleTypeDef *phost, uint8_t id);

/*
 * -- Insert your external function declaration here --
 */
/* USER CODE BEGIN 1 */
USBH_StatusTypeDef USB_Set_Keyboard_LED_Status(uint8_t *LED_status) {
	if (kbd_LED_status_old == kbd_LED_status[0]) {
		return HAL_OK;
	}

	kbd_LED_status_old = LED_status[0];

	uint8_t kbd_led[2] = { 0x00, 0x00 };

	USBH_StatusTypeDef ret = HAL_BUSY;
	USBH_StatusTypeDef ret2 = HAL_OK;

	kbd_led[0] = LED_status[0] & 7;

	for (uint8_t timeout = 0; timeout < 15; timeout++) {
		ret = USBH_HID_SetReport(&hUsbHostFS, 0x02U, 0U, kbd_led,
				sizeof(kbd_led));

		//UsrLog("USBH_HID_SetReport return: %d", ret);
		IWDG_delay_ms(1);

		if (ret == ret2) {
			break;
		}
	}

	for (uint8_t timeout = 0; timeout < 15; timeout++) {
		ret = USBH_HID_GetReport(&hUsbHostFS, 0x02U, 0U, kbd_led,
				sizeof(kbd_led));

		//UsrLog("USBH_HID_GetReport return: %d; kbd_led: %d", ret, kbd_led[0]);
		IWDG_delay_ms(1);

		if (ret == ret2) {
			break;
		}
	}

	if (kbd_led[0] == (LED_status[0] & 7)) {
		ret = HAL_OK;
	} else {
		ret = HAL_ERROR;
	}

	LED_status[0] = kbd_led[0];

	if ((kbd_LED_status[0] & 1) == 1) {
		kbd_num_lock_state = 1;
	} else {
		kbd_num_lock_state = 0;
	}

	if (((kbd_LED_status[0] >> 1) & 1) == 1) {
		caps_lock_state = 1;
	} else {
		caps_lock_state = 0;
	}

	if (((kbd_LED_status[0] >> 2) & 1) == 1) {
		kbd_scroll_lock_state = 1;
	} else {
		kbd_scroll_lock_state = 0;
	}

	return ret;
}

uint8_t USBH_HID_GetASCIICode_Custom(HID_KEYBD_Info_TypeDef *info) {
	uint8_t output = 0;
	if ((info->lshift == 1U) || (info->rshift)) {
		output =
				HID_KEYBRD_ShiftKey_Custom[HID_KEYBRD_Codes_Custom[info->keys[0]]];
	} else if (info->ralt == 1U) {
		USBH_UsrLog("AltGr");

		if (info->keys[0] == KEY_W) {
			output = '?';
		} else if (info->keys[0] == KEY_Q) {
			output = '/';
		}
	} else {
		if (caps_lock_state == true) {
			USBH_UsrLog("caps_lock_state = true");
			if ((info->keys[0] >= KEY_A) & (info->keys[0] <= KEY_Z)) {
				USBH_UsrLog("(info->keys[0] >= 65) & (info->keys[0] <= 90)");
				output =
						HID_KEYBRD_ShiftKey_Custom[HID_KEYBRD_Codes_Custom[info->keys[0]]];
			} else {
				output =
						HID_KEYBRD_Key_Custom[HID_KEYBRD_Codes_Custom[info->keys[0]]];
			}
		} else {
			output =
					HID_KEYBRD_Key_Custom[HID_KEYBRD_Codes_Custom[info->keys[0]]];
		}
	}
	return output;
}

void keyboardMain(HID_KEYBD_Info_TypeDef *keybd_info) {
//	uint8_t keycode = 0;

	uint8_t key = keybd_info->keys[0];

//	keycode = USBH_HID_GetASCIICode_Custom(keybd_info);

//kbd_LED_status = key;

//	UsrLog("key: 0x%02X", key);
//	UsrLog("0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x", keybd_info->keys[0],
//			keybd_info->keys[1], keybd_info->keys[2], keybd_info->keys[3],
//			keybd_info->keys[4], keybd_info->keys[5]);

	cnt_timeout_reset_USB = 0;

	if (key == KEY_INSERT) {
		keyboard_insert = !keyboard_insert;
	} else if (key != 0) {
		usb_power_recycle_count = 0;

		if (HAL_GPIO_ReadPin(AC_DC_STATE_GPIO_Port, AC_DC_STATE_Pin)
				== GPIO_PIN_SET) {
			lcd_timeout0 = lcd_timeout0recall2;
		} else {
			lcd_timeout0 = lcd_timeout0recall;
		}

		if (standby_mode == true) {
			standby_mode = false;

			lcd_restart = true;

			lcd_bright_set = lcd_bright_max;
			//			user_pwm_setvalue(lcd_bright_max);
		} else {
			button1_stage = ScreenAutoDimm;

			lcd_bright_set = lcd_bright_max;
		}

		Appli_state_FS = APPLICATION_READY;

		lcd_menu_keyboard(keybd_info);

		keyboard_timeout_reset = 5;

		keyboard_timeout = 60;

		keyboard_timeout2 = 60;
	} else if (key == 0) {
		//if (lcd_refresh == 0xFF) {
//			lcd_refresh = 3;
		//}

		if (start_MSC_Application1 == 1) {
			start_MSC_Application1 = 2;
		} else if (start_MSC_Application2 == 1) {
			start_MSC_Application2 = 2;
		}

		keyboard_timeout = 60;
		//keyboard_status = 3;
	}

	cnt0 = 0;
	cnt1 = 0;

	keyboard_timeout_reset = 5;
}

USBH_StatusTypeDef USBH_HandleEnum(USBH_HandleTypeDef *phost) {
	USBH_StatusTypeDef Status = USBH_BUSY;

	switch (phost->EnumState) {
	case ENUM_IDLE:
		/* Get Device Desc for only 1st 8 bytes : To get EP0 MaxPacketSize */
		if (USBH_Get_DevDesc(phost, 8U) == USBH_OK) {
			phost->Control.pipe_size = phost->device.DevDesc.bMaxPacketSize;

			phost->EnumState = ENUM_GET_FULL_DEV_DESC;

			/* modify control channels configuration for MaxPacket size */
			USBH_OpenPipe(phost, phost->Control.pipe_in, 0x80U,
					phost->device.address, phost->device.speed,
					USBH_EP_CONTROL, (uint16_t) phost->Control.pipe_size);

			/* Open Control pipes */
			USBH_OpenPipe(phost, phost->Control.pipe_out, 0x00U,
					phost->device.address, phost->device.speed,
					USBH_EP_CONTROL, (uint16_t) phost->Control.pipe_size);

		}
		break;

	case ENUM_GET_FULL_DEV_DESC:
		/* Get FULL Device Desc  */
		if (USBH_Get_DevDesc(phost, USB_DEVICE_DESC_SIZE) == USBH_OK) {
			USBH_UsrLog("PID: %xh", phost->device.DevDesc.idProduct);
			USBH_UsrLog("VID: %xh", phost->device.DevDesc.idVendor);

			phost->EnumState = ENUM_SET_ADDR;

		}
		break;

	case ENUM_SET_ADDR:
		/* set address */
		if (USBH_SetAddress(phost, USBH_DEVICE_ADDRESS) == USBH_OK) {
			USBH_Delay(2U);
			phost->device.address = USBH_DEVICE_ADDRESS;

			/* user callback for device address assigned */
			USBH_UsrLog("Address (#%d) assigned.", phost->device.address);
			phost->EnumState = ENUM_GET_CFG_DESC;

			/* modify control channels to update device address */
			USBH_OpenPipe(phost, phost->Control.pipe_in, 0x80U,
					phost->device.address, phost->device.speed,
					USBH_EP_CONTROL, (uint16_t) phost->Control.pipe_size);

			/* Open Control pipes */
			USBH_OpenPipe(phost, phost->Control.pipe_out, 0x00U,
					phost->device.address, phost->device.speed,
					USBH_EP_CONTROL, (uint16_t) phost->Control.pipe_size);
		}
		break;

	case ENUM_GET_CFG_DESC:
		/* get standard configuration descriptor */
		if (USBH_Get_CfgDesc(phost,
		USB_CONFIGURATION_DESC_SIZE) == USBH_OK) {
			phost->EnumState = ENUM_GET_FULL_CFG_DESC;
		}
		break;

	case ENUM_GET_FULL_CFG_DESC:
		/* get FULL config descriptor (config, interface, endpoints) */
		if (USBH_Get_CfgDesc(phost, phost->device.CfgDesc.wTotalLength)
				== USBH_OK) {
			phost->EnumState = ENUM_GET_MFC_STRING_DESC;
		}
		break;

	case ENUM_GET_MFC_STRING_DESC:
		if (phost->device.DevDesc.iManufacturer != 0U) { /* Check that Manufacturer String is available */

			if (USBH_Get_StringDesc(phost, phost->device.DevDesc.iManufacturer,
					phost->device.Data, 0xFFU) == USBH_OK) {
				/* User callback for Manufacturing string */
				USBH_UsrLog("Manufacturer : %s",
						(char *)(void*)phost->device.Data);
				phost->EnumState = ENUM_GET_PRODUCT_STRING_DESC;

#if (USBH_USE_OS == 1U)
				phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
				(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
				(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
			}
		} else {
			USBH_UsrLog("Manufacturer : N/A");
			phost->EnumState = ENUM_GET_PRODUCT_STRING_DESC;

#if (USBH_USE_OS == 1U)
			phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
			(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
			(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		}
		break;

	case ENUM_GET_PRODUCT_STRING_DESC:
		if (phost->device.DevDesc.iProduct != 0U) { /* Check that Product string is available */
			if (USBH_Get_StringDesc(phost, phost->device.DevDesc.iProduct,
					phost->device.Data, 0xFFU) == USBH_OK) {
				/* User callback for Product string */
				USBH_UsrLog("Product : %s", (char *)(void *)phost->device.Data);
				phost->EnumState = ENUM_GET_SERIALNUM_STRING_DESC;
			}
		} else {
			USBH_UsrLog("Product : N/A");
			phost->EnumState = ENUM_GET_SERIALNUM_STRING_DESC;

#if (USBH_USE_OS == 1U)
			phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
			(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
			(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		}
		break;

	case ENUM_GET_SERIALNUM_STRING_DESC:
		if (phost->device.DevDesc.iSerialNumber != 0U) { /* Check that Serial number string is available */
			if (USBH_Get_StringDesc(phost, phost->device.DevDesc.iSerialNumber,
					phost->device.Data, 0xFFU) == USBH_OK) {
				/* User callback for Serial number string */
				USBH_UsrLog("Serial Number : %s",
						(char *)(void*)phost->device.Data);
				Status = USBH_OK;
			}
		} else {
			USBH_UsrLog("Serial Number : N/A");
			Status = USBH_OK;

#if (USBH_USE_OS == 1U)
			phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
			(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
			(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		}
		break;

	default:
		break;
	}
	return Status;
}

#define USBH_ADDRESS_DEFAULT                     0x00U
#define USBH_ADDRESS_ASSIGNED                    0x01U
#define USBH_MPS_DEFAULT                         0x40U

USBH_StatusTypeDef DeInitStateMachine(USBH_HandleTypeDef *phost) {
	uint32_t i = 0U;

	/* Clear Pipes flags*/
	for (; i < USBH_MAX_PIPES_NBR; i++) {
		phost->Pipes[i] = 0U;
	}

	for (i = 0U; i < USBH_MAX_DATA_BUFFER; i++) {
		phost->device.Data[i] = 0U;
	}

	phost->gState = HOST_IDLE;
	phost->EnumState = ENUM_IDLE;
	phost->RequestState = CMD_SEND;
	phost->Timer = 0U;

	phost->Control.state = CTRL_SETUP;
	phost->Control.pipe_size = USBH_MPS_DEFAULT;
	phost->Control.errorcount = 0U;

	phost->device.address = USBH_ADDRESS_DEFAULT;
	phost->device.speed = USBH_SPEED_FULL;

	return USBH_OK;
}

uint32_t keyboardMain_debounce = 0;

void USBH_HID_EventCallback(USBH_HandleTypeDef *phost) {
	HID_HandleTypeDef *HID_Handle =
			(HID_HandleTypeDef*) phost->pActiveClass->pData;
	if (HID_Handle->Init == USBH_HID_KeybdInit) {
		keybd_info1 = USBH_HID_GetKeybdInfo(phost);

#if (KBD_LOG == 1U)
		if (lcd_screen != LcdScreenPassword) {
			UsrLog("0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x",
					keybd_info1->keys[0], keybd_info1->keys[1],
					keybd_info1->keys[2], keybd_info1->keys[3],
					keybd_info1->keys[4], keybd_info1->keys[5]); // USBH_DbgLog

			UsrLog(
					"lalt: %d, ralt: %d, lctrl: %d, rctrl: %d, lgui: %d, rgui: %d, lshift: %d, rshift: %d, state: %d",
					keybd_info1->lalt, keybd_info1->ralt, keybd_info1->lctrl,
					keybd_info1->rctrl, keybd_info1->lgui, keybd_info1->rgui,
					keybd_info1->lshift, keybd_info1->rshift,
					keybd_info1->state);
		}
#endif
		// ESC x20: RESTART
		if (keybd_info1->keys[0] == 0x29) {
			if (esc_cnt < 20) {
				esc_cnt++;
			} else {
				if (ctrl_atl_del_restart == 0) {
					ctrl_atl_del_restart = 1;

					if ((tm1.seconds > 5) && (tm1.seconds < 55)) {
						ctrl_atl_del_timeout = 0;
					} else {
						ctrl_atl_del_timeout = 10;
					}
				}
			}
		}

		// CTRL + ALT + DEL: RESTART
		if ((keybd_info1->keys[0] == 0x4c)
				&& ((keybd_info1->lalt == 1) || (keybd_info1->ralt == 1))
				&& ((keybd_info1->lctrl == 1) || (keybd_info1->rctrl == 1))) {

			if (ctrl_atl_del_cnt < 2) {
				ctrl_atl_del_cnt++;

				beep(ctrl_atl_del_cnt);
			} else {
				if (ctrl_atl_del_restart == 0) {
					ctrl_atl_del_restart = 1;

					if ((tm1.seconds > 5) && (tm1.seconds < 55)) {
						ctrl_atl_del_timeout = 0;
					} else {
						ctrl_atl_del_timeout = 10;
					}
				}
			}
		}
		//	cnt_esc_restart_timeout

		//HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);

		if (HAL_GetTick() > (keyboardMain_debounce + 100)) {
			keyboardMain_debounce = HAL_GetTick();

			uint8_t key = keybd_info1->keys[0];

			//	keycode = USBH_HID_GetASCIICode_Custom(keybd_info);

			//kbd_LED_status = key;

			//	UsrLog("key: 0x%02X", key);
//			UsrLog("0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x",
//					keybd_info->keys[0], keybd_info->keys[1],
//					keybd_info->keys[2], keybd_info->keys[3],
//					keybd_info->keys[4], keybd_info->keys[5]);

//			cnt_timeout_reset_USB = 0;

			if (key == KEY_INSERT) {
				keyboard_insert = !keyboard_insert;
			} else if (key == KEY_KEYPAD_NUM_LOCK_AND_CLEAR) {
				if ((kbd_LED_status[0] & 1) == 0) {
					kbd_LED_status[0] |= 0B001;
				} else {
					kbd_LED_status[0] &= 0B110;
				}

				UsrLog("kbd_LED_status %d", kbd_LED_status[0]);

				//		USB_Set_Keyboard_LED_Status();
			} else if (key == KEY_CAPS_LOCK) {
				if (((kbd_LED_status[0] >> 1) & 1) == 0) {
					kbd_LED_status[0] |= 0B010;
				} else {
					kbd_LED_status[0] &= 0B101;
				}

				UsrLog("kbd_LED_status %d", kbd_LED_status[0]);
			} else if (key == KEY_SCROLL_LOCK) {
				if (((kbd_LED_status[0] >> 2) & 1) == 0) {
					kbd_LED_status[0] |= 0B100;
				} else {
					kbd_LED_status[0] &= 0B011;
				}

				UsrLog("kbd_LED_status %d", kbd_LED_status[0]);
			} else {
				keyboardMain(keybd_info1);
			}
		}

	} else if (HID_Handle->Init == USBH_HID_MouseInit) {
		USBH_HID_GetMouseInfo(phost);

		USBH_DbgLog(
				"Mouse action: x=  0x%x, y=  0x%x, button1 = 0x%x, button2 = 0x%x, button3 = 0x%x \n",
				mouse_info.x, mouse_info.y, mouse_info.buttons[0],
				mouse_info.buttons[1], mouse_info.buttons[2]);
	}
}

USBH_StatusTypeDef USBH_HID_InterfaceCheck(USBH_HandleTypeDef *phost) {
	/*Decode Bootclass Protocol: Mouse or Keyboard*/
	if (phost->device.CfgDesc.Itf_Desc[phost->device.current_interface].bInterfaceProtocol
			== HID_KEYBRD_BOOT_CODE) {
		USBH_UsrLog("InterfaceCheck: KeyBoard device found!");
		return USBH_OK;
	} else if (phost->device.CfgDesc.Itf_Desc[phost->device.current_interface].bInterfaceProtocol
			== HID_MOUSE_BOOT_CODE) {
		USBH_UsrLog("InterfaceCheck: Mouse device found!");
		return USBH_OK;
	} else {
		USBH_UsrLog("InterfaceCheck: Protocol not supported.");
		return USBH_FAIL;
	}
}

USBH_StatusTypeDef USBH_FS_Restart(void) {
	USBH_UsrLog("USBH_FS_Restart");

//	HAL_Delay(500);
//USBH_LL_ResetPort(&hUsbHostFS);

	HAL_GPIO_WritePin(USB_FS_PWR_GPIO_Port, USB_FS_PWR_Pin, GPIO_PIN_SET); // USB Off

	if (USBH_Stop(&hUsbHostFS) != USBH_OK) {
		Error_Handler();
	}

	if (USBH_RegisterClass(&hUsbHostFS, USBH_HID_CLASS) != USBH_OK) {
		Error_Handler();
	}

	if (USBH_DeInit(&hUsbHostFS) != USBH_OK) {
		Error_Handler();
	}

	if (USBH_Init(&hUsbHostFS, USBH_UserProcess2, HOST_FS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_RegisterClass(&hUsbHostFS, USBH_HID_CLASS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_Start(&hUsbHostFS) != USBH_OK) {
		Error_Handler();
	}

	HAL_GPIO_WritePin(USB_FS_PWR_GPIO_Port, USB_FS_PWR_Pin, GPIO_PIN_RESET); // USB On

	return HAL_OK;
}

void USBH_HS_Restart() {
	if (USBH_Init(&hUsbHostHS, USBH_UserProcess1, HOST_HS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_RegisterClass(&hUsbHostHS, USBH_MSC_CLASS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_Start(&hUsbHostHS) != USBH_OK) {
		Error_Handler();
	}
}

USBH_StatusTypeDef USBH_Process2(USBH_HandleTypeDef *phost) {
	int USBH_HandleEnum_Test = 0;

	__IO USBH_StatusTypeDef status = USBH_FAIL;
	uint8_t idx = 0U;

	/* check for Host port events */
	if (((USBH_IsPortEnabled(phost) == 0U)) && (phost->gState != HOST_IDLE)) {
		if (phost->gState != HOST_DEV_DISCONNECTED) {
			phost->gState = HOST_DEV_DISCONNECTED;
		}
	}

	switch (phost->gState) {
	case HOST_IDLE:

//		UsrLog("HOST_IDLE");

		if (phost->device.is_connected) {
			/* Wait for 200 ms after connection */
			phost->gState = HOST_DEV_WAIT_FOR_ATTACHMENT;
			USBH_Delay(200U);
			USBH_LL_ResetPort(phost);

#if (USBH_USE_OS == 1U)
			phost->os_msg = (uint32_t)USBH_PORT_EVENT;
#if (osCMSIS < 0x20000U)
			(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
			(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif

		}
		break;

	case HOST_DEV_WAIT_FOR_ATTACHMENT: /* Wait for Port Eabled */

//		UsrLog("HOST_DEV_WAIT_FOR_ATTACHMENT");

		if (phost->device.PortEnabled == 1U) {
			phost->gState = HOST_DEV_ATTACHED;
		}
		break;

	case HOST_DEV_ATTACHED:

//		USBH_UsrLog("USB Device Attached");

		/* Wait for 100 ms after Reset */
		USBH_Delay(100U);

		phost->device.speed = USBH_LL_GetSpeed(phost);

		phost->gState = HOST_ENUMERATION;

		phost->Control.pipe_out = USBH_AllocPipe(phost, 0x00U);
		phost->Control.pipe_in = USBH_AllocPipe(phost, 0x80U);

		/* Open Control pipes */
		USBH_OpenPipe(phost, phost->Control.pipe_in, 0x80U,
				phost->device.address, phost->device.speed,
				USBH_EP_CONTROL, (uint16_t) phost->Control.pipe_size);

		/* Open Control pipes */
		USBH_OpenPipe(phost, phost->Control.pipe_out, 0x00U,
				phost->device.address, phost->device.speed,
				USBH_EP_CONTROL, (uint16_t) phost->Control.pipe_size);

#if (USBH_USE_OS == 1U)
		phost->os_msg = (uint32_t)USBH_PORT_EVENT;
#if (osCMSIS < 0x20000U)
		(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
		(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		break;

	case HOST_ENUMERATION:
//		UsrLog("HOST_ENUMERATION");

		/* Check for enumeration status */
		while (USBH_HandleEnum(phost) != USBH_OK) {
			USBH_HandleEnum_Test++;

			if (USBH_HandleEnum_Test > 0xFF)
				break;
		}

		if (USBH_HandleEnum_Test < 0xFF) {
			enumTimeout = 0;
			/* The function shall return USBH_OK when full enumeration is complete */
			USBH_UsrLog("Enumeration done.");
			phost->device.current_interface = 0U;

			if (phost->device.DevDesc.bNumConfigurations == 1U) {
				USBH_UsrLog("This device has only 1 configuration.");
				phost->gState = HOST_SET_CONFIGURATION;

			} else {
				phost->gState = HOST_INPUT;
			}

		} else {
			USBH_UsrLog("USBH_HandleEnum(phost) != USBH_OK");
			if (enumTimeout < 0x3F) {
				enumTimeout++;
			} else {
				enumTimeout = 0;

				if (USBH_Init(&hUsbHostFS, USBH_UserProcess2, HOST_FS)
						!= USBH_OK) {
					Error_Handler();
				}
				if (USBH_RegisterClass(&hUsbHostFS, USBH_HID_CLASS)
						!= USBH_OK) {
					Error_Handler();
				}
				if (USBH_Start(&hUsbHostFS) != USBH_OK) {
					Error_Handler();
				}

				IWDG_delay_ms(200);

				HAL_GPIO_WritePin(USB_FS_PWR_GPIO_Port, USB_FS_PWR_Pin,
						GPIO_PIN_SET); // USB On
			}
		}
		break;

	case HOST_INPUT: {
//		UsrLog("HOST_INPUT");

		/* user callback for end of device basic enumeration */
		if (phost->pUser != NULL) {
			phost->pUser(phost, HOST_USER_SELECT_CONFIGURATION);
			phost->gState = HOST_SET_CONFIGURATION;

#if (USBH_USE_OS == 1U)
			phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
			(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
			(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		}
	}
		break;

	case HOST_SET_CONFIGURATION:

		/* set configuration */
		if (USBH_SetCfg(phost,
				(uint16_t) phost->device.CfgDesc.bConfigurationValue)
				== USBH_OK) {
			phost->gState = HOST_SET_WAKEUP_FEATURE;
			USBH_UsrLog("Default configuration set.");
		}

#if (USBH_USE_OS == 1U)
		phost->os_msg = (uint32_t)USBH_PORT_EVENT;
#if (osCMSIS < 0x20000U)
		(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
		(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		break;

	case HOST_SET_WAKEUP_FEATURE:

		if ((phost->device.CfgDesc.bmAttributes) & (1U << 5)) {
			if (USBH_SetFeature(phost, FEATURE_SELECTOR_REMOTEWAKEUP)
					== USBH_OK) {
				USBH_UsrLog("USBH_SetFeature FS: Device remote wakeup enabled");
				phost->gState = HOST_CHECK_CLASS;
			}
		} else {
			phost->gState = HOST_CHECK_CLASS;
		}

#if (USBH_USE_OS == 1U)
		phost->os_msg = (uint32_t)USBH_PORT_EVENT;
#if (osCMSIS < 0x20000U)
		(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
		(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		break;

	case HOST_CHECK_CLASS:

//		UsrLog("HOST_CHECK_CLASS");

		if (phost->ClassNumber == 0U) {
			USBH_UsrLog("No Class has been registered.");
		} else {
			phost->pActiveClass = NULL;

			for (idx = 0U; idx < USBH_MAX_NUM_SUPPORTED_CLASS; idx++) {
				for (int infx = 0; infx < phost->device.CfgDesc.bNumInterfaces;
						infx++) {
					if ((phost->pClass[idx]->ClassCode
							== phost->device.CfgDesc.Itf_Desc[infx].bInterfaceClass)) {
						phost->pActiveClass = phost->pClass[idx];
						break;
					}
					USBH_UsrLog("Active Class: %d, Interface: %d",
							phost->pClass[idx]->ClassCode, infx);
				}
			}

			if (phost->pActiveClass != NULL) {
				if (phost->pActiveClass->Init(phost) == USBH_OK) {
					phost->gState = HOST_CLASS_REQUEST;
					USBH_UsrLog("%s class started.", phost->pActiveClass->Name);

					/* Inform user that a class has been activated */
					phost->pUser(phost, HOST_USER_CLASS_SELECTED);
				} else {
					phost->gState = HOST_ABORT_STATE;
					USBH_UsrLog("Device not supporting %s class.",
							phost->pActiveClass->Name);
				}
			} else {
				phost->gState = HOST_ABORT_STATE;
				USBH_UsrLog("No registered class for this device.");
			}
		}

#if (USBH_USE_OS == 1U)
		phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
		(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
		(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		break;

	case HOST_CLASS_REQUEST:
//		UsrLog("HOST_CLASS_REQUEST");

		/* process class standard control requests state machine */
		if (phost->pActiveClass != NULL) {
			status = phost->pActiveClass->Requests(phost);

			if (status == USBH_OK) {
				phost->gState = HOST_CLASS;
			}
		} else {
			phost->gState = HOST_ABORT_STATE;
			USBH_ErrLog("Invalid Class Driver.");

#if (USBH_USE_OS == 1U)
			phost->os_msg = (uint32_t)USBH_STATE_CHANGED_EVENT;
#if (osCMSIS < 0x20000U)
			(void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
			(void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, NULL);
#endif
#endif
		}

		break;
	case HOST_CLASS:
		/* process class state machine */
		if (phost->pActiveClass != NULL) {
			if (HAL_GetTick() > (keyboard_led_status_tick + 10)) {
				keyboard_led_status_tick = HAL_GetTick();
				HID_HandleTypeDef *HID_Handle =
						(HID_HandleTypeDef*) phost->pActiveClass->pData;
				if (HID_Handle->Init == USBH_HID_KeybdInit) {
					USB_Set_Keyboard_LED_Status(kbd_LED_status);
				}
			}

			phost->pActiveClass->BgndProcess(phost);
		}
		break;

	case HOST_DEV_DISCONNECTED:

		DeInitStateMachine(phost);

		/* Re-Initilaize Host for new Enumeration */
		if (phost->pActiveClass != NULL) {
			phost->pActiveClass->DeInit(phost);
			phost->pActiveClass = NULL;
		}
		break;

	case HOST_ABORT_STATE:
	default:
		break;
	}
	return USBH_OK;
}

void USB_Error_Handler(uint16_t code) {
	/* USER CODE BEGIN USB_Error_Handler */
	/* User can add his own implementation to report the HAL error return state */
//HAL_GPIO_WritePin(GPIOE,GPIO_PIN_0,GPIO_PIN_RESET); // LED D2
	USBH_UsrLog("USB_Error_Handler: %d", code);
	/* USER CODE END USB_Error_Handler */
}

#include "ff.h"
#include <stdio.h>

FATFS USBH_fatfs;
FIL MyFile;
FRESULT res;
uint32_t bytesWritten;
char rtext[2500];
char wtext[2500]; // 2080
char name[256];	//file name yymmddhhss.csv
uint32_t counter = 0;

extern char USBHPath[]; /* USBH logical drive path */

extern UART_HandleTypeDef huart3;
uint8_t uart_tx_buffer[100];

uint8_t userFunctionExport(void) {
	if (userFunction() == TRUE) {
		export_data_enabled = 0;

		return 0;
	}

	return 1;
}

FRESULT file_exists(char *filename) {
	FIL MyFile1;

	if (f_open(&MyFile1, filename, FA_OPEN_EXISTING) == FR_OK) {
		f_close(&MyFile1);
		UsrLog("file exists");
		return FR_EXIST;
	} else {
		UsrLog("file doesn't exist");
		return FR_NO_FILE;
	}
}

HAL_StatusTypeDef save_BMP_Export(void) {
	if (save_BMP_function() == HAL_OK) {
		//save_BMP_enabled = 0;

		return HAL_OK;
	}

	return HAL_BUSY;
}

HAL_StatusTypeDef save_BMP_function(void) {
//	int16_t x_read = 0;
	int16_t y_read = 0;
	uint16_t buff1[320] = { 0 }; // 3x 320 = 960
	uint8_t buff2[3] = { 0 }; // 3x 320 = 960
	uint32_t color_buff = 0;
	unsigned char header_buff[54];

	if (save_BMP_phase == 1) {
		UsrLog("save_BMP_phase == 1");

		if (Appli_state_HS == APPLICATION_READY) {
//			save_BMP_in_progress = 1;

			/* Register the file system object to the FatFs module */
			if (f_mount(&USBDISKFatHs, (TCHAR const*) USBDISKPath, 0)
					!= FR_OK) {
				/* FatFs Initialization Error */
				USB_Error_Handler(0);

				save_BMP_phase = 0;

				lcd_refresh = 3;
			}

			sprintf(name, "20%02d.%02d.%02d_%02d.%02d.%02d.bmp", tm1.year,
					tm1.month, tm1.date, tm1.hours, tm1.minutes, tm1.seconds);

			/*Create a file*/
			if (f_open(&MyFile, name, FA_CREATE_ALWAYS | FA_WRITE) != FR_OK) {
				/* Creation failed */
				UsrLog("Cannot open %s file \n", name);
				save_BMP_error = 2;
				lcd_refresh = 3;

				save_BMP_phase = 0;
			} else {
				UsrLog("file %s created \n", name);
				/*write message to the file. Use variable wtext, bytesWritten*/

				save_BMP_phase++;
			}
		} else {
			save_BMP_phase = 0;

			lcd_refresh = 3;
		}
	} else if (save_BMP_phase == 2) {
		UsrLog("save_BMP_phase == 2");

		BMP_to_USB_header(header_buff);

		res = f_write(&MyFile, header_buff, sizeof(header_buff),
				(void*) &bytesWritten);

		for (y_read = 239; y_read >= 0; y_read--) {
			//for (y_read = 0; y_read < 239; y_read++) {
			ILI9341_readPixels16(0, y_read, 319, y_read, buff1);

			for (uint16_t i = 0; i < 320; i++) {
				if (buff1[i] == ILI9341_BLUE)
					color_buff = ILI9341_888_BLUE;
				else if (buff1[i] == ILI9341_RED)
					color_buff = ILI9341_888_RED;
				else if (buff1[i] == ILI9341_GREEN)
					color_buff = ILI9341_888_GREEN;
				else if (buff1[i] == ILI9341_CYAN)
					color_buff = ILI9341_888_CYAN;
				else if (buff1[i] == ILI9341_MAGENTA)
					color_buff = ILI9341_888_MAGENTA;
				else if (buff1[i] == ILI9341_YELLOW)
					color_buff = ILI9341_888_YELLOW;
				else if (buff1[i] == ILI9341_WHITE)
					color_buff = ILI9341_888_WHITE;
				else if (buff1[i] == ILI9341_LIGHTGREY)
					color_buff = ILI9341_888_LIGHTGREY;
				else if (buff1[i] == ILI9341_ORANGE)
					color_buff = ILI9341_888_ORANGE;
				else if (buff1[i] == ILI9341_GREY)
					color_buff = ILI9341_888_GREY;
				else if (buff1[i] == ILI9341_DARKGREY)
					color_buff = ILI9341_888_DARKGREY;
				else if (buff1[i] == ILI9341_DARKBLUE)
					color_buff = ILI9341_888_DARKBLUE;
				else if (buff1[i] == ILI9341_DARKCYAN)
					color_buff = ILI9341_888_DARKCYAN;
				else if (buff1[i] == ILI9341_DARKYELLOW)
					color_buff = ILI9341_888_DARKYELLOW;
				else if (buff1[i] == ILI9341_BLUESKY)
					color_buff = ILI9341_888_BLUESKY;
				else if (buff1[i] == ILI9341_BROWN)
					color_buff = ILI9341_888_BROWN;
				else
					color_buff = ILI9341_888_BLACK;

				buff2[0] = color_buff;
				buff2[1] = color_buff >> 8;
				buff2[2] = color_buff >> 16;

				res = f_write(&MyFile, buff2, 3, (void*) &bytesWritten);
			}

			//UsrLog("%lu", len);

			if ((y_read % 10) == 0) {
				UsrLog("line: %u", y_read);
				beep(1);
			}

			IWDG_delay_ms(0);
		}

		save_BMP_phase++;

//		}
	} else if (save_BMP_phase == 3) {
		UsrLog("save_BMP_phase == 3");
		// End MSC_HOST_HANDS_ON: Add the call to userFunction()

//		save_BMP_in_progress = 0;

		/*
		 *
		 * Begin: Data Export (lock content)
		 * Date: 2020-May-06
		 *
		 */

		if (lcd_screen == LcdScreenMonCh) {
			uint8_t u_write_buff[8];

			u_write_buff[0] = tm1.year;
			u_write_buff[1] = tm1.month;
			u_write_buff[2] = tm1.date;

			res = f_write(&MyFile, u_write_buff, 3, (void*) &bytesWritten);

			u_write_buff[0] = tm1.hours;
			u_write_buff[1] = tm1.minutes;
			u_write_buff[2] = tm1.seconds;

			res = f_write(&MyFile, u_write_buff, 3, (void*) &bytesWritten);

			for (int j = 0; j < 3; j++) {
				for (int i = 0; i < 4; i++) {
					u_write_buff[i] = (uC_ID[j] >> (24 - (i * 8))) & 0xFF;
				}

				res = f_write(&MyFile, u_write_buff, 4, (void*) &bytesWritten);
			}

			for (int i = 0; i < 8; i++) {
				u_write_buff[i] = w25qxx.UniqID[i];
			}

			res = f_write(&MyFile, u_write_buff, 8, (void*) &bytesWritten);

			for (int i = 0; i < maxChannel; i++) {
				for (int j = 0; j < maxChannel; j++) {
					u_write_buff[j] = SENSORS[i].SERIAL_ID[j];
				}

				res = f_write(&MyFile, u_write_buff, 8, (void*) &bytesWritten);
			}

			u_write_buff[0] = language_current + 48;

			res = f_write(&MyFile, u_write_buff, 1, (void*) &bytesWritten);
		}

		/*
		 *
		 * End: Data Export (lock content)
		 *
		 */

		/*close the file*/
		f_close(&MyFile);

		set_timestamp(name);

		save_BMP_phase = 0;

		HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin, GPIO_PIN_SET); // USB off

		lcd_refresh = 3;

		return HAL_OK;
	}

	return HAL_BUSY;
}

// source https://forum.arduino.cc/t/writing-binary-file-to-sd-creating-bmp-files/110331/6

/*
 * END of code: https://forum.arduino.cc/t/writing-binary-file-to-sd-creating-bmp-files/110331/6
 */

void get_data_header(void) {
	sprintf(wtext, "%s%c%s%c", Firm_Mod, sepChr, Firm_Ver, sepChr);

	sprintf(wtext + strlen(wtext), "%08lX%08lX%08lX%c", uC_ID[0], uC_ID[1],
			uC_ID[2], sepChr);

	sprintf(wtext + strlen(wtext), "%02X%02X%02X%02X%02X%02X%02X%02X%c",
			MEM_ID[0], MEM_ID[1], MEM_ID[2], MEM_ID[3], MEM_ID[4], MEM_ID[5],
			MEM_ID[6], MEM_ID[7], sepChr);

	sprintf(wtext + strlen(wtext), "%lu%c", (highest_cnt - 1), sepChr);

	uint8_t ch_enabled = 0;

	for (uint8_t i = 0; i < maxChannel; i++) {
		if (export_ch[i] == 1) {
			ch_enabled = (ch_enabled << 1) | 0B1;
		} else {
			ch_enabled = (ch_enabled << 1) & 0B11111110;
		}
	}

	sprintf(wtext + strlen(wtext), "%d%c%d%c%d%c%d%c%d%c%d%c%d", maxChannel,
	sepChr, ch_enabled,
	sepChr, temperature_unit, sepChr, decimal_separator, sepChr, date_format,
	sepChr, language_current, sepChr, file_type);
}

void get_data_header2(void) {
//	if (file_type == datFile64) { // Hide index
//		wtext[0] = 0;
//		wtext[1] = 0;
//	} else { // datFile16 or csvFile
	sprintf(wtext, "Index%c", sepChr);
//	}

	for (int8_t i = 0; i < maxChannel; i++) {
		if (export_ch[i] == 1) {
			char TempUnit = 'C';

			if (temperature_unit == TemperatureUnit_F) {
				TempUnit = 'F';
			}

			sprintf(wtext + strlen(wtext),
					"CH%d: Date%cCH%d: Time (GMT-3)%cCH%d: Temp. %c%c (", i + 1,
					sepChr, i + 1, sepChr, i + 1,
					degChr, TempUnit);

			// UsrLog("channelLabel: %s", channelLabel[i]);

			if (channelLabel[i][0] != 255) {
				char label_tmp[maxChar];

				for (int j = 0; j < maxChar; j++) { // copy
					label_tmp[j] = channelLabel[i][j];
				}

				if (sepChr == 59) {
					replace_char(label_tmp, 59, 124); // ASCII(59): ';', ASCII(124): '|'
				}

				sprintf(wtext + strlen(wtext), "%s", label_tmp);
			} else {
				sprintf(wtext + strlen(wtext), "-");
			}

			sprintf(wtext + strlen(wtext),
					")%cCH%d: Sensor ID%cCH%d: ACC_x(%c)%cCH%d: ACC_y(%c)%cCH%d: Bat.(V)%cCH%d: Carreg.(V)%c",
					sepChr, i + 1, sepChr, i + 1,
					degChr, sepChr, i + 1, degChr,
					sepChr, i + 1,
					sepChr, i + 1, sepChr);
		}
	}

	sprintf(wtext + strlen(wtext), "%cEvent Date%cEvent Time%cEvent Desc.%c",
	sepChr,
	sepChr, sepChr, sepChr);

	if (file_type != csvFile) {
		BASE64_encode(wtext, wtext); // hide data
	}
}

#define shared_array_max 64

uint8_t shared_Sensor_Id64[maxChannel][shared_array_max][8];
uint32_t shared_Sensor_Id64_index[maxChannel][shared_array_max];

uint32_t shared_data_posit = 0;

void shared_data_clear(void) {
	for (uint8_t i = 0; i < maxChannel; i++) {
		for (uint8_t j = 0; j < shared_array_max; j++) {
			for (uint8_t k = 0; k < 8; k++) {
				shared_Sensor_Id64[i][j][k] = 0;
			}

			shared_Sensor_Id64_index[i][j] = 0;
		}
	}

	shared_data_posit = 0;
}

int32_t get_shared_Sensor_Id_index64(uint8_t channel, uint8_t *Sensor_Id,
		uint32_t posit) {
	uint8_t sens_ID_tmp[8];
	uint8_t shared_sens_ID_tmp[8];
	uint8_t compare_empty = 0;
	uint8_t compare_equal = 0;

	for (uint8_t j = 0; j < shared_array_max; j++) {
		for (uint8_t i = 0; i < 8; i++) {
			sens_ID_tmp[i] = Sensor_Id[i];
			shared_sens_ID_tmp[i] = shared_Sensor_Id64[channel][j][i];

			if (shared_sens_ID_tmp[i] == 0) {
				compare_empty++;
			} else {
				if (shared_sens_ID_tmp[i] == sens_ID_tmp[i]) {
					compare_equal++;
				}
			}
		}

		if (compare_equal == 8) {
			return shared_Sensor_Id64_index[channel][j];
		} else {
			if (compare_empty == 8) {
				for (uint8_t i = 0; i < 8; i++) {
					shared_Sensor_Id64[channel][j][i] = sens_ID_tmp[i];
				}

				shared_Sensor_Id64_index[channel][j] = posit;

				return -1; // new entry
			}
		}
	}

	return -2;
}

void replace_char(char *char_array, uint8_t find, uint8_t replace) {
	uint16_t _length = 0;

	_length = sizeof_array(char_array);

	for (uint16_t j = 0; j < _length; j++) {
		if (char_array[j] == find) { // ascii(46) = "."
			char_array[j] = replace; // ascii(44) = ","
		}
	}
}

void get_data(uint32_t posit) {
	HAL_StatusTypeDef result_test_data;

	DadaStruct_TypeDef buff_test_data;

	DadaStruct2b_TypeDef buff_data2[maxChannel];

	uint8_t buff_data_skip[maxChannel] = { 0, 0, 0, 0, 0, 0, 0, 0 };

	for (uint8_t i = 0; i < maxChannel; i++) {
		if ((posit < ch_mark_cnt_export[i]) && (export_ch[i] == 1)) {
			result_test_data = HAL_BUSY;

			read_data_steps = 0;

			while (result_test_data == HAL_BUSY) {
				result_test_data = W25Q64_read_data(i, posit, &buff_test_data);
			}

			if (file_type == csvFile) {
				if (date_format == ddmmyy) {
					sprintf(buff_data2[i].Date, "%02d/%02d/%02d",
							buff_test_data.Date[0], buff_test_data.Date[1],
							buff_test_data.Date[2]);
				} else { // mmddyy:
					sprintf(buff_data2[i].Date, "%02d/%02d/%02d",
							buff_test_data.Date[1], buff_test_data.Date[0],
							buff_test_data.Date[2]);
				}

				sprintf(buff_data2[i].Time, "%02d:%02d", buff_test_data.Time[0],
						buff_test_data.Time[1]);
			} else {
				if (file_type == datFile16) {
					sprintf(buff_data2[i].Date, "%02X%02X%02X",
							buff_test_data.Date[2], buff_test_data.Date[1],
							buff_test_data.Date[0]);

					sprintf(buff_data2[i].Time, "%02X%02X",
							buff_test_data.Time[0], buff_test_data.Time[1]);
				} else { // datFile64
					char y_tmp[3];
					char m_tmp[2];
					char d_tmp[2];

					conv_b10_b64(buff_test_data.Date[0], d_tmp);
					conv_b10_b64(buff_test_data.Date[1], m_tmp);
					conv_b10_b64(buff_test_data.Date[2], y_tmp);

					if (y_tmp[1] == 0) {
						y_tmp[2] = 0;
						y_tmp[1] = y_tmp[0];
						y_tmp[0] = 'A';
					}

					sprintf(buff_data2[i].Date, "%s%s%s", y_tmp, m_tmp, d_tmp);

//					for (uint8_t j = 0; j < 3; j++) {
//						conv_b10_b64(buff_test_data.Date[2 - j], tmp);
//
//						buff_data2[i].Date[j + 1] = tmp[0];
//					}
//
//					buff_data2[i].Date[3] = 0;

					char tmp[2];

					for (uint8_t j = 0; j < 2; j++) {
						conv_b10_b64(buff_test_data.Time[1 - j], tmp);

						buff_data2[i].Time[j] = tmp[0];
					}

					buff_data2[i].Time[2] = 0;
				}
			}

			buff_data2[i].Temperature_f = DS18B20_bin_to_float(
					buff_test_data.Temperature);

			if (file_type == csvFile) {
				DS18B20_hex_id(buff_test_data.Sensor_Id,
						buff_data2[i].Sensor_Id);
			} else {
				if (file_type == datFile16) {
					DS18B20_hex_id(buff_test_data.Sensor_Id,
							buff_data2[i].Sensor_Id);
				} else { // datFile64
					DS18B20_b64_id(buff_test_data.Sensor_Id,
							buff_data2[i].Sensor_Id);

//					DS18B20_b64_id(buff_test_data.Sensor_Id,
//							buff_data2[i].Sensor_Id);
//
//					int32_t ID_index = -5;
//
//					ID_index = get_shared_Sensor_Id_index64(i,
//							buff_test_data.Sensor_Id, posit);
//
//					if (ID_index >= 0) {
//						sprintf(buff_data2[i].Sensor_Id, "%lu", ID_index);
//					}
				}
			}
			//           031297795C2728
			// DEpd5XCco: 31297795C2728
//			}

			buff_data2[i].AccX = buff_test_data.AccX;
			buff_data2[i].AccY = buff_test_data.AccY;
			buff_data2[i].BattV = buff_test_data.BattV;
			buff_data2[i].ChargerV = buff_test_data.ChargerV;

			buff_data_skip[i] = 0;
		} else {
			buff_data_skip[i] = 1;
		}
	}

//	if (file_type == datFile64) { // Hide index
//		wtext[0] = 0;
//		wtext[1] = 0;
//		sprintf(wtext, "%lu%c", posit, sepChr);
//	} else { // datFile16 or csvFile
	sprintf(wtext, "%lX%c", posit, sepChr);
//	}

	for (uint8_t i = 0; i < maxChannel; i++) {
		if (export_ch[i] == 1) {
			if ((posit < ch_mark_cnt_export[i]) && (buff_data_skip[i] == 0)) {
				int8_t temperature_i = buff_data2[i].Temperature_f;
				float temperature_dec_f = buff_data2[i].Temperature_f
						- temperature_i;
				temperature_dec_f *= 10000;
				temperature_dec_f /= 625;

				int8_t temperature_dec_i = temperature_dec_f;

				int8_t _AccX = buff_data2[i].AccX - 127;
				int8_t _AccY = buff_data2[i].AccY - 127;

				float _BattV = buff_data2[i].BattV;
				_BattV *= 0.004;
				_BattV += 3.5;

				float _ChargerV = buff_data2[i].ChargerV;
				_ChargerV *= 0.1;
				_ChargerV += 7.0;

				if (file_type == csvFile) {
					float _Temperature_f = buff_data2[i].Temperature_f;

					if (temperature_unit != TemperatureUnit_C) { // TemperatureUnit_F
						_Temperature_f *= 9.0; // (°C × 9/5) + 32
						_Temperature_f /= 5.0; // (°C × 9/5) + 32
						_Temperature_f += 32.0; // (°C × 9/5) + 32
					}

					sprintf(wtext + strlen(wtext),
							"%s%c%s%c%.4f%c%s%c%d%c%d%c%f%c%f%c",
							buff_data2[i].Date,
							sepChr, buff_data2[i].Time,
							sepChr, _Temperature_f, sepChr,
							buff_data2[i].Sensor_Id, sepChr, _AccX,
							sepChr, _AccY, sepChr, _BattV,
							sepChr, _ChargerV, sepChr);

					if (decimal_separator == sepComma) {
						replace_char(wtext, 46, 44); // ascii(46): "."; ascii(44): ","
					}
				} else {
					if (file_type == datFile16) {
						sprintf(wtext + strlen(wtext),
								"%s%c%s%c%X.%X%c%s%c%X%c%X%c%X%c%X%c",
								buff_data2[i].Date,
								sepChr, buff_data2[i].Time,
								sepChr, temperature_i, temperature_dec_i,
								sepChr, buff_data2[i].Sensor_Id, sepChr,
								buff_data2[i].AccX,
								sepChr, buff_data2[i].AccY, sepChr,
								buff_data2[i].BattV,
								sepChr, buff_data2[i].ChargerV, sepChr);
					} else {
						char temperature_c[4];
						char temperature_dec_c[2];
						char AccX_c[5];
						char AccY_c[5];
						char BattV_c[4];
						char ChargerV_c[4];

						conv_b10_b64(temperature_i, temperature_c);
						conv_b10_b64(temperature_dec_i, temperature_dec_c);
						conv_b10_b64(buff_data2[i].AccX, AccX_c);
						conv_b10_b64(buff_data2[i].AccY, AccY_c);
						conv_b10_b64(buff_data2[i].BattV, BattV_c);
						conv_b10_b64(buff_data2[i].ChargerV, ChargerV_c);

						sprintf(wtext + strlen(wtext),
								"%s%c%s%c%s.%s%c%s%c%s%c%s%c%s%c%s%c",
								buff_data2[i].Date,
								sepChr, buff_data2[i].Time,
								sepChr, temperature_c, temperature_dec_c,
								sepChr, buff_data2[i].Sensor_Id, sepChr, AccX_c,
								sepChr, AccY_c, sepChr, BattV_c,
								sepChr, ChargerV_c, sepChr);
					}
				}
			} else {
				sprintf(wtext + strlen(wtext), "%c%c%c%c%c%c%c%c",
				sepChr, sepChr, sepChr, sepChr, sepChr, sepChr, sepChr, sepChr);
			}
		}
	}

	if (file_type == csvFile) {
		if (date_format == ddmmyy) {
			sprintf(wtext + strlen(wtext), "%c%02d/%02d/%02d%c%02d:%02d%c%s%c",
			sepChr, export_date, export_month, export_year, sepChr,
					export_hours, export_minutes, sepChr, "0",
					sepChr);
		} else { // mmddyy:
			sprintf(wtext + strlen(wtext), "%c%02d/%02d/%02d%c%02d:%02d%c%s%c",
			sepChr, export_month, export_date, export_year, sepChr,
					export_hours, export_minutes, sepChr, "0",
					sepChr);
		}
	} else {
		if (file_type == datFile16) {
			sprintf(wtext + strlen(wtext), "%c%02x%02x%02x%c%02X%02X%c%s%c",
			sepChr, export_year, export_month, export_date, sepChr,
					export_hours, export_minutes, sepChr, "0",
					sepChr);
		} else { // datFile64
			char _export_date[2];
			char _export_month[2];
			char _export_year[3];
			char _export_hours[2];
			char _export_minutes[2];

			conv_b10_b64(export_date, _export_date);
			conv_b10_b64(export_month, _export_month);
			conv_b10_b64(export_year, _export_year);
			conv_b10_b64(export_hours, _export_hours);
			conv_b10_b64(export_minutes, _export_minutes);

			if (_export_year[1] == 0) {
				_export_year[2] = 0;
				_export_year[1] = _export_year[0];
				_export_year[0] = 'A';
			}

			sprintf(wtext + strlen(wtext), "%c%s%s%s%c%s%s%c%s%c", sepChr,
					_export_year, _export_month, _export_date, sepChr,
					_export_hours, _export_minutes, sepChr, "0",
					sepChr);

//			char y_tmp[3];
//			char m_tmp[2];
//			char d_tmp[2];
//
//			conv_b10_b64(buff_test_data.Date[0], d_tmp);
//			conv_b10_b64(buff_test_data.Date[1], m_tmp);
//			conv_b10_b64(buff_test_data.Date[2], y_tmp);
//
//			if (y_tmp[1] == 0) {
//				y_tmp[2] = 0;
//				y_tmp[1] = y_tmp[0];
//				y_tmp[0] = 'A';
//			}
//
//			sprintf(buff_data2[i].Date, "%s%s%s",
//					y_tmp, m_tmp, d_tmp);

		}
	}

	if (file_type == datFile16) {
		BASE64_encode(wtext, wtext);  // hide data
	}
}

////Use custom get_fattime() function
//#define FATFS_CUSTOM_FATTIME    1

////Use custom get_fattime function
////Implement RTC get time here if you need it
//DWORD get_fattime (void) {
//    //Get your time from RTC or something like that
//
//return  ((DWORD)(2014 - 1980) << 25)  // Year 2014
//        | ((DWORD)7 << 21)            // Month 7
//        | ((DWORD)10 << 16)           // Mday 10
//        | ((DWORD)16 << 11)           // Hour 16
//        | ((DWORD)0 << 5)             // Min 0
//        | ((DWORD)0 >> 1);            // Sec 0
//}

FRESULT set_timestamp(char *obj) { /* Pointer to the file name */
	FILINFO fno;

	fno.fdate =
			(WORD) (((tm1.year + 1940) * 512U) | tm1.month * 32U | tm1.date);
	fno.ftime =
			(WORD) (tm1.hours * 2048U | tm1.minutes * 32U | tm1.seconds / 2U);

	return f_utime(obj, &fno);
}

uint8_t scanning_sensor_ID = 0;

uint8_t userFunction(void) {
	uint8_t progress_tmp;
	if (userFunction_phase == 1) {
		if (abort_operation == 1) {
			UsrLog("Operation aborted by user \n");
			export_error = 0;

			export_in_progress = 0;
			userFunction_phase = 0;
			export_data_enabled = 0;
			progress_usb_export = 0;
			start_MSC_Application1 = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;
		}

		UsrLog("userFunction_phase == 1");

		highest_cnt = 0;

		export_date = tm1.date;
		export_month = tm1.month;
		export_year = tm1.year;
		export_hours = tm1.hours;
		export_minutes = tm1.minutes;

		for (int8_t i = 0; i < maxChannel; i++) {
			ch_mark_cnt_export[i] = ch_mark_cnt[i];
		}

		for (int8_t i = 0; i < maxChannel; i++) {
			UsrLog("ch_mark_cnt_export[%d]: %lu", i, ch_mark_cnt_export[i]);

			if ((highest_cnt < ch_mark_cnt_export[i]) && (export_ch[i] == 1)) {
				highest_cnt = ch_mark_cnt_export[i];
			}
		}

		UsrLog("highest_cnt: %lu", highest_cnt);

		if ((highest_cnt > 0) && (Appli_state_HS == APPLICATION_READY)) {
			export_in_progress = 1;

			/* Register the file system object to the FatFs module */
			if (f_mount(&USBDISKFatHs, (TCHAR const*) USBDISKPath, 0)
					!= FR_OK) {

//				/* FatFs Initialization Error */

				UsrLog("Cannot mount USBDISK \n");
				export_error = 1;
				lcd_refresh = 3;

				userFunction_phase = 0;

				export_data_enabled = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			}

			char file_ext[4] = "";

			if (file_type == csvFile) {
				sprintf(file_ext, "csv");
			} else if (file_type == datFile64) {
				sprintf(file_ext, "dat");
			} else if (file_type == datFile16) {
				sprintf(file_ext, "Dat");
			}

			sprintf(name, "Datalogger2039_20%02d-%02d-%02d_%02d-%02d-%02d.%s",
					tm1.year, tm1.month, tm1.date, tm1.hours, tm1.minutes,
					tm1.seconds, file_ext);

			/*Create a file*/
			if (f_open(&MyFile, name,
			FA_CREATE_ALWAYS | FA_WRITE) != FR_OK) {
				/* Creation failed */
				UsrLog("Cannot open %s file \n", name);
				export_error = 2;
				lcd_refresh = 3;

				userFunction_phase = 0;

				export_data_enabled = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			} else {
				UsrLog("file %s created \n", name);
				/*write message to the file. Use variable wtext, bytesWritten*/

				userFunction_phase++;
			}
		} else {
			userFunction_phase = 0;

			lcd_refresh = 3;
		}
	} else if (userFunction_phase == 2) {
		UsrLog("userFunction_phase == 2");

		if (abort_operation == 1) {
			UsrLog("Operation aborted by user \n");

			/*close the file*/
			if (f_close(&MyFile) != FR_OK) {
				UsrLog("Cannot close %s file \n", name);
				export_error = 3;
				lcd_refresh = 3;

				export_in_progress = 0;
				userFunction_phase = 0;
				export_data_enabled = 0;
				progress_usb_export = 0;
				start_MSC_Application1 = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			}

			set_timestamp(name);

			export_error = 0;

			export_in_progress = 0;
			userFunction_phase = 0;
			export_data_enabled = 0;
			progress_usb_export = 0;
			start_MSC_Application1 = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;
		}

		get_data_header(); // --> wtext

		sprintf(wtext + strlen(wtext), "\n"); // wtext + \n

		if (f_write(&MyFile, wtext, sizeof_array(wtext), (void*) &bytesWritten)
				!= FR_OK) {
			UsrLog("Cannot write %s file \n", name);
			export_error = 4;
			lcd_refresh = 3;

			userFunction_phase = 0;

			export_data_enabled = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;
		}

		get_data_header2(); // -- wtext

		sprintf(wtext + strlen(wtext), "\n"); // wtext + \n

		if (f_write(&MyFile, wtext, sizeof_array(wtext), (void*) &bytesWritten)
				!= FR_OK) {
			UsrLog("Cannot write %s file \n", name);
			export_error = 5;
			lcd_refresh = 3;

			userFunction_phase = 0;

			export_data_enabled = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;
		}

		userFunction_phase++;

		userFunction_index1 = 0;

		shared_data_clear();

		if (file_type == csvFile) {
			if (file_cnt_csv > 1) {
				file_cnt_csv--;
			} else {
				file_cnt_csv = 0;

				file_type = datFile64;
			}
		} else {
			if (file_cnt_dat < 999) {
				file_cnt_dat++;
			} else {
				file_cnt_dat = 0;
			}
		}

		ConfigStruct_TypeDef conf_dat;

		W25Q64_read_config(&conf_dat);

		conf_dat.FileType = file_type;

		conf_dat.FileCntDat = file_cnt_dat;

		conf_dat.FileCntCsv = file_cnt_csv;

		W25Q64_update_config(&conf_dat);

	} else if (userFunction_phase == 3) {
		UsrLog("userFunction_phase == 3");
		while ((HAL_GPIO_ReadPin(RTC_INT_STATE_GPIO_Port,
		RTC_INT_STATE_Pin) == GPIO_PIN_RESET) && (userFunction_phase == 3)) {

			if (abort_operation == 1) {
				UsrLog("Operation aborted by user \n");

				/*close the file*/
				if (f_close(&MyFile) != FR_OK) {
					UsrLog("Cannot close %s file \n", name);
					export_error = 6;
					lcd_refresh = 3;

					export_in_progress = 0;
					userFunction_phase = 0;
					export_data_enabled = 0;
					progress_usb_export = 0;
					start_MSC_Application1 = 0;

					HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
							GPIO_PIN_SET); // USB off

					return TRUE;
				}

				set_timestamp(name);

				export_error = 0;

				export_in_progress = 0;
				userFunction_phase = 0;
				export_data_enabled = 0;
				progress_usb_export = 0;
				start_MSC_Application1 = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			}

			if ((userFunction_index1 <= (highest_cnt - 1))
					&& (highest_cnt > 0)) {
				if (scanning_sensor_ID != 1) {
					progress_tmp = ((userFunction_index1 * 8) / highest_cnt)
							+ 1;
				} else {
					progress_tmp = ((shared_data_posit * 8) / highest_cnt) + 1;
				}

				if (progress_tmp > 7) {
					progress_usb_export = 7;
				} else {
					progress_usb_export = progress_tmp;
				}

				if ((progress_usb_export_old != progress_usb_export)
						|| (HAL_GetTick() > (progress_tick + 3000))) {
					progress_tick = HAL_GetTick();
					if (scanning_sensor_ID != 1) {
						if(highest_cnt >= userFunction_index1) {
							progress_remaining = highest_cnt - userFunction_index1;
						} else {
							progress_remaining = 0;
						}
					} else {
						if(highest_cnt >= shared_data_posit) {
							progress_remaining = highest_cnt - shared_data_posit;
						} else {
							progress_remaining = 0;
						}
					}
					progress_usb_export_old = progress_usb_export;
					lcd_progress_bar();
				}

				//lcd_progress_barX10();

//				if (userFunction_index1 == 0) {
//					if (shared_data(highest_cnt) != HAL_OK) {
//						scanning_sensor_ID = 1;
//						return FALSE;
//					} else {
//						scanning_sensor_ID = 0;
//					}
//				}

				// UsrLog("get_data");

				get_data(userFunction_index1);

				userFunction_index1++;

				sprintf(wtext + strlen(wtext), "\n");

				// UsrLog("wtext: %s", wtext);

				if (f_write(&MyFile, wtext, sizeof_array(wtext),
						(void*) &bytesWritten) != FR_OK) {
					UsrLog("Cannot write %s file \n", name);
					export_error = 7;
					lcd_refresh = 3;

					userFunction_phase = 0;

					export_data_enabled = 0;

					HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
							GPIO_PIN_SET); // USB off

					return TRUE;
				}

				if (HAL_GPIO_ReadPin(AC_DC_STATE_GPIO_Port,
				AC_DC_STATE_Pin)) {
					lcd_timeout0 = lcd_timeout0recall2;
				} else {
					lcd_timeout0 = lcd_timeout0recall;
				}

				if (HAL_GetTick() > (userFunction_tick + 5)) {
					userFunction_tick = HAL_GetTick();

					IWDG_delay_ms(0);

					MX_USB_HOST_Process_FS();

					drawInfo();
				}
			} else {
				/*close the file*/
				if (f_close(&MyFile) != FR_OK) {
					UsrLog("Cannot close %s file \n", name);
					export_error = 8;
					lcd_refresh = 3;

					userFunction_phase = 0;

					export_data_enabled = 0;

					HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
							GPIO_PIN_SET); // USB off

					return TRUE;
				}

				set_timestamp(name);

				userFunction_phase++;

				shared_data_clear();
			}
		}
	} else if (userFunction_phase == 4) {
		UsrLog("userFunction_phase == 4");

		if (abort_operation == 1) {
			UsrLog("Operation aborted by user \n");

			export_error = 0;

			export_in_progress = 0;
			userFunction_phase = 0;
			export_data_enabled = 0;
			progress_usb_export = 0;
			start_MSC_Application1 = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;
		}

		/*check number of written bytes*/
		if ((bytesWritten == 0) || (res != FR_OK)) {
			/*error during writing*/
			UsrLog("write error \n");

			export_error = 9;
			lcd_refresh = 3;

			userFunction_phase = 0;

			export_data_enabled = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;

		} else {
			/*open file to verification*/
			if (f_open(&MyFile, name, FA_READ) != FR_OK) {
				/*file open failure*/
				UsrLog("Cannot open %s file for verify \n", name);
				export_error = 10;
				lcd_refresh = 3;
				userFunction_phase = 0;

				export_data_enabled = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			} else {
				userFunction_phase++;

				line_count = 0;

				userFunction_index1 = 0;
			}

			/*end program execution after verification*/
		}
	} else if (userFunction_phase == 5) {
		UsrLog("userFunction_phase == 5");

		while ((HAL_GPIO_ReadPin(RTC_INT_STATE_GPIO_Port,
		RTC_INT_STATE_Pin) == GPIO_PIN_RESET) && (userFunction_phase == 5)) {
			IWDG_delay_ms(0);

			MX_USB_HOST_Process_FS();

			if (abort_operation == 1) {
				UsrLog("Operation aborted by user \n");

				/*close the file*/
				if (f_close(&MyFile) != FR_OK) {
					UsrLog("Cannot close %s file \n", name);
					export_error = 11;
					lcd_refresh = 3;

					export_in_progress = 0;
					userFunction_phase = 0;
					export_data_enabled = 0;
					progress_usb_export = 0;
					start_MSC_Application1 = 0;

					HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
							GPIO_PIN_SET); // USB off

					return TRUE;
				}

				//set_timestamp(name);

				export_error = 0;

				export_in_progress = 0;
				userFunction_phase = 0;
				export_data_enabled = 0;
				progress_usb_export = 0;
				start_MSC_Application1 = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			}

			//UsrLog("index: %lu", userFunction_index1);

			if ((userFunction_index1 <= (highest_cnt - 1))
					&& (highest_cnt > 0)) {

				//UsrLog("line_count: %lu", line_count);

				// UsrLog("check point 1");

				/*Read file content. Use variable : rtext, bytesread*/

				// f_gets: http://elm-chan.org/fsw/ff/doc/gets.html
				if (!f_gets(rtext, sizeof(rtext), &MyFile)) {
					UsrLog("null pointer");
				}

				if ((f_eof(&MyFile) != 0) || (f_error(&MyFile) != 0)) {
					userFunction_phase++;

					// line_count = 0;

					FRESULT ret = f_error(&MyFile);

					if (ret != 0) {
						UsrLog("Error f_gets: %d", ret);
					}
				} else {
					if (line_count == 0) {
						get_data_header(); // line 0
					} else if (line_count == 1) {
						get_data_header2(); // line 1
					} else {
						get_data(userFunction_index1); // line (n - 1)

						userFunction_index1++;
					}

					//UsrLog("sizeof(wtext): %d", sizeof(wtext));

					for (uint16_t i = 0; i < sizeof(wtext); i++) {
						if (wtext[i] != 0) {
							if (wtext[i] != rtext[i]) {
								userFunction_phase++;

								UsrLog(
										"Error: Index: %lu; write(%02X) != read(%02X); pos: %d",
										userFunction_index1, wtext[i], rtext[i], i);
								UsrLog("wtext:%s", wtext);
								UsrLog("rtext:%s", rtext);

								IWDG_delay_ms(0);

								export_error = 9;
								lcd_refresh = 3;

								//break; // Error found: exit from for loop
							}
						} else {
							//UsrLog("break");
							break; // All OK: exit from for loop
						}
					}
				}

				line_count++;

				progress_tmp = ((line_count * 2) / highest_cnt) + 7;

				if (progress_tmp < 7) {
					progress_usb_export = 7;
				} else {
					progress_usb_export = progress_tmp;
				}

				if ((progress_usb_export_old != progress_usb_export)
						|| (HAL_GetTick() > (progress_tick + 3000))) {
					if(highest_cnt >= line_count) {
						progress_remaining = highest_cnt - line_count;
					} else {
						progress_remaining = 0;
					}

					progress_tick = HAL_GetTick();
					progress_usb_export_old = progress_usb_export;
					lcd_progress_bar();
				}

				//lcd_progress_barX10();

				//		IWDG_delay_ms(0);
				//
				//		MX_USB_HOST_Process_FS();

				if (HAL_GetTick() > (userFunction_tick + 5)) {
					userFunction_tick = HAL_GetTick();

					IWDG_delay_ms(0);

					MX_USB_HOST_Process_FS();

					drawInfo();
				}
			}
		}
	} else if (userFunction_phase == 6) {
		UsrLog("userFunction_phase == 6");

		if (abort_operation == 1) {
			UsrLog("Operation aborted by user \n");

			/*close the file*/
			if (f_close(&MyFile) != FR_OK) {
				UsrLog("Cannot close %s file \n", name);
				export_error = 12;
				lcd_refresh = 3;

				export_in_progress = 0;
				userFunction_phase = 0;
				export_data_enabled = 0;
				progress_usb_export = 0;
				start_MSC_Application1 = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			}

			set_timestamp(name);

			export_error = 0;

			export_in_progress = 0;
			userFunction_phase = 0;
			export_data_enabled = 0;
			progress_usb_export = 0;
			start_MSC_Application1 = 0;

			return TRUE;
		}

		if (line_count == 0) {
			/*read fail*/
			UsrLog("Cannot read file for verification \n");

			export_error = 13;
			lcd_refresh = 3;
			userFunction_phase = 0;

			export_data_enabled = 0;

			HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
					GPIO_PIN_SET); // USB off

			return TRUE;
		} else {
			/*read success*/

			/*close the file*/
			if (f_close(&MyFile) != FR_OK) {
				/*check number of written bytes*/
				UsrLog("fclose fail \n");

				export_error = 14;
				lcd_refresh = 3;
				userFunction_phase = 0;

				export_data_enabled = 0;

				HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
						GPIO_PIN_SET); // USB off

				return TRUE;
			} else {
				/* Compare read data with the expected data */
				if (line_count == (highest_cnt + 2)) {
					/*verification success full - number of written bytes is equal to number of read bytes*/
					UsrLog(
							"verification OK - read content matches written content");

					int d = 1000;

					while (d--) {
						IWDG_delay_ms(1);
						MX_USB_HOST_Process_FS();
					}

					progress_usb_export = 10;

					if (progress_usb_export_old != progress_usb_export) {
						progress_usb_export_old = progress_usb_export;
						lcd_progress_bar();
					}

					userFunction_phase++;

				} else {
					/*verification failed - number of written bytes is not equal to number of read bytes*/
					UsrLog("verify fail; lines read: %lu, lines wrote: %lu",
							line_count, (highest_cnt + 2));

					export_error = 15;
					lcd_refresh = 3;
					userFunction_phase = 0;

					export_data_enabled = 0;

					HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin,
							GPIO_PIN_SET); // USB off

					return TRUE;
				}
			}
		}
	} else if (userFunction_phase == 7) {
		UsrLog("userFunction_phase == 7");
// End MSC_HOST_HANDS_ON: Add the call to userFunction()

		HAL_GPIO_WritePin(USB_HS_PWR_GPIO_Port, USB_HS_PWR_Pin, GPIO_PIN_SET); // USB off

		export_in_progress = 0;

		progress_usb_export = 99;

		lcd_progress_bar();

		for (int i = 0; i < 8; i++) { // maxChannel
			if (export_ch[i] == 1) {
				ch_exported[i] = 1; // set as exported
			}
		}

		update_exported_data();

		return TRUE;
	}

	return FALSE;
}

void update_exported_data(void) {
	ConfigStruct_TypeDef conf_dat;

	W25Q64_read_config(&conf_dat);

	for (int i = 0; i < 8; i++) { // maxChannel
		conf_dat.ChExported[i] = ch_exported[i];
	}

	W25Q64_update_config(&conf_dat);
}

void MX_USB_HOST_Process_HS(void) {
	/* USB Host Background task */
	USBH_Process(&hUsbHostHS);
}

void MX_USB_HOST_Process_FS(void) {
	/* USB Host Background task */
	USBH_Process2(&hUsbHostFS);
}

/* USER CODE END 1 */

/**
 * Init USB host library, add supported class and start the library
 * @retval None
 */
void MX_USB_HOST_Init(void) {
	/* USER CODE BEGIN USB_HOST_Init_PreTreatment */
	if (lcd_enabled == false) {
		USBH_UsrLog("Skip: MX_USB_HOST_Init");
		return;
	} else {
		USBH_UsrLog("MX_USB_HOST_Init");
	}
	/* USER CODE END USB_HOST_Init_PreTreatment */

	/* Init host Library, add supported class and start the library. */
	if (USBH_Init(&hUsbHostHS, USBH_UserProcess1, HOST_HS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_RegisterClass(&hUsbHostHS, USBH_MSC_CLASS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_Start(&hUsbHostHS) != USBH_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN USB_HOST_Init_PreTreatment */
	if (lcd_enabled == false) {
		USBH_UsrLog("Skip: MX_USB_HOST_Init");
		return;
	} else {
		USBH_UsrLog("MX_USB_HOST_Init");
	}
	/* USER CODE END USB_HOST_Init_PreTreatment */

	/* Init host Library, add supported class and start the library. */
	if (USBH_Init(&hUsbHostFS, USBH_UserProcess2, HOST_FS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_RegisterClass(&hUsbHostFS, USBH_HID_CLASS) != USBH_OK) {
		Error_Handler();
	}
	if (USBH_Start(&hUsbHostFS) != USBH_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN USB_HOST_Init_PostTreatment */

	/* USER CODE END USB_HOST_Init_PostTreatment */
}

/*
 * Background task
 */
void MX_USB_HOST_Process(void) {
	/* USB Host Background task */
	USBH_Process(&hUsbHostHS);
	USBH_Process(&hUsbHostFS);
}
/*
 * user callback definition
 */
static void USBH_UserProcess1(USBH_HandleTypeDef *phost, uint8_t id) {
	/* USER CODE BEGIN CALL_BACK_2 */
	switch (id) {
	case HOST_USER_SELECT_CONFIGURATION:
		break;

	case HOST_USER_DISCONNECTION:
		Appli_state = APPLICATION_DISCONNECT;
		Appli_state_HS = Appli_state;
		if (lcd_screen == LcdScreenUsbExport) {
			lcd_refresh = 3;
		}
		if (export_in_progress == 1) {
			export_in_progress = 0;
			export_error = 16;
			lcd_refresh = 3;
			userFunction_phase = 0;

			export_data_enabled = 0;
			progress_usb_export = 0;
			start_MSC_Application1 = 0;
		}

		if (f_mount(NULL, "", 0) != FR_OK) {
			Error_Handler();
		}
		if (FATFS_UnLinkDriver(USBDISKPath) != 0) {
			Error_Handler();
		}
		break;

	case HOST_USER_CLASS_ACTIVE:
		Appli_state = APPLICATION_READY;
		Appli_state_HS = Appli_state;
		if (lcd_screen == LcdScreenUsbExport) {
			export_in_progress = 0;

			userFunction_phase = 0;

			export_data_enabled = 0;
			progress_usb_export = 0;

			export_error = 0;
			start_MSC_Application1 = 0;
			lcd_refresh = 3;
		}
		break;

	case HOST_USER_CONNECTION:
		Appli_state = APPLICATION_START;
		Appli_state_HS = Appli_state;

		if (FATFS_LinkDriver(&USBH_Driver, USBDISKPath) == 0) {
			if (f_mount(&USBDISKFatHs, (const TCHAR*) USBDISKPath, 0)
					!= FR_OK) {
				Error_Handler();
			}
		}
		break;

	default:
		break;
	}
	/* USER CODE END CALL_BACK_2 */
}

static void USBH_UserProcess2(USBH_HandleTypeDef *phost, uint8_t id) {
	/* USER CODE BEGIN CALL_BACK_21 */
	switch (id) {
	case HOST_USER_SELECT_CONFIGURATION:
		break;

	case HOST_USER_DISCONNECTION:
		Appli_state = APPLICATION_DISCONNECT;

		if (Appli_state_FS != APPLICATION_DISCONNECT) {
			usb_power_recycle_count++;
		}

		Appli_state_FS = Appli_state;

		kbd_LED_status_old = 99;

		keyboard_timeout = 0;

		keyboard_timeout2 = 0;

		break;

	case HOST_USER_CLASS_ACTIVE:
		Appli_state = APPLICATION_READY;
		Appli_state_FS = Appli_state;
		break;

	case HOST_USER_CONNECTION:
		Appli_state = APPLICATION_START;
		Appli_state_FS = Appli_state;
		break;

	default:
		break;
	}
	/* USER CODE END CALL_BACK_21 */
}

/**
 * @}
 */

/**
 * @}
 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
