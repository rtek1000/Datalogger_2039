/*
 * 1-Version.h
 *
 *  Created on: 6 de mai de 2022
 *      Author: r
 */

#ifndef INC_1_VERSION_H_
#define INC_1_VERSION_H_

#define Firm_Mod "Datalogger 2039"
#define Firm_Ver "0.0.2 Beta"
#define byRef "Rtek1000"
#define byYear "2022"

#endif /* INC_1_VERSION_H_ */

/*
 * Version control:
 * 0.0.2 - PrintScreen bug (file header, cannot open on Windows)
 *       - PrintScreen bug (USB off)
 *       - Added 1-Version.h file (This one)
 * 0.0.1 - Prelimilary version
 *
 */
