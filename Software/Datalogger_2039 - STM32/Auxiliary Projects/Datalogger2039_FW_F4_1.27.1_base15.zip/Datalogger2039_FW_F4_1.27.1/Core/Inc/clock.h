/*
 * clock.h
 *
 *  Created on: Jun 18, 2023
 *      Author: user
 */

#ifndef INC_CLOCK_H_
#define INC_CLOCK_H_

#include "main.h"

void SystemClock_Config_40MHz(void);

#endif /* INC_CLOCK_H_ */
