/*
 * screen_menu.c
 *
 *  Created on: Jun 25, 2023
 *      Author: user
 */

#include "screen_menu.h"

void menu_LcdScreenMain(void){

}
