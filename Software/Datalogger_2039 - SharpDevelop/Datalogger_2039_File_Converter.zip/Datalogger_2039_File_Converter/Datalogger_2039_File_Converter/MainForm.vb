﻿'
' Created by SharpDevelop.
' User: UserZ
' Date: 09/05/2022
' Time: 19:53
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
imports System
imports System.IO
Imports System.Security
Imports System.Security.Cryptography
Imports System.Text

Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Dim lowRAMmemory As Boolean = False
	
	Dim aplication_name As String = "Datalogger_2039"
	
	Dim title1 As String = aplication_name & " - File Converter - Version 0.0.3 Pre-alpha"
	
	Dim SourceFileFolderSave As String
	Dim SourceFileNameSave As String
	Dim OpenSavedFile As Boolean = False
	
	Dim SourceFileFolder As String
	Dim SourceFileName As String
	
	Dim TotalLineCounter As Integer = 0
	Dim loadFail As Boolean = False
	Dim LoadSuccess As Boolean = False
	
	Dim FirstComponentsCounter As Integer = 0
	
	Dim Firm_Mod As String
	Dim Firm_Ver As String
	Dim uC_ID As String
	Dim MEM_ID As String
	Dim highest_cnt As String
	Dim maxChannel As String
	Dim ch_enabled As String
	Dim temperature_unit As String
	Dim decimal_separator As String
	Dim date_format As String
	
	Dim export_enable As Boolean = False
	
	Dim lines As New List(Of String)()
	
	Sub Timer1Tick(sender As Object, e As EventArgs)
		ToolStripStatusLabel1.Text = DateTime.Now.ToLongDateString
		ToolStripStatusLabel2.Text = DateTime.Now.ToLongTimeString
	End Sub
	
	Sub AboutToolStripMenuItemClick(sender As Object, e As EventArgs)
		msgbox("Datalogger_2039 File Converter (*.dat)" & vbCrLf & "To Spreadsheet Editor (*.csv or *.xls)" & vbCrLf & vbCrLf _
			& "by Rtek1000 - 2022" & vbCrLf & "            Written in SharpDevelop v4.4.1", , "About")
	End Sub
	
	Sub BtnLoadClick(sender As Object, e As EventArgs)
		'source: https://www.devmedia.com.br/openfiledialog-no-vb-net/20427
		
		'define as propriedades do controle
		
		'OpenFileDialog
		
		Me.OpenFileDialog1.Multiselect = False
		
		Me.OpenFileDialog1.Title = "Selecionar Arquivos"
		
		OpenFileDialog1.InitialDirectory = "C:\"
		
		OpenFileDialog1.FileName = "datalogger_2039.dat"
		
		'filtra para exibir somente arquivos de imagens
		
		OpenFileDialog1.Filter = "Datalogger_2039 (*.DAT)|*dat" '|" & "All files (*.*)|*.*"
		
		OpenFileDialog1.CheckFileExists = True
		
		OpenFileDialog1.CheckPathExists = True
		
		OpenFileDialog1.FilterIndex = 2
		
		OpenFileDialog1.RestoreDirectory = True
		
		OpenFileDialog1.ReadOnlyChecked = True
		
		OpenFileDialog1.ShowReadOnly = True
		
		Dim dr As DialogResult = Me.OpenFileDialog1.ShowDialog()
		
		Dim bytes() As Byte = new Byte(0) {0}
		
		If dr = System.Windows.Forms.DialogResult.OK Then
			
			' Le os arquivos selecionados
			
			For Each arquivo As [String] In OpenFileDialog1.FileNames
				
				'txtArquivos.Text += arquivo & vbNewLine
				
				Try
					
					bytes = My.Computer.FileSystem.ReadAllBytes(
						OpenFileDialog1.FileName)
					
					MsgBox(bytes.length, , "bytes") 'ToString.Substring(bytes.length - 11)
					
					'PictureBox1.Image = Image.FromStream(New IO.MemoryStream(bytes))
					
					' Aqui fica o que deve ser executado com os arquivos selecionados.
					
				Catch ex As SecurityException
					
					' O usuário  não possui permissão para ler arquivos
					
					MessageBox.Show((("Erro de segurança Contate o administrador de segurança da rede." & vbLf & vbLf & "Mensagem : ") + ex.Message & vbLf & vbLf & "Detalhes (enviar ao suporte):" & vbLf & vbLf) + ex.StackTrace)
					
				Catch ex As Exception
					
					' Não pode carregar o arquivo (problemas de permissão)
					
					MessageBox.Show(("Não é possível exibir a imagem : " & arquivo.Substring(arquivo.LastIndexOf("\"c))))
					
				End Try
				
				'tbox_Sen1.Text
				
				'MsgBox(Hex(uC_ID(0)), , "bytes")
				
			Next
			
		End If		
	End Sub
	
	Sub BtnGenClick(sender As Object, e As EventArgs)
		Dim myStream As Stream
		Dim saveFileDialog1 As New SaveFileDialog()
		
		saveFileDialog1.Filter = "csv files (*.CSV)|*.csv"
		saveFileDialog1.FilterIndex = 2
		saveFileDialog1.RestoreDirectory = True
		
		If saveFileDialog1.ShowDialog() = DialogResult.OK Then
			myStream = saveFileDialog1.OpenFile()
			If (myStream IsNot Nothing) Then
				' Codigo para escrever o stream
				myStream.Close()
			End If
		End If		
	End Sub
	
	Function HexToInt(hex_str As String) As Integer
		Return Convert.ToInt32(hex_str, 16)
	End Function
	
	Function date_formater (dd As Integer, mm As Integer, yy As Integer) As String
		Dim date_buff As String = ""
		
'		If cbbx_date1.SelectedIndex = 0 Then
'			'	cbbx_date1.Items.Add("yyyy-mm-dd")
'			date_buff = "20" & yy & "-" & mm & "-" & dd
'		Else if cbbx_date1.SelectedIndex = 1 Then
'			'	cbbx_date1.Items.Add("yyyy-dd-mm")
'			date_buff = "20" & yy & "-" & dd & "-" & mm
'		Else if cbbx_date1.SelectedIndex = 1 Then
'			'	cbbx_date1.Items.Add("dd-yyyy-mm")
'			date_buff = dd & "-" & "20" & yy & "-" & mm
'		Else if cbbx_date1.SelectedIndex = 2 Then
'			'	cbbx_date1.Items.Add("dd-mm-yyyy")
'			date_buff = dd & "-" & mm & "-" & "20" & yy
'		Else if cbbx_date1.SelectedIndex = 3 Then
'			'	cbbx_date1.Items.Add("mm-dd-yyyy")
'			date_buff = mm & "-" & dd & "-" & "20" & yy
'		Else if cbbx_date1.SelectedIndex = 4 Then
'			'	cbbx_date1.Items.Add("mm-yyyy-dd")
'			date_buff = mm & "-" & "20" & yy & "-" & dd
'		Else if cbbx_date1.SelectedIndex = 5 Then
'			'	cbbx_date1.Items.Add("yyyy/mm/dd")
'			date_buff = "20" & yy & "/" & mm & "/" & dd
'		Else if cbbx_date1.SelectedIndex = 6 Then
'			'	cbbx_date1.Items.Add("yyyy/dd/mm")
'			date_buff = "20" & yy & "/" & dd & "/" & mm
'		Else if cbbx_date1.SelectedIndex = 7 Then
'			'	cbbx_date1.Items.Add("dd/yyyy/mm")
'			date_buff = dd & "/" & "20" & yy & "/" & mm
'		Else if cbbx_date1.SelectedIndex = 8 Then
'			'	cbbx_date1.Items.Add("dd/mm/yyyy")
'			date_buff = dd & "/" & mm & "/" & "20" & yy
'		Else if cbbx_date1.SelectedIndex = 9 Then
'			'	cbbx_date1.Items.Add("mm/dd/yyyy")
'			date_buff = mm & "/" & dd & "/" & "20" & yy
'		Else 'if cbbx_date1.SelectedIndex = 10 Then
'			'	cbbx_date1.Items.Add("mm/yyyy/dd")
'			date_buff = mm & "/" & "20" & yy & "/" & dd
'		End If
		
		Return date_buff
	End Function
	
	Sub CSV_File_Export
		'	Dim filetext As String = ""
		Dim filetext_line As String = ""
		Dim components() As String
		Dim LineCounter As Integer = 0
		Dim buffer As String = ""
		'	Dim buff2 As String = ""
		Dim component_index As Integer = 0
		Dim TAB_char As Integer = Asc(";") 'TAB = 9, Asc(";") = 59
		Dim dd As String
		Dim mm As String
		Dim yy As String
		
		Dim write_list As New List(Of String)()
		
		If export_enable Then
			updateProgressBar(0)
			
			export_enable = False
			
			For Each line As String In lines
				If(line.ToString <> "") Then
					components = line.Split(Chr(Asc(";"))) 'Regex.Split("\t",line)
					If(components.Length > 0) Then
						If(LineCounter > 1) Then
							' Index
							If components(0).Length > 0 Then
								components(0) = (HexToInt(components(0)) + 1).ToString
							End If
							
							For i = 1 To components.Length - 4 ' without event data
								'							If (cbxCh1.Checked And (i >= 1 And i <= 8)) Or _
								'								(cbxCh2.Checked And (i >= 9 And i <= 16)) Or _
								'								(cbxCh3.Checked And (i >= 17 And i <= 24)) Or _
								'								(cbxCh4.Checked And (i >= 25 And i <= 32)) Or _
								'								(cbxCh5.Checked And (i >= 33 And i <= 40)) Or _
								'								(cbxCh6.Checked And (i >= 41 And i <= 48)) Or _
								'								(cbxCh7.Checked And (i >= 49 And i <= 56)) Or _
								'								(cbxCh8.Checked And (i >= 57 And i <= 64)) Then
								
								If ((i - 1) Mod 8) = 0 Then ' CHx: Date (0B1415) mmddyy
									If components(i).Length = 6 Then
										dd = (HexToInt(components(i).SubString(4))).ToString
										
										If dd.Length = 1 Then
											dd = "0" & dd
										End If
										
										mm = (HexToInt(components(i).SubString(2, 4))).ToString
										
										If mm.Length = 1 Then
											mm = "0" & mm
										End If
										
										yy = (HexToInt(components(i).SubString(0, 2))).ToString
										
										components(i) = (date_formater(Convert.ToInt32(dd), _
											Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
									End If
								Else If i > 1 And ((i - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3) (1017) hhmm
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).SubString(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).SubString(2, 4))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute & ":" & "00"
										
										components(i) = buffer
									End If
								Else If i > 2 And ((i - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
									Dim values_str() As String
									Dim values_byte(2) As Integer
									Dim value_float As Double ' Float
									
									values_str = components(i).Split(Chr(Asc("."))) 'Regex.Split("\.", components(i))
									
									If values_str.Length = 2 Then
										values_byte(0) = HexToInt(values_str(1).Trim)
										values_byte(1) = HexToInt(values_str(0).Trim)
										
										value_float = values_byte(0) * 0.0625
										value_float = value_float + values_byte(1)
										
'										If rbtn_DegF.Selected Then
'											value_float = (value_float * 1.8) + 32
'										End If
										
										components(i) = (value_float).ToString
										
'										If rbtn_Comma.Selected Then
'											components(i) = components(i).Replace(".", ",")
'										End If
									End If
								Else If i > 4 And ((i - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
									If components(i).Length = 2 Then
										components(i) = (HexToInt(components(i).Trim)).ToString
										components(i) = (Val(components(i)) - 127).ToString
									End If
								Else If i > 5 And ((i - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
									If components(i).Length = 2 Then
										components(i) = (HexToInt(components(i).Trim)).ToString
										components(i) = (Val(components(i)) - 127).ToString
									End If
								Else If i > 6 And ((i - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
									If components(i).Length = 2 Then
										Dim batt_f As Double : batt_f = HexToInt(components(i).Trim)
										batt_f = batt_f * 0.004
										batt_f = batt_f + 3.5
										components(i) = (batt_f).ToString
										If components(i).Length > 6 Then
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
										
'										If rbtn_Comma.Selected Then
'											components(i) = components(i).Replace(".", ",")
'										End If
									End If
								Else If i > 7 And ((i - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
									If components(i).Length = 2 Then
										Dim charg_f As Double : charg_f = HexToInt(components(i).Trim)
										charg_f = charg_f * 0.1
										charg_f = charg_f + 7.0
										components(i) = (charg_f).ToString
										If components(i).Length > 6 Then
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
										
'										If rbtn_Comma.Selected Then
'											components(i) = components(i).Replace(".", ",")
'										End If
									End If
								End If
								'							End If
							Next
							
							For i = components.Length - 3 To components.Length - 1 ' event data
								If i = (components.Length - 3) Then ' Event Date
									dd = (HexToInt(components(i).SubString(4))).ToString
									mm = (HexToInt(components(i).SubString(2, 4))).ToString
									yy = (HexToInt(components(i).SubString(0, 2))).ToString
									components(i) = (date_formater(Convert.ToInt32(dd), _
										Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
								Else If i = (components.Length - 2) Then ' Event Time
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).SubString(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).SubString(2, 4))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute & "00"
										
										components(i) = buffer
									End If
								Else If i = (components.Length - 1) Then ' Event Desc.
									components(i) = (HexToInt(components(i).Trim)).ToString
								End If
							Next
						End If
						
						component_index = 0
						
						filetext_line = ""
						
						For Each data_string In components
							'						Log("component_index: " & component_index)
							
							If LineCounter > 1 Then
								If component_index = 0 Then ' Index
									If data_string <> "" Then
										filetext_line = data_string & Chr(TAB_char)
										'Log("filetext_line: " & filetext_line)
									End If
								Else
									'								If (cbxCh1.Checked And (i >= 1 And i <= 8)) Or _
									'									(cbxCh2.Checked And (i >= 9 And i <= 16)) Or _
									'									(cbxCh3.Checked And (i >= 17 And i <= 24)) Or _
									'									(cbxCh4.Checked And (i >= 25 And i <= 32)) Or _
									'									(cbxCh5.Checked And (i >= 33 And i <= 40)) Or _
									'									(cbxCh6.Checked And (i >= 41 And i <= 48)) Or _
									'									(cbxCh7.Checked And (i >= 49 And i <= 56)) Or _
									'									(cbxCh8.Checked And (i >= 57 And i <= 64)) Then
									If component_index > 0 And _
										component_index < (components.Length - 4) And _
										((component_index - 1) Mod 8) = 0 Then ' CHx: Date
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 1 And _
										component_index < (components.Length - 4) And _
										((component_index - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3)
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 2 And _
										component_index < (components.Length - 4) And _
										((component_index - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 3 And _
										component_index < (components.Length - 4) And _
										((component_index - 4) Mod 8) = 0 Then ' CHx: Sensor ID (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 4 And _
										component_index < (components.Length - 4) And _
										((component_index - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 5 And _
										component_index < (components.Length - 4) And _
										((component_index - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 6 And _
										component_index < (components.Length - 4) And _
										((component_index - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 7 And _
										component_index < (components.Length - 4) And _
										((component_index - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									End If
									'								End If
								End If
								
								If component_index = (components.Length - 3) Then ' Event Date
									If data_string <> "" Then
										filetext_line =  filetext_line & Chr(TAB_char) & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 2) Then ' Event Time
									If data_string <> "" Then
										filetext_line = filetext_line & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 1) Then ' Event Desc.
									If data_string <> "" Then
										filetext_line = filetext_line & data_string & Chr(TAB_char)
									End If
								End If
							Else
								Dim data_string_chk As String = data_string
								
								If data_string_chk.Contains(";") Then
									data_string_chk = data_string_chk.Replace(";", "|")
									msgbox("The character ';' has been replaced by '|'",, "Replace delimiter in channel title")
								End If
								filetext_line = filetext_line & data_string_chk & Chr(TAB_char)
							End If
							
							component_index = component_index + 1
							
							If lowRAMmemory Then
								'Exit
							End If
						Next
					End If
				End If
				
				filetext_line = filetext_line '& CRLF
				
				write_list.Add(filetext_line)
				
				LineCounter = LineCounter + 1
				
				'			If LineCounter > 5 Then
				'				Log("test only")
				'				
				'				Exit
				'			End If
				
				updateProgressBar(LineCounter / TotalLineCounter)
				
				'sleep(0)
				
				If lowRAMmemory Then
					'Exit
				End If
			Next
			
			'		File.WriteString(SourceFileFolderSave, SourceFileNameSave, filetext)
			
			'File.WriteList(SourceFileFolderSave, SourceFileNameSave, write_list)
			
			msgbox("Export finished.",, "File exported")
		End If
		
		enable_buttons
	End Sub
	
	Sub enable_buttons
'		Button1.Enabled = True
'		Button2.Enabled = True
'		
'		rbtn_DegF.Enabled = True
'		rbtn_DegC.Enabled = True
'		
'		rbtn_Dot.Enabled = True
'		rbtn_Comma.Enabled = True
'		
'		rbtn_FileCSV.Enabled = True
'		rbtn_FileXLS.Enabled = True
'		
'		cbbx_date1.Enabled = True
'		
'		cbxSaveDefault.Enabled = True
'		
'		cbxCh1.Enabled = True
'		cbxCh2.Enabled = True
'		cbxCh3.Enabled = True
'		cbxCh4.Enabled = True
'		cbxCh5.Enabled = True
'		cbxCh6.Enabled = True
'		cbxCh7.Enabled = True
'		cbxCh8.Enabled = True
	End Sub
	
	Sub updateProgressBar(value_unit As Double)
		value_unit = value_unit * 100
		Dim value As Integer = Convert.ToInt32(value_unit)
		Dim buff As Integer
		
		If value > (progressBar1.Value + 0.01) Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		else If value < (progressBar1.Value - 0.01) Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		else if value = 0 Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		else if value > 0.99 Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		End If
		
'		Dim RAMmemory_buff As Double = 0
'		Dim RAMmemory_timeout As Integer = 0
		
'		Do While ((RAMmemory_buff < 0.0075) And (RAMmemory_timeout <= 5000))
'			Dim RAMmemory As Double : RAMmemory = robot.JVMMemoryFree / 1073741824
'			
'			RAMmemory_buff = RAMmemory
'			
'			'		Log(RAMmemory)
'			
'			If RAMmemory < 0.0075 Then
'				RAMmemory_timeout = RAMmemory_timeout + 1
'				Log("robot.JVMMemoryFree: LOW RAM (" & RAMmemory & ")")
'				
'				If RAMmemory_timeout >= 4999 Then
'					xui.MsgboxAsync("Try closing other programs to free memory, if the problem still persists, try exporting fewer channels at a time.", "Low free RAM memory")
'					
'					lowRAMmemory = True
'				End If
'			End If
'			
'			Sleep(1)
'		Loop
		
		
		'	If RAMmemory < 0.0075 Then
		'		
		'		If lowRAMmemory = False Then
		'			xui.MsgboxAsync("Try closing other programs to free memory, if the problem still persists, try exporting fewer channels at a time.", "Low free RAM memory")
		'		End If
		'		
		'		lowRAMmemory = True
		'		
		'	End If
	End Sub
End Class
