﻿'
' Created by SharpDevelop.
' User: UserZ
' Date: 09/05/2022
' Time: 19:53
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
imports System
imports System.IO
Imports System.Security
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading.Thread

Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Dim lowRAMmemory As Boolean = False
	
	Dim aplication_name As String = "Datalogger_2039"
	
	Dim title1 As String = aplication_name & " - File Converter - Version 0.0.3 Pre-alpha"
	
	Dim SourceFileFolderSave As String
	Dim SourceFileNameSave As String
	Dim OpenSavedFile As Boolean = False
	
	Dim SourceFileFolder As String
	Dim SourceFileName As String
	
	Dim TotalLineCounter As Integer = 0
	Dim loadFail As Boolean = False
	Dim LoadSuccess As Boolean = False
	
	Dim FirstComponentsCounter As Integer = 0
	
	Dim Firm_Mod As String
	Dim Firm_Ver As String
	Dim uC_ID As String
	Dim MEM_ID As String
	Dim highest_cnt As String
	Dim maxChannel As String
	Dim ch_enabled As String
	Dim temperature_unit As String
	Dim decimal_separator As String
	Dim date_format As String
	
	Dim export_enable As Boolean = False
	
	Dim lines As New List(Of String)()
	Dim write_list As New List(Of String)()
	
	Sub Timer1Tick(sender As Object, e As EventArgs)
		ToolStripStatusLabel1.Text = DateTime.Now.ToLongDateString
		ToolStripStatusLabel2.Text = DateTime.Now.ToLongTimeString
	End Sub
	
	Sub AboutToolStripMenuItemClick(sender As Object, e As EventArgs)
		msgbox("Datalogger_2039 File Converter (*.dat)" & vbCrLf & "To Spreadsheet Editor (*.csv or *.xls)" & vbCrLf & vbCrLf _
			& "by Rtek1000 - 2022" & vbCrLf & "            Written in SharpDevelop v4.4.1", , "About")
	End Sub
	
	Sub BtnLoadClick(sender As Object, e As EventArgs)
		OpenFile()	
	End Sub
	
	Sub BtnGenClick(sender As Object, e As EventArgs)
		
		BtnLoad.Enabled = False
		BtnGen.Enabled = False
		
		rbtn_DegF.Enabled = False
		rbtn_DegC.Enabled = False
		
		rbtn_Comma.Enabled = False
		rbtn_Dot.Enabled = False
		
		rbtn_FileCSV.Enabled = False
		rbtn_FileXLS.Enabled = False
		
		cbbx_date1.Enabled = False
		
		cbxSaveDefault.Enabled = False
		
		cbxCh1.Enabled = False
		cbxCh2.Enabled = False
		cbxCh3.Enabled = False
		cbxCh4.Enabled = False
		cbxCh5.Enabled = False
		cbxCh6.Enabled = False
		cbxCh7.Enabled = False
		cbxCh8.Enabled = False
		
		If rbtn_FileCSV.Checked Then
			CSV_Export
		Else if rbtn_FileXLS.Checked Then
			'XLS_Export
		Else
			msgbox("Select file type (*.csv or *.xlsx)" & vbCrLf & "Operation aborted.",, "File export")
		End If	
	End Sub
	
	Function HexToInt(Str As String) As Integer
		Dim Str_tmp As String = Str
		
		For i = 0 To Str_tmp.Length - 1
			If Asc(Str_tmp(i)) < Asc("0") And Asc(Str_tmp(i)) > Asc("9") And _
				Asc(Str_tmp(i)) < Asc("A") And Asc(Str_tmp(i)) > Asc("F") And _
				Asc(Str_tmp(i)) < Asc("a") And Asc(Str_tmp(i)) > Asc("f") Then
				
				Return 0
			End If
		Next
		
		If Str.Length = 0 Or Str.Length > 8 Then
			Return 0
		End If
		
		If Str.Length <> 8 Then
			For i = Str.Length To 7
				Str = "0" & Str
			Next
		End If
		
		'Dim converter As ByteConverter
		Dim res As Integer = Convert.ToInt32(Val("&H" & Str))
		Return res
	End Function
	
	Sub OpenFile()
		LoadSuccess = False
		
		btnGen.Enabled = False
		
		updateProgressBar(0)
		
		Me.OpenFileDialog1.Multiselect = False
		
		Me.OpenFileDialog1.Title = "Selecionar Arquivos"
		
		OpenFileDialog1.InitialDirectory = "C:\"
		
		OpenFileDialog1.FileName = ""
		
		OpenFileDialog1.Filter = "Datalogger_2039 (*.DAT)|*.dat" '|" & "All files (*.*)|*.*"
		
		OpenFileDialog1.CheckFileExists = True
		
		OpenFileDialog1.CheckPathExists = True
		
		OpenFileDialog1.FilterIndex = 2
		
		OpenFileDialog1.RestoreDirectory = True
		
		OpenFileDialog1.ReadOnlyChecked = True
		
		OpenFileDialog1.ShowReadOnly = True
		
		Dim res As DialogResult = Me.OpenFileDialog1.ShowDialog()
		
		If res = System.Windows.Forms.DialogResult.OK Then
			Try
				If OpenFileDialog1.FileName <> "" Then
					'Log("OpenFileDialog1.FileName: " & OpenFileDialog1.FileName)
					loadFile(OpenFileDialog1.FileName)
				End If
				
			Catch ex As SecurityException
				msgbox("User does not have permission to read files" & vbCrLf & vbCrLf & "SecurityException:" & ex.Message,,"OpenFile")
			Catch ex As Exception
				msgbox("File cannot be read (permission error)" & vbCrLf & vbCrLf & "Exception:" & ex.Message,,"OpenFile")
			End Try
		Else
			msgbox("Operation aborted successfully.",, "File open")
		End If	
	End Sub
	
	' source: https://www.authorcode.com/get-the-file-name-from-the-full-path-in-vb-net/
	Function GetFileName(ByVal path As String) As String
		Dim _filename As String = System.IO.Path.GetFileName(path)
		Return _filename
	End Function
	
	Function GetParent(ByVal path As String) As String
		Dim _fileParent As String = System.IO.Directory.GetParent(path).ToString
		Return _fileParent
	End Function
	
	Sub loadFile(fn As String)
		Dim bytes() As Byte = New Byte(0) {0}
		
		SourceFileFolder = GetParent(fn)
		SourceFileName = GetFileName(fn) 'File.GetName(fn).Trim
		
		lines.Clear
		
		Try
			Dim reader As New StreamReader(fn, Encoding.UTF8)
			Dim a as String
			
			Do
				a = reader.ReadLine
				
				If a <> "" Then
					lines.Add(a)
				End If
			Loop Until a Is Nothing
			
			reader.Close()
		Catch
			msgbox("Error: Operation aborted.",, "Load file")
		End Try
		
		MainForm.ActiveForm.Text = title1 & " - File open: " & SourceFileName
		
		loadFail = False
		
		txtfLines.Text = ""
		
		TotalLineCounter = lines.Count
		
		Dim line0 As String = lines.Item(0)
		
		loadFail = header_check(line0)
		
		If loadFail = True Then
			loadFailed
			Return
		End If
		
		updateProgressBar(0)
		
		Dim lines_check(lines.Count) As String
		
		For i = 0 To (lines.Count - 1)
			lines_check(i) = lines.Item(i)
		Next
		
		loadFail = componentsCheck(lines_check)
		
		If loadFail = True Then
			loadFailed
			Return
		End If
		
		decodeLines
		
		updateProgressBar(0.5)
		
		checkDecodedComponents
		
		cbbx_date1.Enabled = True
		
		updateProgressBar(1)
		
		msgbox("File loaded successfully.",, "Load file")
	End Sub
	
	Function header_check(line_in As String) As Boolean
		Dim components() As String = {}
		
		'Log("line_in: " & line_in)
		Try
			components = line_in.Split(Chr(9)) 'Regex.Split("\t", line_in)
			
			'Log("components.Length: " & components.Length)
		Catch
			'Log("header_check Fail")
			'Log(LastException)
		End Try
		
		If components.Length <> 10 Then
			Log("'components.Length = 9' Fail; components.Length: " & _
				components.Length)
			Return True
		End If
		
		' Firm_Mod: Datalogger 2039
		' Firm_Ver: 0.0.1 Beta
		' uC_ID: 0028003B3439471736353438
		' MEM_ID: DF608862CF963C27
		' highest_cnt: A826
		' maxChannel: 8
		' ch_enabled: 255
		' temperature_unit: 1
		' decimal_separator: 1
		' date_format: 0
		
		Firm_Mod = components(0).Trim
		Firm_Ver = components(1).Trim
		uC_ID = components(2).Trim
		MEM_ID  = components(3).Trim
		highest_cnt = components(4).Trim
		maxChannel = components(5).Trim
		ch_enabled = components(6).Trim
		temperature_unit = components(7).Trim
		decimal_separator = components(8).Trim
		date_format = components(9).Trim
		
		'Log("Firm_Mod: " & Firm_Mod)
		
		If Firm_Mod <> "Datalogger 2039" Then
			'ret_LoadFail = True
			Log("'Datalogger 2039' Fail")
			Return True
		End If
		
		If uC_ID.Length <> 24 Then
			Log("'uC:' Fail")
			Return True
		End If
		
		If MEM_ID.Length <> 16 Then
			Log("'mem:' Fail")
			Return True
		End If
		
		If HexToInt(highest_cnt) <> (TotalLineCounter - 2) Then
			Log("LineCounter Fail, highest_cnt: " & highest_cnt & " TotalLineCounter: " & TotalLineCounter)
			Return True
		End If
		
		If IsNumeric(maxChannel) = False Then
			Log("IsNumber maxChannel Fail")
			Return True
		End If
		
		If IsNumeric(ch_enabled) = False Then
			Log("IsNumber ch_enabled Fail")
			Return True
		End If
		
		Dim i_ch_enabled As Integer = Convert.ToInt32(ch_enabled)
		
		If i_ch_enabled = 0 Then
			Log("ch_enabled = 0 Fail")
			Return True
		End If
		
		txtfVersion.Text = Firm_Ver
		txtfUcID.Text = uC_ID
		txtfMemID.Text = MEM_ID
		
		BinaryToChannels(ByteToBinary(Convert.ToByte(ch_enabled), Convert.ToInt32(maxChannel)))
		
		rbtn_DegF.Enabled = True
		rbtn_DegC.Enabled = True
		
		If Convert.ToInt32(temperature_unit) = 0 Then ' TemperatureUnit_F
			rbtn_DegF.Checked = True
			rbtn_DegC.Checked = False
		Else ' TemperatureUnit_C
			rbtn_DegF.Checked = False
			rbtn_DegC.Checked = True
		End If
		
		rbtn_Dot.Enabled = True
		rbtn_Dot.Enabled = True
		
		If Convert.ToInt32(decimal_separator) = 0 Then ' sepDot
			rbtn_Dot.Checked = True
			rbtn_Dot.Checked = False
		Else ' sepComma
			rbtn_Dot.Checked = False
			rbtn_Dot.Checked = True
		End If
		
		If Convert.ToInt32(date_format) = 0 Then ' mmddyy
			cbbx_date1.SelectedIndex = 4
		Else ' ddmmyy
			cbbx_date1.SelectedIndex = 9
		End If
		
		txtfLines.Text = (Convert.ToInt32(TotalLineCounter) - 2).ToString
		btnGen.Enabled = True
		
		LoadSuccess = True
		
		Return False
	End Function
	
	Function ByteToBinary (Number As Byte, channels As Integer) As String
		Dim Result As String = ""
		For i = 0 To (channels - 1)
			If ((Number >> (7 - i)) And 1) = 1 Then
				Result = Result & "1"
			Else
				Result = Result & "0"
			End If
		Next
		
		Return Result
	End Function
	
	Sub loadFailed()
		txtfVersion.Text = ""
		txtfUcID.Text = ""
		txtfMemID.Text = ""
		txtfLines.Text = ""
		
		updateProgressBar(0)
		
		btnGen.Enabled = False
		
		msgbox("File format not recognized.",, "Error!")
	End Sub
	
	Function componentsCheck(lines_in() As String) As Boolean
		Dim LineCounter As Integer = 0
		Dim ComponentsCounter As Integer = 0
		
		For Each line As String In lines_in
			If(line <> "") Then
				ComponentsCounter = 0
				
				For i = 0 To line.Length -1
					If line(i) = Chr(9) Then ' Horizontal Tab code: 9
						ComponentsCounter = ComponentsCounter + 1
					End If
				Next
				
				If LineCounter = 1 Then
					FirstComponentsCounter = ComponentsCounter
				Else If LineCounter > 1 Then
					If FirstComponentsCounter <> ComponentsCounter Then
						msgbox("File header format not recognized.",, "Error!")
						Log("Error: FirstComponentsCounter <> ComponentsCounter")
						Log(FirstComponentsCounter & "<>" & ComponentsCounter)
						'LoadFail = True
						'Exit
						Return True
					End If
				End If
			Else
				'Log("Null line")
			End If
			
			LineCounter = LineCounter + 1
			
			updateProgressBar(LineCounter / TotalLineCounter)
		Next
		
		Return False
	End Function
	
	Sub decodeLines()
		Dim lines2 As New List(Of String)()
		Dim LineCounter As Integer = 0
		
		lines2.Clear
		
		lines2.Add(lines.Item(0))
		
		For Each line As String In lines
			If line <> "" Then
				If LineCounter > 0 Then				
					'					Try
					'					If LineCounter < 4 Then
					'						Log("line: " & line)
					'					End If
					
					Dim data As Byte() = System.Convert.FromBase64String(line)
					
					line = System.Text.ASCIIEncoding.ASCII.GetString(data)
					
					'					If LineCounter < 6 Then
					'						Log(line.Replace(Chr(9), Chr(59)))
					'					End If
					
					If line.LastIndexOf(Chr(9)) = (line.Length - 1) Then
						line = line.Remove(line.Length - 1, 1)
						'Log("True")
					End If
					
					'					If LineCounter < 6 Then
					'						Log(line.Replace(Chr(9), Chr(59)))
					'					End If
					
					lines2.Add(line) 'B64.DecodeStoS(line, "UTF8"))
					
					'					If LineCounter < 4 Then
					'						Log("line: " & line)
					'					End If
					
					'					Catch
					'						'Log("decodeLines Fail")
					'						'Log(LastException)
					'					End Try
				End If
			End If
			
			LineCounter = LineCounter + 1
			
			'		Dim prog_buff As Double
			'		
			'		prog_buff = LineCounter / TotalLineCounter
			'		prog_buff = prog_buff * 0.2
			'		
			'		updateProgressBar(prog_buff)
			
			Sleep(0)
		Next
		
		lines.Clear
		
		lines.AddRange(lines2.ToArray)
		
		lines2.Clear
		
		'		LineCounter = 0
		'		
		'		For Each line As String In lines
		'			If LineCounter < 6 Then
		'				Log("line: " & line)
		'			Else 
		'				exit for
		'			End If
		'			
		'			LineCounter = LineCounter + 1
		'		Next
	End Sub
	
	Sub checkDecodedComponents()
		Dim ComponentsCounter_base64 As Integer = 0
		Dim FirstComponentsCounter_base64 As Integer = 0
		Dim LineCounter As Integer = 0
		
		If(lines.Item(1) <> "") Then
			Dim str As String = lines.Item(1)
			
			ComponentsCounter_base64 = 0
			
			For i = 0 To str.Length -1
				If str(i) = Chr(9) Then ' Horizontal Tab code: 9
					ComponentsCounter_base64 = ComponentsCounter_base64 + 1
				End If
			Next
		End If
		
		FirstComponentsCounter_base64 = ComponentsCounter_base64
		
		loadFail = False
		
		For Each line As String In lines
			If(line <> "") Then
				If(LineCounter > 1) Then
					ComponentsCounter_base64 = 0
					
					For i = 0 To line.Length -1
						If line(i) = Chr(9) Then ' Horizontal Tab code: 9
							ComponentsCounter_base64 = ComponentsCounter_base64 + 1
						End If
					Next
					
					If ComponentsCounter_base64 <> FirstComponentsCounter_base64 Then
						'Log("FirstComponentsCounter_base64: " & FirstComponentsCounter_base64)
						'Log("ComponentsCounter_base64: " & ComponentsCounter_base64)
						'Log("ComponentsCounter_base64 <> FirstComponentsCounter_base64")
						'Log(line)
						loadFail = True
						Exit For 'Exit
					End If
				End If
			End If
			
			LineCounter = LineCounter + 1
			
			'		Dim prog_buff As Double
			'		
			'		prog_buff = LineCounter / TotalLineCounter
			'		prog_buff = prog_buff * 0.8
			'		prog_buff = prog_buff + 0.2
			'		
			'		updateProgressBar(prog_buff)
			
			Sleep(0)
		Next
	End Sub
	
	Sub BinaryToChannels (channels As String)
		Dim numberOfChannels As Integer = 0
		Dim index1 As Integer = 0
		
		For i = 0 To (channels.Length - 1)
			If channels(i) = "1" Then
				numberOfChannels = numberOfChannels + 1
			End If
		Next
		
		For i = 0 To (channels.Length - 1)
			If channels(i) = "1" Then
				If i = 0 Then
					cbxCh1.Enabled = True
					cbxCh1.Checked = True
				Else If i = 1 Then
					cbxCh2.Enabled = True
					cbxCh2.Checked = True
				Else If i = 2 Then
					cbxCh3.Enabled = True
					cbxCh3.Checked = True
				Else If i = 3 Then
					cbxCh4.Enabled = True
					cbxCh4.Checked = True
				Else If i = 4 Then
					cbxCh5.Enabled = True
					cbxCh5.Checked = True
				Else If i = 5 Then
					cbxCh6.Enabled = True
					cbxCh6.Checked = True
				Else If i = 6 Then
					cbxCh7.Enabled = True
					cbxCh7.Checked = True
				Else If i = 7 Then
					cbxCh8.Enabled = True
					cbxCh8.Checked = True
				End If
				
			Else
				If i = 0 Then
					cbxCh1.Enabled = False
					cbxCh1.Checked = False
				Else If i = 1 Then
					cbxCh2.Enabled = False
					cbxCh2.Checked = False
				Else If i = 2 Then
					cbxCh3.Enabled = False
					cbxCh3.Checked = False
				Else If i = 3 Then
					cbxCh4.Enabled = False
					cbxCh4.Checked = False
				Else If i = 4 Then
					cbxCh5.Enabled = False
					cbxCh5.Checked = False
				Else If i = 5 Then
					cbxCh6.Enabled = False
					cbxCh6.Checked = False
				Else If i = 6 Then
					cbxCh7.Enabled = False
					cbxCh7.Checked = False
				Else If i = 7 Then
					cbxCh8.Enabled = False
					cbxCh8.Checked = False
				End If
				
			End If
			
			index1 = index1 + 1
		Next
	End Sub
	
	Sub Log(str As String)
		Debug.write(str & vbCrLf)
	End Sub
	
	Function date_formater (dd As Integer, mm As Integer, yy As Integer) As String
		Dim date_buff As String = ""
		
		If cbbx_date1.SelectedIndex = 0 Then
			'	cbbx_date1.Items.Add("yyyy-mm-dd")
			date_buff = "20" & yy & "-" & mm & "-" & dd
		Else if cbbx_date1.SelectedIndex = 1 Then
			'	cbbx_date1.Items.Add("yyyy-dd-mm")
			date_buff = "20" & yy & "-" & dd & "-" & mm
		Else if cbbx_date1.SelectedIndex = 1 Then
			'	cbbx_date1.Items.Add("dd-yyyy-mm")
			date_buff = dd & "-" & "20" & yy & "-" & mm
		Else if cbbx_date1.SelectedIndex = 2 Then
			'	cbbx_date1.Items.Add("dd-mm-yyyy")
			date_buff = dd & "-" & mm & "-" & "20" & yy
		Else if cbbx_date1.SelectedIndex = 3 Then
			'	cbbx_date1.Items.Add("mm-dd-yyyy")
			date_buff = mm & "-" & dd & "-" & "20" & yy
		Else if cbbx_date1.SelectedIndex = 4 Then
			'	cbbx_date1.Items.Add("mm-yyyy-dd")
			date_buff = mm & "-" & "20" & yy & "-" & dd
		Else if cbbx_date1.SelectedIndex = 5 Then
			'	cbbx_date1.Items.Add("yyyy/mm/dd")
			date_buff = "20" & yy & "/" & mm & "/" & dd
		Else if cbbx_date1.SelectedIndex = 6 Then
			'	cbbx_date1.Items.Add("yyyy/dd/mm")
			date_buff = "20" & yy & "/" & dd & "/" & mm
		Else if cbbx_date1.SelectedIndex = 7 Then
			'	cbbx_date1.Items.Add("dd/yyyy/mm")
			date_buff = dd & "/" & "20" & yy & "/" & mm
		Else if cbbx_date1.SelectedIndex = 8 Then
			'	cbbx_date1.Items.Add("dd/mm/yyyy")
			date_buff = dd & "/" & mm & "/" & "20" & yy
		Else if cbbx_date1.SelectedIndex = 9 Then
			'	cbbx_date1.Items.Add("mm/dd/yyyy")
			date_buff = mm & "/" & dd & "/" & "20" & yy
		Else 'if cbbx_date1.SelectedIndex = 10 Then
			'	cbbx_date1.Items.Add("mm/yyyy/dd")
			date_buff = mm & "/" & "20" & yy & "/" & dd
		End If
		
		Return date_buff
	End Function
	
	Private Sub CSV_Export
		Dim fn As String
		
		Dim filename As String = GetFilename(SourceFileName).SubString(0, GetFilename(SourceFileName).IndexOf(".dat"))
		
		'Dim myStream As Stream
		Dim saveFileDialog1 As New SaveFileDialog()
		
		saveFileDialog1.FileName = filename & ".csv"
		saveFileDialog1.Filter = "csv files (*.CSV)|*.csv"
		saveFileDialog1.FilterIndex = 2
		saveFileDialog1.RestoreDirectory = True
		
		If saveFileDialog1.ShowDialog() = DialogResult.OK Then
			fn = saveFileDialog1.FileName
			
			'Log("fn: " & fn)
			
			If fn <> "" Then
				export_enable = True
				
				SourceFileFolderSave = GetParent(fn)
				SourceFileNameSave = GetFileName(fn)
				
				CSV_File_Export
			End If
			
			'			myStream = saveFileDialog1.OpenFile()
			'			If (myStream IsNot Nothing) Then
			'				' Codigo para escrever o stream
			'				myStream.Close()
			'			End If
		Else
			msgbox("Operation aborted successfully.",, "File save")
			
			enable_buttons
			Return
		End If	
		'		
		'		Try
		'			SourceFileFolderSave = SourceFileFolder 'kvs.Get("previous_save_path")
		'			'Log("previous_save_path: " & SourceFileFolderSave)
		'		Catch
		'			Log("kvs.Get('previous_save_path') FAIL")
		'			'Log(LastException)
		'		End Try
		'		
		'		Dim a As FileChooser
		'		a.Initialize
		'		
		'		If File.IsDirectory(SourceFileFolderSave, "") Then
		'			a.InitialDirectory = SourceFileFolderSave
		'		Else
		'			a.InitialDirectory = File.DirApp
		'		End If
		'		
		'		a.Title = "File save"
		'		'a.InitialFileName = filename & ".xlsx"
		'		'a.setExtensionFilter("Spreadsheet file", Array As String("*.xlsx"))
		'		a.InitialFileName = filename & ".csv"
		'		a.setExtensionFilter("Delimited text file", Array As String("*.csv"))
		'		
		'		fn = a.ShowSave(MainForm)
		'		
		'		If fn = "" Then
		'			xui.MsgboxAsync("Operation aborted successfully.", "File save")
		'			
		'			enable_buttons
		'			Return
		'		Else
		'			'		Dim sf As Object = xui.Msgbox2Async("Do you want to open the file after saving?", "View file", "No", "Cancel", "Yes", Null)
		'			'		Wait For (sf) Msgbox_Result (Result As Int)
		'			'		If Result = xui.DialogResponse_Negative Then
		'			'			OpenSavedFile = False
		'			'		Else If Result = xui.DialogResponse_Cancel Then
		'			'			xui.MsgboxAsync("Operation aborted successfully.", "File save")
		'			'			Return
		'			'		Else
		'			'			OpenSavedFile = True
		'			'		End If
		'			
		'			SourceFileFolderSave = File.GetFileParent(fn)
		'			SourceFileNameSave = File.GetName(fn).Trim
		'			
		'			Try
		'				kvs.Put("previous_save_path", SourceFileFolderSave)
		'				Log("previous_save_path: " & SourceFileFolderSave)
		'			Catch
		'				Log(LastException)
		'			End Try
		'			
		'			MainForm.Title = title1 & " - File save: " & SourceFileNameSave
		'			
		'			'		Button1.Enabled = False
		'			'		Button2.Enabled = False
		'			
		'			'		Thread1.Initialise("Thread1")
		'			'		Thread1.Name = aplication_name & " Thread 1"
		'			'		Thread1.Start(Null, "CSV_File_Export", args1)
		'			export_enable = True
		'			
		'			CSV_File_Export
		'			
		'			'		Button1.Enabled = True
		'			'		Button2.Enabled = True
		'			
		'		End If
		'	StopMessageLoop 'non-ui
	End Sub
	
	Sub CSV_File_Export()
		'	Dim filetext As String = ""
		Dim filetext_line As String = ""
		Dim components() As String
		Dim LineCounter As Integer = 0
		Dim buffer As String = ""
		'	Dim buff2 As String = ""
		Dim component_index As Integer = 0
		Dim TAB_char As Integer = Asc(";") 'TAB = 9, Asc(";") = 59
		Dim dd As String
		Dim mm As String
		Dim yy As String
		
		write_list.Clear
		
		If export_enable Then
			updateProgressBar(0)
			
			export_enable = False
			
			For Each line As String In lines
				'				If(LineCounter < 6) Then
				'					Log("LineCounter: " & LineCounter)
				'					Log("line: " & line)
				'				End If
				
				If(line <> "") Then
					'					If LineCounter < 6 Then
					'						Log(line.Replace(Chr(9), Chr(59)))
					'					End If
					
					components = line.Split(Chr(9)) 'Regex.Split("\t",line)
					
					'					If LineCounter < 6 Then
					'						Log("components.Length: " & components.Length)
					'					End If
					
					'components.Resize(
					'					If(LineCounter = 1) Then
					'						Log("LineCounter: " & LineCounter)
					'						Log("components.Length: " & components.Length)
					'						Log("line: " & line.Replace(Chr(9), Chr(59)))
					'					End If
					
					'					If(LineCounter < 6) Then
					'						Log("components.Length: " & components.Length)
					'					End If
					
					If(components.Length > 0) Then
						If(LineCounter > 1) Then
							' Index
							If components(0).Length > 0 Then
								components(0) = (HexToInt(components(0)) + 1).ToString
							Else
								Log("Index: components(0).Length <= 0")
							End If
							
							For i = 1 To components.Length - 6 ' without event data
								'								Log("i: " & i)
								'								Log("components(i): " & components(i))
								'							If (cbxCh1.Checked And (i >= 1 And i <= 8)) Or _
								'								(cbxCh2.Checked And (i >= 9 And i <= 16)) Or _
								'								(cbxCh3.Checked And (i >= 17 And i <= 24)) Or _
								'								(cbxCh4.Checked And (i >= 25 And i <= 32)) Or _
								'								(cbxCh5.Checked And (i >= 33 And i <= 40)) Or _
								'								(cbxCh6.Checked And (i >= 41 And i <= 48)) Or _
								'								(cbxCh7.Checked And (i >= 49 And i <= 56)) Or _
								'								(cbxCh8.Checked And (i >= 57 And i <= 64)) Then
								
								If ((i - 1) Mod 8) = 0 Then ' CHx: Date (0B1415) mmddyy
									If components(i).Length = 6 Then
										dd = (HexToInt(components(i).SubString(4, 2))).ToString
										
										If dd.Length = 1 Then
											dd = "0" & dd
										End If
										
										mm = (HexToInt(components(i).SubString(2, 2))).ToString
										
										If mm.Length = 1 Then
											mm = "0" & mm
										End If
										
										yy = (HexToInt(components(i).SubString(0, 2))).ToString
										
										components(i) = (date_formater(Convert.ToInt32(dd), _
											Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
									End If
								Else If i > 1 And ((i - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3) (1017) hhmm
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).SubString(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).SubString(2, 2))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute '& ":" & "00"
										
										components(i) = buffer
									End If
								Else If i > 2 And ((i - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
									Dim values_str() As String
									Dim values_byte(2) As Integer
									Dim value_float As Double ' Float
									
									values_str = components(i).Split(Chr(Asc("."))) 'Regex.Split("\.", components(i))
									
									If values_str.Length = 2 Then
										values_byte(0) = HexToInt(values_str(1).Trim)
										values_byte(1) = HexToInt(values_str(0).Trim)
										
										value_float = values_byte(0) * 0.0625
										value_float = value_float + values_byte(1)
										
										'										If rbtn_DegF.Selected Then
										'											value_float = (value_float * 1.8) + 32
										'										End If
										
										components(i) = (value_float).ToString
										
										'										If rbtn_Comma.Selected Then
										'											components(i) = components(i).Replace(".", ",")
										'										End If
									End If
								Else If i > 4 And ((i - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
									If components(i).Length = 2 Then
										components(i) = (HexToInt(components(i).Trim)).ToString
										components(i) = (Val(components(i)) - 127).ToString
									End If
								Else If i > 5 And ((i - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
									If components(i).Length = 2 Then
										components(i) = (HexToInt(components(i).Trim)).ToString
										components(i) = (Val(components(i)) - 127).ToString
									End If
								Else If i > 6 And ((i - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
									If components(i).Length = 2 Then
										Dim batt_f As Double : batt_f = HexToInt(components(i).Trim)
										batt_f = batt_f * 0.004
										batt_f = batt_f + 3.5
										components(i) = (batt_f).ToString
										If components(i).Length > 6 Then
											Log("components(i): " & components(i))
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
										
										'										If rbtn_Comma.Selected Then
										'											components(i) = components(i).Replace(".", ",")
										'										End If
									End If
								Else If i > 7 And ((i - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
									If components(i).Length = 2 Then
										Dim charg_f As Double : charg_f = HexToInt(components(i).Trim)
										charg_f = charg_f * 0.1
										charg_f = charg_f + 7.0
										components(i) = (charg_f).ToString
										If components(i).Length > 6 Then
											'Log("components(i): " & components(i))
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
										
										'										If rbtn_Comma.Selected Then
										'											components(i) = components(i).Replace(".", ",")
										'										End If
									End If
								End If
								'							End If
							Next
							
							For i = components.Length - 3 To components.Length - 1 ' event data
								'								Log("i: " & i)
								'								Log("components(i): " & components(i))
								If i = (components.Length - 3) Then ' Event Date
									dd = (HexToInt(components(i).SubString(4, 2))).ToString
									mm = (HexToInt(components(i).SubString(2, 2))).ToString
									yy = (HexToInt(components(i).SubString(0, 2))).ToString
									components(i) = (date_formater(Convert.ToInt32(dd), _
										Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
								Else If i = (components.Length - 2) Then ' Event Time
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).SubString(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).SubString(2, 2))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute '& ":00"
										
										components(i) = buffer
									End If
								Else If i = (components.Length - 1) Then ' Event Desc.
									components(i) = (HexToInt(components(i).Trim)).ToString
								End If
							Next
						End If
						
						component_index = 0
						
						filetext_line = ""
						
						For Each data_string In components
							'						Log("component_index: " & component_index)
							
							If LineCounter > 1 Then
								If component_index = 0 Then ' Index
									If data_string <> "" Then
										filetext_line = data_string & Chr(TAB_char)
										'Log("filetext_line: " & filetext_line)
									End If
								Else
									'								If (cbxCh1.Checked And (i >= 1 And i <= 8)) Or _
									'									(cbxCh2.Checked And (i >= 9 And i <= 16)) Or _
									'									(cbxCh3.Checked And (i >= 17 And i <= 24)) Or _
									'									(cbxCh4.Checked And (i >= 25 And i <= 32)) Or _
									'									(cbxCh5.Checked And (i >= 33 And i <= 40)) Or _
									'									(cbxCh6.Checked And (i >= 41 And i <= 48)) Or _
									'									(cbxCh7.Checked And (i >= 49 And i <= 56)) Or _
									'									(cbxCh8.Checked And (i >= 57 And i <= 64)) Then
									If component_index > 0 And _
										component_index < (components.Length - 4) And _
										((component_index - 1) Mod 8) = 0 Then ' CHx: Date
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 1 And _
										component_index < (components.Length - 4) And _
										((component_index - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3)
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 2 And _
										component_index < (components.Length - 4) And _
										((component_index - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 3 And _
										component_index < (components.Length - 4) And _
										((component_index - 4) Mod 8) = 0 Then ' CHx: Sensor ID (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 4 And _
										component_index < (components.Length - 4) And _
										((component_index - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 5 And _
										component_index < (components.Length - 4) And _
										((component_index - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 6 And _
										component_index < (components.Length - 4) And _
										((component_index - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 7 And _
										component_index < (components.Length - 4) And _
										((component_index - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									End If
									'								End If
								End If
								
								If component_index = (components.Length - 3) Then ' Event Date
									If data_string <> "" Then
										filetext_line =  filetext_line & Chr(TAB_char) & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 2) Then ' Event Time
									If data_string <> "" Then
										filetext_line = filetext_line & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 1) Then ' Event Desc.
									If data_string <> "" Then
										filetext_line = filetext_line & data_string '& Chr(TAB_char)
									End If
								End If
							Else
								Dim data_string_chk As String = data_string
								
								If data_string_chk.Contains(";") Then
									data_string_chk = data_string_chk.Replace(";", "|")
									msgbox("The character ';' has been replaced by '|'",, "Replace delimiter in channel title")
								End If
								
								If component_index <> (components.Length - 1) Then 
									filetext_line = filetext_line & data_string_chk & Chr(TAB_char)
								Else 
									filetext_line = filetext_line & data_string_chk
								End If
							End If
							
							component_index = component_index + 1
							
							If lowRAMmemory Then
								'Exit
							End If
						Next
					End If
				End If
				
				'filetext_line = filetext_line '& CRLF
				
				write_list.Add(filetext_line)
				
				LineCounter = LineCounter + 1
				
				'			If LineCounter > 5 Then
				'				Log("test only")
				'				
				'				Exit
				'			End If
				
				updateProgressBar(LineCounter / TotalLineCounter)
				
				sleep(0)
				
				If lowRAMmemory Then
					'Exit
				End If
			Next
			
			'		File.WriteString(SourceFileFolderSave, SourceFileNameSave, filetext)
			
			'File.WriteList(SourceFileFolderSave, SourceFileNameSave, write_list)
			
			file_writer
			
			msgbox("Export finished.",, "File exported")
		End If
		
		enable_buttons
	End Sub
	
	Sub file_writer()
		Using StreamWriter1 As New System.IO.StreamWriter(SourceFileFolderSave & "\" & SourceFileNameSave)
			For Each item As String In write_list
				'StreamWriter1.WriteLine(item)
				StreamWriter1.Write(item & vbLf)
			Next
			StreamWriter1.Flush()
			StreamWriter1.Close()
		End Using
	End Sub
	
	Sub enable_buttons
		btnLoad.Enabled = True
		btnGen.Enabled = True
		
		rbtn_DegF.Enabled = True
		rbtn_DegC.Enabled = True
		
		rbtn_Comma.Enabled = True
		rbtn_Dot.Enabled = True
		
		rbtn_FileCSV.Enabled = True
		rbtn_FileXLS.Enabled = True
		
		cbbx_date1.Enabled = True
		
		cbxSaveDefault.Enabled = True
		
		cbxCh1.Enabled = True
		cbxCh2.Enabled = True
		cbxCh3.Enabled = True
		cbxCh4.Enabled = True
		cbxCh5.Enabled = True
		cbxCh6.Enabled = True
		cbxCh7.Enabled = True
		cbxCh8.Enabled = True
	End Sub
	
	Sub updateProgressBar(value_unit As Double)
		value_unit = value_unit * 100
		Dim value As Integer = Convert.ToInt32(value_unit)
		Dim buff As Integer
		
		If value > (progressBar1.Value + 0.01) Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		else If value < (progressBar1.Value - 0.01) Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		else if value = 0 Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		else if value > 0.99 Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		End If
		
		'		Dim RAMmemory_buff As Double = 0
		'		Dim RAMmemory_timeout As Integer = 0
		
		'		Do While ((RAMmemory_buff < 0.0075) And (RAMmemory_timeout <= 5000))
		'			Dim RAMmemory As Double : RAMmemory = robot.JVMMemoryFree / 1073741824
		'			
		'			RAMmemory_buff = RAMmemory
		'			
		'			'		Log(RAMmemory)
		'			
		'			If RAMmemory < 0.0075 Then
		'				RAMmemory_timeout = RAMmemory_timeout + 1
		'				Log("robot.JVMMemoryFree: LOW RAM (" & RAMmemory & ")")
		'				
		'				If RAMmemory_timeout >= 4999 Then
		'					msgbox("Try closing other programs to free memory, if the problem still persists, try exporting fewer channels at a time.", "Low free RAM memory")
		'					
		'					lowRAMmemory = True
		'				End If
		'			End If
		'			
		'			Sleep(1)
		'		Loop
		
		
		'	If RAMmemory < 0.0075 Then
		'		
		'		If lowRAMmemory = False Then
		'			msgbox("Try closing other programs to free memory, if the problem still persists, try exporting fewer channels at a time.", "Low free RAM memory")
		'		End If
		'		
		'		lowRAMmemory = True
		'		
		'	End If
	End Sub
	
	Sub MainFormLoad(sender As Object, e As EventArgs)
		cbbx_date1.Items.Add("yyyy-mm-dd")
		cbbx_date1.Items.Add("yyyy-dd-mm")
		
		cbbx_date1.Items.Add("dd-yyyy-mm")
		cbbx_date1.Items.Add("dd-mm-yyyy")
		
		cbbx_date1.Items.Add("mm-dd-yyyy")
		cbbx_date1.Items.Add("mm-yyyy-dd")
		
		cbbx_date1.Items.Add("yyyy/mm/dd")
		cbbx_date1.Items.Add("yyyy/dd/mm")
		
		cbbx_date1.Items.Add("dd/yyyy/mm")
		cbbx_date1.Items.Add("dd/mm/yyyy")
		
		cbbx_date1.Items.Add("mm/dd/yyyy")
		cbbx_date1.Items.Add("mm/yyyy/dd")
		cbbx_date1.SelectedIndex = 0		
	End Sub
	
	Sub ENToolStripMenuItemClick(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub ESToolStripMenuItemClick(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub PTToolStripMenuItemClick(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub Rbtn_FileXLSCheckedChanged(sender As Object, e As EventArgs)
		If Rbtn_FileXLS.Checked = True Then
			MsgBox("Not implemented!", , "Sorry!")	
			Rbtn_FileXLS.Checked = False
			Rbtn_FileCSV.Checked = True
		End If
	End Sub
End Class
