﻿'
' Created by SharpDevelop.
' User: UserZ
' Date: 09/05/2022
' Time: 19:53
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
imports System
imports System.IO
Imports System.Security
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading.Thread
Imports ClosedXML.Excel
Imports Microsoft.VisualBasic.Devices

Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Dim lowRAMmemory As Boolean = False
	
	Dim debug_load_file As Boolean = False
	Dim debug_export_csv As Boolean = False
	
	Dim aplication_name As String = "Datalogger_2039"
	
	Dim title1 As String = aplication_name & " - File Converter - Version 0.0.4 Pre-alpha"
	
	Dim SourceFileFolderSave As String
	Dim SourceFileNameSave As String
	Dim OpenSavedFile As Boolean = False
	
	Dim SourceFileFolder As String
	Dim SourceFileName As String
	
	Dim TotalLineCounter As Integer = 0
	Dim loadFail As Boolean = False
	Dim LoadSuccess As Boolean = False
	
	Dim FirstComponentsCounter As Integer = 0
	
	Dim Firm_Mod As String
	Dim Firm_Ver As String
	Dim uC_ID As String
	Dim MEM_ID As String
	Dim highest_cnt As String
	Dim maxChannel As String
	Dim ch_enabled As String
	Dim temperature_unit As String
	Dim decimal_separator As String
	Dim date_format As String
	Dim language_current As String
	Dim	file_type As String
	
	Dim export_enable As Boolean = False
	
	Dim lines As New List(Of String)()
	Dim write_list As New List(Of String)()
	
	Dim firstTime As Integer = 0
	
	Sub MainFormLoad(sender As Object, e As EventArgs)
		cbbx_date1.Items.Add("yyyy-mm-dd")
		cbbx_date1.Items.Add("yyyy-dd-mm")
		
		cbbx_date1.Items.Add("dd-yyyy-mm")
		cbbx_date1.Items.Add("dd-mm-yyyy")
		
		cbbx_date1.Items.Add("mm-dd-yyyy")
		cbbx_date1.Items.Add("mm-yyyy-dd")
		
		cbbx_date1.Items.Add("yyyy/mm/dd")
		cbbx_date1.Items.Add("yyyy/dd/mm")
		
		cbbx_date1.Items.Add("dd/yyyy/mm")
		cbbx_date1.Items.Add("dd/mm/yyyy")
		
		cbbx_date1.Items.Add("mm/dd/yyyy")
		cbbx_date1.Items.Add("mm/yyyy/dd")
		cbbx_date1.SelectedIndex = 0
		
		'For i = 0 To 63
		'	Log(base10to64(i))
		'Next
		
		'For i = -1000 To -1063 Step -1
		'	Log(base64to10(base10to64(i)).ToString)
		'Next
		
	End Sub
	
	Sub Timer1Tick(sender As Object, e As EventArgs)
		If firstTime = 0 Then
			MainForm.ActiveForm.Text = title1
			firstTime = 1
		End If
		
		ToolStripStatusLabel1.Text = "Now: " & DateTime.Now.ToLongDateString & ", " & _
			DateTime.Now.ToLongTimeString & " | " & getAvailableRAM() & " | Source file: " & SourceFileName
		'ToolStripStatusLabel2.Text = DateTime.Now.ToLongTimeString
	End Sub
	
	Sub BtnLoadClick(sender As Object, e As EventArgs)
		OpenFile()	
	End Sub
	
	Sub BtnGenClick(sender As Object, e As EventArgs)
		
		BtnLoad.Enabled = False
		BtnGen.Enabled = False
		
		rbtn_DegF.Enabled = False
		rbtn_DegC.Enabled = False
		
		rbtn_Comma.Enabled = False
		rbtn_Dot.Enabled = False
		
		rbtn_FileCSV.Enabled = False
		rbtn_FileXLS.Enabled = False
		
		cbbx_date1.Enabled = False
		
		cbxSaveDefault.Enabled = False
		
		cbxCh1.Enabled = False
		cbxCh2.Enabled = False
		cbxCh3.Enabled = False
		cbxCh4.Enabled = False
		cbxCh5.Enabled = False
		cbxCh6.Enabled = False
		cbxCh7.Enabled = False
		cbxCh8.Enabled = False
		
		If rbtn_FileCSV.Checked Then
			CSV_Export
		Else if rbtn_FileXLS.Checked Then
			XLS_Export
			'create_xlsx
		Else
			msgbox("Select file type (*.csv or *.xlsx)" & vbCrLf & "Operation aborted.",, "File export")
		End If	
	End Sub
	
	Function HexToInt(Str As String) As Integer
		Dim Str_tmp As String = Str
		
		For i = 0 To Str_tmp.Length - 1
			If Asc(Str_tmp(i)) < Asc("0") And Asc(Str_tmp(i)) > Asc("9") And _
				Asc(Str_tmp(i)) < Asc("A") And Asc(Str_tmp(i)) > Asc("F") And _
				Asc(Str_tmp(i)) < Asc("a") And Asc(Str_tmp(i)) > Asc("f") Then
				Log("HexToInt invalid input")
				Return 0
			End If
		Next
		
		If Str.Length = 0 Or Str.Length > 8 Then
			Log("HexToInt invalid length")
			Return 0
		End If
		
		If Str.Length <> 8 Then
			For i = Str.Length To 7
				Str = "0" & Str
			Next
		End If
		
		'Dim converter As ByteConverter
		Dim res As Integer = Convert.ToInt32(Val("&H" & Str))
		Return res
	End Function
	
	Sub OpenFile()
		LoadSuccess = False
		
		btnGen.Enabled = False
		
		updateProgressBar(0)
		
		Me.OpenFileDialog1.Multiselect = False
		
		Me.OpenFileDialog1.Title = "File select"
		
		OpenFileDialog1.InitialDirectory = "C:\"
		
		OpenFileDialog1.FileName = ""
		
		OpenFileDialog1.Filter = "Datalogger_2039 (*.DAT)|*.dat" '|" & "All files (*.*)|*.*"
		
		OpenFileDialog1.CheckFileExists = True
		
		OpenFileDialog1.CheckPathExists = True
		
		OpenFileDialog1.FilterIndex = 2
		
		OpenFileDialog1.RestoreDirectory = True
		
		OpenFileDialog1.ReadOnlyChecked = True
		
		OpenFileDialog1.ShowReadOnly = True
		
		Dim res As DialogResult = Me.OpenFileDialog1.ShowDialog()
		
		If res = System.Windows.Forms.DialogResult.OK Then
			'			Try
			If OpenFileDialog1.FileName <> "" Then
				'Log("OpenFileDialog1.FileName: " & OpenFileDialog1.FileName)
				loadFile(OpenFileDialog1.FileName)
			Else
				Log("OpenFile invalid FileName")
			End If
			
			'			Catch ex As SecurityException
			'				msgbox("User does not have permission to read files" & vbCrLf & vbCrLf & "SecurityException:" & ex.Message,,"OpenFile")
			'			Catch ex As Exception
			'				msgbox("File cannot be read (permission error)" & vbCrLf & vbCrLf & "Exception:" & ex.Message,,"OpenFile")
			'			End Try
		Else
			msgbox("Operation aborted successfully.",, "File open")
		End If	
	End Sub
	
	' source: https://www.authorcode.com/get-the-file-name-from-the-full-path-in-vb-net/
	Function GetFileName(ByVal path As String) As String
		Dim _filename As String = System.IO.Path.GetFileName(path)
		Return _filename
	End Function
	
	Function GetParent(ByVal path As String) As String
		Dim _fileParent As String = System.IO.Directory.GetParent(path).ToString
		Return _fileParent
	End Function
	
	Sub loadFile(fn As String)
		Dim bytes() As Byte = New Byte(0) {0}
		
		SourceFileFolder = GetParent(fn)
		SourceFileName = GetFileName(fn) 'File.GetName(fn).Trim
		
		lines.Clear
		
		Try
			Dim reader As New StreamReader(fn, Encoding.UTF8)
			Dim a As String
			Dim line_cnt As Integer
			
			line_cnt = 0
			
			Do
				a = reader.ReadLine
				
				If a <> "" Then
					lines.Add(a)
				Else
					Log("[loadFile] Line " & line_cnt & ": loadFile null ReadLine")
				End If
				
				line_cnt = line_cnt + 1
				
				Application.DoEvents
			Loop Until a Is Nothing
			
			reader.Close()
		Catch
			msgbox("Error: Operation aborted.",, "Load file")
		End Try
		
		loadFail = False
		
		txtfLines.Text = ""
		
		TotalLineCounter = lines.Count
		
		Dim line0 As String = lines.Item(0)
		
		loadFail = header_check(line0)
		
		If loadFail = True Then
			loadFailed
			
			Log("[loadFile] header_check fail")
			Return
		End If
		
		updateProgressBar(0)
		
		If Val(file_type) = 0 Then
			decodeLines16
		Else If Val(file_type) = 2 Then
			decodeLines64
		End If
		
		Dim lines_check(lines.Count) As String
		
		For i = 0 To (lines.Count - 1)
			lines_check(i) = lines.Item(i)
		Next
		
		loadFail = componentsCheck(lines_check)
		
		If loadFail = True Then
			loadFailed
			
			Log("[loadFile] componentsCheck fail")
			Return
		End If
		
		updateProgressBar(0.5)
		
		checkDecodedComponents
		
		cbbx_date1.Enabled = True
		
		updateProgressBar(1)
		
		msgbox("File loaded successfully.",, "Load file")
	End Sub
	
	Function header_check(line_in As String) As Boolean
		Dim components() As String = {}
		
		Try
			components = line_in.Split(Chr(59)) 'Regex.Split("\t", line_in)
		Catch
			'Log("header_check Fail")
			'Log(LastException)
		End Try
		
		If components.Length <> 12 Then
			Log("[header_check] 'components.Length = 12' Fail; components.Length: " & _
				components.Length)
			Return True
		End If
		
		' Firm_Mod: Datalogger 2039
		' Firm_Ver: 0.0.1 Beta
		' uC_ID: 0028003B3439471736353438
		' MEM_ID: DF608862CF963C27
		' highest_cnt: A826
		' maxChannel: 8
		' ch_enabled: 255
		' temperature_unit: 1
		' decimal_separator: 1
		' date_format: 0
		' language_current: 0
		' file_type: 2
		
		Firm_Mod = components(0).Trim
		Firm_Ver = components(1).Trim
		uC_ID = components(2).Trim
		MEM_ID  = components(3).Trim
		highest_cnt = components(4).Trim
		maxChannel = components(5).Trim
		ch_enabled = components(6).Trim
		temperature_unit = components(7).Trim
		decimal_separator = components(8).Trim
		date_format = components(9).Trim
		language_current = components(10).Trim
		file_type = components(11).Trim
		
		'Log("file_type: " & file_type)
		
		If file_type <> "0" And file_type <> "2" Then
			Log("[header_check] 'file_type' Fail")
			MsgBox("File not recognized", ,"File open")
			Return True
		End If
		
		If Firm_Mod <> "Datalogger 2039" Then
			Log("[header_check] 'Datalogger 2039' Fail")
			Return True
		End If
		
		If uC_ID.Length <> 24 Then
			Log("[header_check] 'uC:' Fail")
			Return True
		End If
		
		If MEM_ID.Length <> 16 Then
			Log("[header_check] 'mem:' Fail")
			Return True
		End If
		
		If val(highest_cnt) <> (TotalLineCounter - 2) Then
			Log("[header_check] LineCounter Fail, highest_cnt: " & highest_cnt & " TotalLineCounter: " & (TotalLineCounter - 2))
			Return True
		End If
		
		If IsNumeric(maxChannel) = False Then
			Log("[header_check] IsNumber maxChannel Fail")
			Return True
		End If
		
		If IsNumeric(ch_enabled) = False Then
			Log("[header_check] IsNumber ch_enabled Fail")
			Return True
		End If
		
		Dim i_ch_enabled As Integer = Convert.ToInt32(ch_enabled)
		
		If i_ch_enabled = 0 Then
			Log("[header_check] ch_enabled = 0 Fail")
			Return True
		End If
		
		txtfVersion.Text = Firm_Ver
		txtfUcID.Text = uC_ID
		txtfMemID.Text = MEM_ID
		
		BinaryToChannels(ByteToBinary(Convert.ToByte(ch_enabled), Convert.ToInt32(maxChannel)))
		
		rbtn_DegF.Enabled = True
		rbtn_DegC.Enabled = True
		
		If Convert.ToInt32(temperature_unit) = 0 Then ' TemperatureUnit_F
			rbtn_DegF.Checked = True
			rbtn_DegC.Checked = False
		Else ' TemperatureUnit_C
			rbtn_DegF.Checked = False
			rbtn_DegC.Checked = True
		End If
		
		rbtn_Dot.Enabled = True
		rbtn_Dot.Enabled = True
		
		If Convert.ToInt32(decimal_separator) = 0 Then ' sepDot
			rbtn_Dot.Checked = True
			rbtn_Dot.Checked = False
		Else ' sepComma
			rbtn_Dot.Checked = False
			rbtn_Dot.Checked = True
		End If
		
		If Convert.ToInt32(date_format) = 0 Then ' mmddyy
			cbbx_date1.SelectedIndex = 4
		Else ' ddmmyy
			cbbx_date1.SelectedIndex = 9
		End If
		
		txtfLines.Text = (Convert.ToInt32(TotalLineCounter) - 2).ToString
		btnGen.Enabled = True
		
		LoadSuccess = True
		
		Return False
	End Function
	
	Function ByteToBinary (Number As Byte, channels As Integer) As String
		Dim Result As String = ""
		For i = 0 To (channels - 1)
			If ((Number >> (7 - i)) And 1) = 1 Then
				Result = Result & "1"
			Else
				Result = Result & "0"
			End If
		Next
		
		Return Result
	End Function
	
	Sub loadFailed()
		txtfVersion.Text = ""
		txtfUcID.Text = ""
		txtfMemID.Text = ""
		txtfLines.Text = ""
		
		updateProgressBar(0)
		
		btnGen.Enabled = False
		
		msgbox("File format not recognized.",, "Error!")
	End Sub
	
	Function componentsCheck(lines_in() As String) As Boolean
		Dim LineCounter As Integer = 0
		Dim ComponentsCounter As Integer = 0
		
		For Each line As String In lines_in
			If(line <> "") Then
				ComponentsCounter = 0
				
				For i = 0 To line.Length -1
					If line(i) = Chr(59) Then ' Horizontal Tab code: 9
						ComponentsCounter = ComponentsCounter + 1
					End If
				Next
				
				If LineCounter = 1 Then
					If debug_load_file = True Then
						Log("[componentsCheck] Line : " & LineCounter & " Components: " & ComponentsCounter)
						Log(line)
					End If
					FirstComponentsCounter = ComponentsCounter
				Else If LineCounter > 1 Then
					If debug_load_file = True Then
						Log("[componentsCheck] Line : " & LineCounter & " Components: " & ComponentsCounter)
					End If
					
					If FirstComponentsCounter <> ComponentsCounter Then
						msgbox("File header format not recognized.",, "Error!")
						Log("[componentsCheck] Error: FirstComponentsCounter <> ComponentsCounter")
						Log(FirstComponentsCounter & "<>" & ComponentsCounter)
						'LoadFail = True
						'Exit
						Return True
					End If
				End If
			Else
				'Log("Null line")
			End If
			
			LineCounter = LineCounter + 1
			
			updateProgressBar(LineCounter / TotalLineCounter)
			
			Application.DoEvents
		Next
		
		Return False
	End Function
	
	Sub decodeLines16()
		Dim lines2 As New List(Of String)()
		Dim LineCounter As Integer = 0
		
		lines2.Clear
		
		lines2.Add(lines.Item(0))
		
		For Each line As String In lines
			If line <> "" Then
				If LineCounter > 0 Then
					Dim data As Byte() = System.Convert.FromBase64String(line)
					
					line = System.Text.ASCIIEncoding.ASCII.GetString(data)
					
					If line.LastIndexOf(Chr(59)) = (line.Length - 1) Then
						line = line.Remove(line.Length - 1, 1)	
					End If
					
					lines2.Add(line) 'B64.DecodeStoS(line, "UTF8"))
				End If
			Else
				Log("[decodeLines] line null")
			End If
			
			LineCounter = LineCounter + 1
			
			Application.DoEvents
		Next
		
		lines.Clear
		
		lines.AddRange(lines2.ToArray)
		
		lines2.Clear
	End Sub
	
	Sub decodeLines64()
		Dim lines2 As New List(Of String)()
		Dim LineCounter As Integer = 0
		'Dim components() As String
		
		lines2.Clear
		
		lines2.Add(lines.Item(0))
		
		For Each line As String In lines
			If line <> "" Then
				'Log("line " & LineCounter)
				
				If LineCounter = 1 Then
					Dim data As Byte() = System.Convert.FromBase64String(line)
					
					line = System.Text.ASCIIEncoding.ASCII.GetString(data)
					
					'Log(line)
					
					lines2.Add(line) 'B64.DecodeStoS(line, "UTF8"))
				Else If LineCounter > 1 Then	
					'Log(line)
					lines2.Add(line) 'B64.DecodeStoS(line, "UTF8"))
				End If
			Else
				Log("[decodeLines] line null")
			End If
			
			LineCounter = LineCounter + 1
			
			Application.DoEvents
		Next
		
		lines.Clear
		
		lines.AddRange(lines2.ToArray)
		
		lines2.Clear
	End Sub
	
	Sub checkDecodedComponents()
		Dim ComponentsCounter_base64 As Integer = 0
		Dim FirstComponentsCounter_base64 As Integer = 0
		Dim LineCounter As Integer = 0
		
		If(lines.Item(1) <> "") Then
			Dim str As String = lines.Item(1)
			
			ComponentsCounter_base64 = 0
			
			For i = 0 To str.Length -1
				If str(i) = Chr(59) Then ' Horizontal Tab code: 9
					ComponentsCounter_base64 = ComponentsCounter_base64 + 1
				End If
			Next
		Else
			Log("[checkDecodedComponents] lines.Item null")
		End If
		
		FirstComponentsCounter_base64 = ComponentsCounter_base64
		
		loadFail = False
		
		For Each line As String In lines
			If(line <> "") Then
				If(LineCounter > 0) Then
					ComponentsCounter_base64 = 0
					
					For i = 0 To line.Length -1
						If line(i) = Chr(59) Then ' Horizontal Tab code: 9
							ComponentsCounter_base64 = ComponentsCounter_base64 + 1
						End If
					Next
					
					If ComponentsCounter_base64 <> FirstComponentsCounter_base64 Then
						'Log("FirstComponentsCounter_base64: " & FirstComponentsCounter_base64)
						'Log("ComponentsCounter_base64: " & ComponentsCounter_base64)
						Log("[checkDecodedComponents] ComponentsCounter_base64 <> FirstComponentsCounter_base64")
						Log(line)
						loadFail = True
						Exit For 'Exit
					End If
				End If
			Else
				Log("[checkDecodedComponents] line null")
			End If
			
			LineCounter = LineCounter + 1
			
			'		Dim prog_buff As Double
			'		
			'		prog_buff = LineCounter / TotalLineCounter
			'		prog_buff = prog_buff * 0.8
			'		prog_buff = prog_buff + 0.2
			'		
			'		updateProgressBar(prog_buff)
			
			'Sleep(0)
			Application.DoEvents
		Next
	End Sub
	
	Sub BinaryToChannels (channels As String)
		Dim numberOfChannels As Integer = 0
		Dim index1 As Integer = 0
		
		For i = 0 To (channels.Length - 1)
			If channels(i) = "1" Then
				numberOfChannels = numberOfChannels + 1
			End If
		Next
		
		For i = 0 To (channels.Length - 1)
			If channels(i) = "1" Then
				If i = 0 Then
					cbxCh1.Enabled = True
					cbxCh1.Checked = True
				Else If i = 1 Then
					cbxCh2.Enabled = True
					cbxCh2.Checked = True
				Else If i = 2 Then
					cbxCh3.Enabled = True
					cbxCh3.Checked = True
				Else If i = 3 Then
					cbxCh4.Enabled = True
					cbxCh4.Checked = True
				Else If i = 4 Then
					cbxCh5.Enabled = True
					cbxCh5.Checked = True
				Else If i = 5 Then
					cbxCh6.Enabled = True
					cbxCh6.Checked = True
				Else If i = 6 Then
					cbxCh7.Enabled = True
					cbxCh7.Checked = True
				Else If i = 7 Then
					cbxCh8.Enabled = True
					cbxCh8.Checked = True
				End If
				
			Else
				If i = 0 Then
					cbxCh1.Enabled = False
					cbxCh1.Checked = False
				Else If i = 1 Then
					cbxCh2.Enabled = False
					cbxCh2.Checked = False
				Else If i = 2 Then
					cbxCh3.Enabled = False
					cbxCh3.Checked = False
				Else If i = 3 Then
					cbxCh4.Enabled = False
					cbxCh4.Checked = False
				Else If i = 4 Then
					cbxCh5.Enabled = False
					cbxCh5.Checked = False
				Else If i = 5 Then
					cbxCh6.Enabled = False
					cbxCh6.Checked = False
				Else If i = 6 Then
					cbxCh7.Enabled = False
					cbxCh7.Checked = False
				Else If i = 7 Then
					cbxCh8.Enabled = False
					cbxCh8.Checked = False
				End If
				
			End If
			
			index1 = index1 + 1
		Next
	End Sub
	
	Sub Log(str As String)
		Debug.write(str & vbCrLf)
	End Sub
	
	Function date_formater (dd As Integer, mm As Integer, yy As Integer) As String
		Dim date_buff As String = ""
		
		If cbbx_date1.SelectedIndex = 0 Then
			'	cbbx_date1.Items.Add("yyyy-mm-dd")
			date_buff = "20" & yy & "-" & mm & "-" & dd
		Else if cbbx_date1.SelectedIndex = 1 Then
			'	cbbx_date1.Items.Add("yyyy-dd-mm")
			date_buff = "20" & yy & "-" & dd & "-" & mm
		Else if cbbx_date1.SelectedIndex = 1 Then
			'	cbbx_date1.Items.Add("dd-yyyy-mm")
			date_buff = dd & "-" & "20" & yy & "-" & mm
		Else if cbbx_date1.SelectedIndex = 2 Then
			'	cbbx_date1.Items.Add("dd-mm-yyyy")
			date_buff = dd & "-" & mm & "-" & "20" & yy
		Else if cbbx_date1.SelectedIndex = 3 Then
			'	cbbx_date1.Items.Add("mm-dd-yyyy")
			date_buff = mm & "-" & dd & "-" & "20" & yy
		Else if cbbx_date1.SelectedIndex = 4 Then
			'	cbbx_date1.Items.Add("mm-yyyy-dd")
			date_buff = mm & "-" & "20" & yy & "-" & dd
		Else if cbbx_date1.SelectedIndex = 5 Then
			'	cbbx_date1.Items.Add("yyyy/mm/dd")
			date_buff = "20" & yy & "/" & mm & "/" & dd
		Else if cbbx_date1.SelectedIndex = 6 Then
			'	cbbx_date1.Items.Add("yyyy/dd/mm")
			date_buff = "20" & yy & "/" & dd & "/" & mm
		Else if cbbx_date1.SelectedIndex = 7 Then
			'	cbbx_date1.Items.Add("dd/yyyy/mm")
			date_buff = dd & "/" & "20" & yy & "/" & mm
		Else if cbbx_date1.SelectedIndex = 8 Then
			'	cbbx_date1.Items.Add("dd/mm/yyyy")
			date_buff = dd & "/" & mm & "/" & "20" & yy
		Else if cbbx_date1.SelectedIndex = 9 Then
			'	cbbx_date1.Items.Add("mm/dd/yyyy")
			date_buff = mm & "/" & dd & "/" & "20" & yy
		Else 'if cbbx_date1.SelectedIndex = 10 Then
			'	cbbx_date1.Items.Add("mm/yyyy/dd")
			date_buff = mm & "/" & "20" & yy & "/" & dd
		End If
		
		Return date_buff
	End Function
	
	Private Sub CSV_Export
		Dim fn As String
		Dim filename As String = Path.GetFileNameWithoutExtension(SourceFileName)
		
		Dim saveFileDialog1 As New SaveFileDialog()
		
		saveFileDialog1.FileName = filename & ".csv"
		saveFileDialog1.Filter = "csv files (*.CSV)|*.csv"
		saveFileDialog1.FilterIndex = 2
		saveFileDialog1.RestoreDirectory = True
		
		If saveFileDialog1.ShowDialog() = DialogResult.OK Then
			fn = saveFileDialog1.FileName
			
			If fn <> "" Then
				export_enable = True
				
				SourceFileFolderSave = GetParent(fn)
				SourceFileNameSave = GetFileName(fn)
				
				If Val(file_type) = 0 Then
					CSV_File_Export16
				Else If Val(file_type) = 2 Then
					CSV_File_Export64
				End If
				
			Else
				Log("fileName null")
			End If
		Else
			msgbox("Operation aborted successfully.",, "File save")
			
			enable_buttons
			Return
		End If
	End Sub
	
	Sub CSV_File_Export16()
		Dim filetext_line As String = ""
		Dim components() As String
		Dim LineCounter As Integer = 0
		Dim buffer As String = ""
		Dim component_index As Integer = 0
		Dim TAB_char As Integer = Asc(";") 'TAB = 9, Asc(";") = 59
		Dim dd As String
		Dim mm As String
		Dim yy As String
		
		write_list.Clear
		
		If debug_export_csv = True Then
			Log("[CSV_File_Export]")
		End If
		
		If export_enable Then
			updateProgressBar(0)
			
			export_enable = False
			
			For Each line As String In lines
				If(line <> "") Then
					components = line.Split(Chr(59)) 'Regex.Split("\t",line)
					
					'Log("line: " & LineCounter & " components: " & components.Length)
					'Log(line)
					If(components.Length > 0) Then
						If(LineCounter > 1) Then
							' Index
							If components(0).Length > 0 Then
								components(0) = (HexToInt(components(0)) + 1).ToString
							Else
								Log("Index: components(0).Length <= 0")
							End If
							
							For i = 1 To components.Length - 6 ' without event data
								If ((i - 1) Mod 8) = 0 Then ' CHx: Date (0B1415) ddmmyy
									If components(i).Length = 6 Then
										dd = (HexToInt(components(i).SubString(4, 2))).ToString
										
										If dd.Length = 1 Then
											dd = "0" & dd
										End If
										
										mm = (HexToInt(components(i).SubString(2, 2))).ToString
										
										If mm.Length = 1 Then
											mm = "0" & mm
										End If
										
										yy = (HexToInt(components(i).SubString(0, 2))).ToString
										
										components(i) = (date_formater(Convert.ToInt32(dd), _
											Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
									End If
								Else If i > 1 And ((i - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3) (1017) hhmm
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).SubString(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).SubString(2, 2))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute '& ":" & "00"
										
										components(i) = buffer
									End If
								Else If i > 2 And ((i - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
									Dim values_str() As String
									Dim values_byte(2) As Integer
									Dim value_float As Double ' Float
									
									values_str = components(i).Split(Chr(Asc("."))) 'Regex.Split("\.", components(i))
									
									If values_str.Length = 2 Then
										values_byte(0) = HexToInt(values_str(1).Trim)
										values_byte(1) = HexToInt(values_str(0).Trim)
										
										value_float = values_byte(0) * 0.0625
										value_float = value_float + values_byte(1)
										components(i) = (value_float).ToString
									End If
								Else If i > 4 And ((i - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
									If components(i).Length = 2 Then
										components(i) = (HexToInt(components(i).Trim)).ToString
										components(i) = (Val(components(i)) - 127).ToString
									End If
								Else If i > 5 And ((i - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
									If components(i).Length = 2 Then
										components(i) = (HexToInt(components(i).Trim)).ToString
										components(i) = (Val(components(i)) - 127).ToString
									End If
								Else If i > 6 And ((i - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
									If components(i).Length = 2 Then
										Dim batt_f As Double : batt_f = HexToInt(components(i).Trim)
										batt_f = batt_f * 0.004
										batt_f = batt_f + 3.5
										components(i) = (batt_f).ToString
										If components(i).Length > 6 Then
											Log("components(i): " & components(i))
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
									End If
								Else If i > 7 And ((i - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
									If components(i).Length = 2 Then
										Dim charg_f As Double : charg_f = HexToInt(components(i).Trim)
										charg_f = charg_f * 0.1
										charg_f = charg_f + 7.0
										components(i) = (charg_f).ToString
										If components(i).Length > 6 Then
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
									End If
								End If
							Next
							
							For i = components.Length - 3 To components.Length - 1 ' event data
								If i = (components.Length - 3) Then ' Event Date
									dd = (HexToInt(components(i).SubString(4, 2))).ToString
									mm = (HexToInt(components(i).SubString(2, 2))).ToString
									yy = (HexToInt(components(i).SubString(0, 2))).ToString
									components(i) = (date_formater(Convert.ToInt32(dd), _
										Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
								Else If i = (components.Length - 2) Then ' Event Time
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).SubString(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).SubString(2, 2))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute '& ":00"
										
										components(i) = buffer
									End If
								Else If i = (components.Length - 1) Then ' Event Desc.
									components(i) = (HexToInt(components(i).Trim)).ToString
								End If
							Next
						End If
						
						component_index = 0
						
						filetext_line = ""
						
						For Each data_string In components
							If LineCounter > 1 Then
								If component_index = 0 Then ' Index
									If data_string <> "" Then
										filetext_line = data_string & Chr(TAB_char)
									End If
								Else
									If component_index > 0 And _
										component_index < (components.Length - 4) And _
										((component_index - 1) Mod 8) = 0 Then ' CHx: Date
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 1 And _
										component_index < (components.Length - 4) And _
										((component_index - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3)
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 2 And _
										component_index < (components.Length - 4) And _
										((component_index - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 3 And _
										component_index < (components.Length - 4) And _
										((component_index - 4) Mod 8) = 0 Then ' CHx: Sensor ID (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 4 And _
										component_index < (components.Length - 4) And _
										((component_index - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 5 And _
										component_index < (components.Length - 4) And _
										((component_index - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 6 And _
										component_index < (components.Length - 4) And _
										((component_index - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 7 And _
										component_index < (components.Length - 4) And _
										((component_index - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									End If
								End If
								
								If component_index = (components.Length - 3) Then ' Event Date
									If data_string <> "" Then
										filetext_line =  filetext_line & Chr(TAB_char) & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 2) Then ' Event Time
									If data_string <> "" Then
										filetext_line = filetext_line & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 1) Then ' Event Desc.
									If data_string <> "" Then
										filetext_line = filetext_line & data_string '& Chr(TAB_char)
									End If
								End If
							Else
								Dim data_string_chk As String = data_string
								
								If data_string_chk.Contains(";") Then
									data_string_chk = data_string_chk.Replace(";", "|")
									msgbox("The character ';' has been replaced by '|'",, "Replace delimiter in channel title")
								End If
								
								If component_index <> (components.Length - 1) Then 
									filetext_line = filetext_line & data_string_chk & Chr(TAB_char)
								Else 
									filetext_line = filetext_line & data_string_chk
								End If
							End If
							
							component_index = component_index + 1
							
							If lowRAMmemory Then
								'Exit
							End If
						Next
					End If
				End If
				
				If debug_export_csv = True Then
					Log("filetext_line " & LineCounter & ": " & filetext_line)
				End If
				
				write_list.Add(filetext_line)
				
				LineCounter = LineCounter + 1
				
				updateProgressBar(LineCounter / TotalLineCounter)
				
				Application.DoEvents
				
				If lowRAMmemory Then
					'Exit
				End If
			Next
			
			Try
				updateProgressBar(0)
				
				file_writer
				
				MsgBox("Export finished.", , "File exported")
			Catch ex As SecurityException
				msgbox("User does not have permission to write files" & vbCrLf & vbCrLf & "SecurityException:" & ex.Message,,"OpenFile")
			Catch ex As Exception
				msgbox("File cannot be read (permission error)" & vbCrLf & vbCrLf & "Exception:" & ex.Message,,"OpenFile")
			End Try
			
		End If
		
		enable_buttons
	End Sub
	
	Sub CSV_File_Export64()
		Dim filetext_line As String = ""
		Dim components() As String
		Dim LineCounter As Integer = 0
		Dim buffer As String = ""
		Dim component_index As Integer = 0
		Dim TAB_char As Integer = Asc(";") 'TAB = 9, Asc(";") = 59
		Dim dd As String
		Dim mm As String
		Dim yy As String
		Dim ch_counter As Integer = 0
		Dim sensor_ID(8) As String
		
		write_list.Clear
		
		If debug_export_csv = True Then
			Log("[CSV_File_Export]")
		End If
		
		If export_enable Then
			updateProgressBar(0)
			
			export_enable = False
			
			For Each line As String In lines
				If(line <> "") Then
					components = line.Split(Chr(59)) 'Regex.Split("\t",line)
					
					'Log("line: " & LineCounter & " components: " & components.Length)
					'Log(line)
					If(components.Length > 0) Then
						If(LineCounter > 1) Then
							' Index
							If components(0).Length > 0 Then
								components(0) = (HexToInt(components(0)) + 1).ToString
							Else
								Log("Index: components(0).Length <= 0")
							End If
							
							For i = 1 To components.Length - 6 ' without event data
								If ((i - 1) Mod 8) = 0 Then ' CHx: Date (AWGK) yymd
									'ch_counter = ch_counter + 1
									
									'Log("components(i).Length: " & components(i).Length)
									If components(i).Length = 4 Then
										'Log("components(i): " & components(i))
										dd = (base64to10(components(i).SubString(3, 1))).ToString
										
										If dd.Length = 1 Then
											dd = "0" & dd
										End If
										
										mm = (base64to10(components(i).SubString(2, 1))).ToString
										
										If mm.Length = 1 Then
											mm = "0" & mm
										End If
										
										If Asc(components(i).SubString(0, 1)) = Asc("A") Then
											yy = (base64to10(components(i).SubString(1, 1))).ToString
										Else
											yy = (base64to10(components(i).SubString(0, 2))).ToString
										End If
										
										components(i) = (date_formater(Convert.ToInt32(dd), _
											Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
									End If
								Else If i > 1 And ((i - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3) (1017) hhmm
									If components(i).Length = 2 Then
										Dim hour As String = (base64to10(components(i).SubString(1, 1))).ToString
										Dim minute As String = (base64to10(components(i).SubString(0, 1))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & ":" & minute '& ":" & "00"
										
										components(i) = buffer
									End If
								Else If i > 2 And ((i - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
									Dim values_str() As String
									Dim values_byte(2) As Integer
									Dim value_float As Double ' Float
									
									values_str = components(i).Split(Chr(Asc("."))) 'Regex.Split("\.", components(i))
									
									If values_str.Length = 2 Then
										values_byte(0) = base64to10(values_str(1).Trim)
										values_byte(1) = base64to10(values_str(0).Trim)
										
										value_float = values_byte(0) * 0.0625
										value_float = value_float + values_byte(1)
										components(i) = (value_float).ToString
									End If
								Else If i > 3 And ((i - 4) Mod 8) = 0 Then ' CHx: Sensor ID (864866715576104)
									components(i) = (base64to10(components(i).Trim)).ToString
									Dim ID_bytes(8) As Integer
									'Dim result As Int64
									Dim divider As Int64
									Dim tmp_num As Int64 = Val(components(i))
									
									'If components(i).IsNumber = True Then
									For j = 1 To 7
										divider = (2 ^ (48 - ((j - 1) * 8)))
										'Log((2 ^ (48 - ((j - 1) * 8))).ToString)
										ID_bytes(j) = tmp_num \ divider
										
										
										'Log("tmp_num: " & tmp_num & " / divider: " & divider)
										'Log("Dec: " & ID_bytes(j))
										
										tmp_num = tmp_num - (ID_bytes(j) * divider)
										'Log("tmp_num: " & tmp_num)
									Next
									'End If
									
									components(i) = ""
									
									For j = 1 To 7
										'Log("Dec: " & ID_bytes(j))
										'Log("Hex: " & Hex(ID_bytes(j)))
										
										If Hex(ID_bytes(j)).Length = 2 Then
											components(i) = components(i) & Hex(ID_bytes(j))
										Else
											components(i) = components(i) & "0" & Hex(ID_bytes(j))
										End If
									Next
									
									'Log(" ")
									
									If ID_bytes(2) > 0 And ID_bytes(3) > 0 Then
										sensor_ID(ch_counter) = components(i)
									Else
										components(i) = sensor_ID(ch_counter)
									End If
								Else If i > 4 And ((i - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
									'Log(components(i).Length)
									'If components(i).Length = 1 Then
									components(i) = (base64to10(components(i).Trim)).ToString
									components(i) = (Val(components(i)) - 127).ToString
									'End If
								Else If i > 5 And ((i - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
									'If components(i).Length = 2 Then
									components(i) = (base64to10(components(i).Trim)).ToString
									components(i) = (Val(components(i)) - 127).ToString
									'End If
								Else If i > 6 And ((i - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
									'If components(i).Length = 1 Then
									Dim batt_f As Double : batt_f = base64to10(components(i).Trim)
									batt_f = batt_f * 0.004
									batt_f = batt_f + 3.5
									components(i) = (batt_f).ToString
									If components(i).Length > 6 Then
										Log("components(i): " & components(i))
										components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
									End If
									'End If
								Else If i > 7 And ((i - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
									If components(i).Length = 1 Then
										Dim charg_f As Double : charg_f = base64to10(components(i).Trim)
										charg_f = charg_f * 0.1
										charg_f = charg_f + 7.0
										components(i) = (charg_f).ToString
										If components(i).Length > 6 Then
											components(i) = components(i).SubString(0, components(i).IndexOf(".") + 4)
										End If
									End If
									
									ch_counter = ch_counter + 1
								End If
							Next
							
							For i = components.Length - 4 To components.Length - 2 ' event data
								If i = (components.Length - 4) Then ' Event Date
									'Log("i: " & i)
									'Log("components(i): " & components(i))
									'If components(i).Length = 4 Then
									dd = (base64to10(components(i).SubString(3, 1))).ToString
									mm = (base64to10(components(i).SubString(2, 1))).ToString
									
									If Asc(components(i).SubString(0, 1)) = Asc("A") Then
										yy = (base64to10(components(i).SubString(1, 1))).ToString
									Else
										yy = (base64to10(components(i).SubString(0, 2))).ToString
									End If
									
									components(i) = (date_formater(Convert.ToInt32(dd), _
										Convert.ToInt32(mm), Convert.ToInt32(yy))).ToString
									'End If
								Else If i = (components.Length - 3) Then ' Event Time
									'If components(i).Length = 4 Then
									Dim hour As String = (base64to10(components(i).SubString(0, 1))).ToString
									Dim minute As String = (base64to10(components(i).SubString(1, 1))).ToString
									
									If hour.Length = 1 Then
										hour = "0" & hour
									End If
									
									If minute.Length = 1 Then
										minute = "0" & minute
									End If
									
									buffer = hour & ":" & minute '& ":00"
									
									components(i) = buffer
									'End If
								Else If i = (components.Length - 2) Then ' Event Desc.
									components(i) = (HexToInt(components(i).Trim)).ToString
									
									ch_counter = 0
								End If
							Next
						End If
						
						component_index = 0
						
						filetext_line = ""
						
						For Each data_string In components
							If LineCounter > 1 Then
								If component_index = 0 Then ' Index
									If data_string <> "" Then
										filetext_line = data_string & Chr(TAB_char)
									End If
								Else
									If component_index > 0 And _
										component_index < (components.Length - 4) And _
										((component_index - 1) Mod 8) = 0 Then ' CHx: Date
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 1 And _
										component_index < (components.Length - 4) And _
										((component_index - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3)
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 2 And _
										component_index < (components.Length - 4) And _
										((component_index - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 3 And _
										component_index < (components.Length - 4) And _
										((component_index - 4) Mod 8) = 0 Then ' CHx: Sensor ID (label)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 4 And _
										component_index < (components.Length - 4) And _
										((component_index - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 5 And _
										component_index < (components.Length - 4) And _
										((component_index - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
										
										If data_string <> "" Then
											filetext_line = filetext_line & data_string & Chr(TAB_char)
										End If
									Else If component_index > 6 And _
										component_index < (components.Length - 4) And _
										((component_index - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									Else If component_index > 7 And _
										component_index < (components.Length - 4) And _
										((component_index - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
										
										If data_string <> "" Then
											filetext_line = filetext_line & Chr(34) & data_string & Chr(34) & Chr(TAB_char)
										End If
									End If
								End If
								
								If component_index = (components.Length - 4) Then ' Event Date
									If data_string <> "" Then
										filetext_line =  filetext_line & Chr(TAB_char) & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 3) Then ' Event Time
									If data_string <> "" Then
										filetext_line = filetext_line & data_string & Chr(TAB_char)
									End If
								Else If component_index = (components.Length - 2) Then ' Event Desc.
									If data_string <> "" Then
										filetext_line = filetext_line & data_string '& Chr(TAB_char)
									End If
								End If
							Else
								Dim data_string_chk As String = data_string
								
								If data_string_chk.Contains(";") Then
									data_string_chk = data_string_chk.Replace(";", "|")
									msgbox("The character ';' has been replaced by '|'",, "Replace delimiter in channel title")
								End If
								
								If component_index <> (components.Length - 1) Then 
									filetext_line = filetext_line & data_string_chk & Chr(TAB_char)
								Else 
									filetext_line = filetext_line & data_string_chk
								End If
							End If
							
							component_index = component_index + 1
							
							If lowRAMmemory Then
								'Exit
							End If
						Next
					End If
				End If
				
				If debug_export_csv = True Then
					Log("filetext_line " & LineCounter & ": " & filetext_line)
				End If
				
				write_list.Add(filetext_line)
				
				LineCounter = LineCounter + 1
				
				updateProgressBar(LineCounter / TotalLineCounter)
				
				Application.DoEvents
				
				If lowRAMmemory Then
					'Exit
				End If
			Next
			
			Try
				updateProgressBar(0)
				
				file_writer
				
				MsgBox("Export finished.", , "File exported")
			Catch ex As SecurityException
				msgbox("User does not have permission to write files" & vbCrLf & vbCrLf & "SecurityException:" & ex.Message,,"OpenFile")
			Catch ex As Exception
				msgbox("File cannot be read (permission error)" & vbCrLf & vbCrLf & "Exception:" & ex.Message,,"OpenFile")
			End Try
			
		End If
		
		enable_buttons
	End Sub
	
	Function base10to64(input As Integer) As String
		Dim num10 As Integer = input
		Dim output(20) As char
		Dim output_str As String = ""
		dim R As Integer
		dim Q As Integer
		dim J As Integer = 0
		dim k As Integer = 0
		dim is_negative As Integer = 0
		dim map() as Char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".ToCharArray
		Dim tmp(20) As Char
		
		if (num10 < 0) then
			is_negative = 1
			num10 = num10 * (-1)
		End If
		
		if (num10 <> 0) then
			Q = num10			
			
			while (Q > 0)
				Q = 0
				
				while (num10 >= 64)
					num10 = num10 - 64
					Q = Q + 1
				end while
				
				R = num10
				
				tmp(J) = map(R)
				
				num10 = Q
				
				J = J + 1
			end while
			
			tmp(J) = Chr(0)
			
			if (is_negative = 1) then
				output(0) = Chr(45) '// chr(45): "-"
			End If
			
			k = 0
			
			while (Asc(tmp(k)) <> 0)
				k = k + 1
			end while
			
			for i = 0 to k - 1
				if (is_negative <> 1) then
					output(i) = tmp((k - 1) - i)
				else
					output(i + 1) = tmp((k - 1) - i)
				End If
			next
			
			if (is_negative <> 1) then
				output(J) = Chr(0)
			else
				output(J + 1) = Chr(0)
			End If
		else
			output(0) = map(0)
			output(1) = Chr(0)
		End If
		
		For i = 0 To output.Length
			If Asc(output(i)) = 0 Then
				Exit For
			Else If Asc(output(i)) <> 0 Then
				output_str = output_str & output(i)
			End If
		Next
		
		'output_str = output.ToString
		
		Return output_str
	End Function
	
	Function base64to10(input As String) As Int64
		'Dim num10 As Integer ' = input
		Dim input_inv As String = ""
		Dim output(20) As char
		Dim output_int As Int64 = 0
		'dim R As Integer
		'dim Q As Integer
		dim J As Integer = 0
		dim k As Integer = 0
		dim is_negative As Boolean = false
		dim map() as Char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".ToCharArray
		Dim tmp(20) As Char
		
		If input.Length = 0 Then
			Return 0
		End If
		
		If input(0) = Chr(45) Then ' chr(45): "-"
			is_negative = true
			
			If input.Length > 1 Then
				input = input.Substring(1)
			Else
				Return 0
			End If
		End If
		
		For i = 0 To input.Length -1
			input_inv = input(i) & input_inv
		Next
		
		For i = 0 To input_inv.Length -1
			output_int = output_int + (indexOfMap(map, input_inv(i)) * (64 ^ i))
		Next
		
		If is_negative = True Then
			output_int = output_int * -1
		End If
		
		Return output_int
	End Function
	
	Function indexOfMap(map() As Char, input As String) As Integer
		For i = 0 To map.Length - 1
			If Asc(input) = Asc(map(i)) Then
				Return i
				'Exit for
			End If
		Next
		
		Return 0
	End Function
	
	Sub file_writer()
		Using StreamWriter1 As New System.IO.StreamWriter(SourceFileFolderSave & "\" & SourceFileNameSave)
			Dim i As Integer = 0
			
			For Each item As String In write_list
				'StreamWriter1.WriteLine(item)
				StreamWriter1.Write(item & vbLf)
				
				updateProgressBar(i / write_list.Count)
				
				i = i + 1
				
				Application.DoEvents
			Next
			StreamWriter1.Flush()
			StreamWriter1.Close()
		End Using
	End Sub
	
	Sub enable_buttons
		btnLoad.Enabled = True
		btnGen.Enabled = True
		
		rbtn_DegF.Enabled = True
		rbtn_DegC.Enabled = True
		
		rbtn_Comma.Enabled = True
		rbtn_Dot.Enabled = True
		
		rbtn_FileCSV.Enabled = True
		rbtn_FileXLS.Enabled = True
		
		cbbx_date1.Enabled = True
		
		cbxSaveDefault.Enabled = True
		
		cbxCh1.Enabled = True
		cbxCh2.Enabled = True
		cbxCh3.Enabled = True
		cbxCh4.Enabled = True
		cbxCh5.Enabled = True
		cbxCh6.Enabled = True
		cbxCh7.Enabled = True
		cbxCh8.Enabled = True
	End Sub
	
	Sub updateProgressBar(value_unit As Double)
		value_unit = value_unit * 100
		Dim value As Integer = Convert.ToInt32(value_unit)
		Dim buff As Integer
		
		If value > (progressBar1.Value + 0.01) Then
			If value > progressBar1.Maximum Then
				value = progressBar1.Maximum
			Else If value < progressBar1.Minimum Then
				value = progressBar1.Minimum
			End If
			
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		Else If value < (progressBar1.Value - 0.01) Then
			If value > progressBar1.Maximum Then
				value = progressBar1.Maximum
			Else If value < progressBar1.Minimum Then
				value = progressBar1.Minimum
			End If
			
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		Else If value = 0 Then
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		Else If value > 0.99 Then
			If value > progressBar1.Maximum Then
				value = progressBar1.Maximum
			End If
			
			progressBar1.Value = value
			
			buff = value * 100
			
			'lblProgressVal.Text = buff
		End If
	End Sub
	
	Sub ENToolStripMenuItemClick(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub ESToolStripMenuItemClick(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub PTToolStripMenuItemClick(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub Rbtn_FileXLSCheckedChanged(sender As Object, e As EventArgs)
		
	End Sub
	
	Private Sub XLS_Export()
		Dim fn As String = ""
		
		Dim filename As String = Path.GetFileNameWithoutExtension(SourceFileName)
		
		Dim saveFileDialog1 As New SaveFileDialog()
		
		saveFileDialog1.FileName = filename & ".xlsx"
		saveFileDialog1.Filter = "Spreadsheet files (*.xlsx)|*.XLSX"
		saveFileDialog1.FilterIndex = 2
		saveFileDialog1.RestoreDirectory = True
		
		If saveFileDialog1.ShowDialog() = DialogResult.OK Then
			fn = saveFileDialog1.FileName
			
			'Log("fn: " & fn)
			
			If fn <> "" Then
				export_enable = True
				
				SourceFileFolderSave = GetParent(fn)
				SourceFileNameSave = GetFileName(fn)
				
				
				If Val(file_type) = 0 Then
					XLS_File_Export16
				Else If Val(file_type) = 2 Then
					XLS_File_Export64
				End If
				
				'create_xlsx ' test
				
				enable_buttons()
			Else
				Return
			End If
		Else
			MsgBox("Operation aborted successfully.", , "File save")
			
			enable_buttons()
			Return
		End If
	End Sub
	
	Sub XLS_File_Export16()
		If export_enable Then
			Dim Workbook1 As XLWorkbook = New XLWorkbook() 'XLWorkbookWriter = XL.CreateWriterBlank
			Dim sheet1 = Workbook1.Worksheets.Add("Sheet1") 'XLSheetWriter = Workbook.CreateSheetWriterByName("Sheet1")
			
			'Dim XL As XLUtils
			Dim components() As String '= new Array As String("")
			'Dim XLAddress1 As XLAddress
			Dim component_index As Integer = 0
			Dim LineCounter As Integer = 0
			
			
			'Dim TitleStyle As Workbook 'As XLStyle = Workbook.CreateStyle
			
			Dim buffer As String = ""
			Dim buff2 As String = ""
			
			'TitleStyle.ForegroundColor(XL.COLOR_GREY_80_PERCENT).FontBoldColor(12, XL.COLOR_WHITE).HorizontalAlignment("CENTER")
			
			'Dim n As Long = Convert.ToInt32(DateTime.Now.ToString())
			
			updateProgressBar(0)
			
			export_enable = False
			
			Dim col_max As Integer = 0
			
			'XL.Initialize()
			'XLAddress1.Initialize()
			
			'Log("[XLS_File_Export] lines.Size: " & lines.Count)
			
			For Each line As String In lines
				If (line <> "") Then
					components = line.Split(Chr(59)) 'Regex.Split("\t", line)
					
					'Log("[XLS_File_Export] Line " & LineCounter & ", components: " & components.Length)
					
					If (components.Length > 0) Then
						If (LineCounter > 1) Then
							' Index
							If components(0).Length > 0 Then
								components(0) = (Convert.ToInt32(HexToInt(components(0))) + 1).ToString 
							End If
							
							For i = 1 To components.Length - 4 ' without event data					
								If ((i - 1) Mod 8) = 0 Then ' CHx: Date (0B1415) mmddyy
									If components(i).Length = 6 Then									
										buff2 = (HexToInt(components(i).Substring(4))).ToString ' day
										
										If buff2.Length = 1 Then
											buff2 = "0" & buff2
										End If
										
										buffer = buff2
										
										buff2 = (HexToInt(components(i).Substring(2, 2))).ToString ' month
										
										If buff2.Length = 1 Then
											buff2 = "0" & buff2
										End If
										
										buffer = buffer & buff2
										
										buffer = buffer & "20" & HexToInt(components(i).Substring(0, 2)) ' year
										
										
										components(i) = buffer
									End If
								ElseIf i > 1 And ((i - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3) (1017) hhmm
									If components(i).Length = 4 Then
										Dim hour As String = (HexToInt(components(i).Substring(0, 2))).ToString
										Dim minute As String = (HexToInt(components(i).Substring(2, 2))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & minute & "00"
										
										components(i) = buffer
									End If
								ElseIf i > 2 And ((i - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
									Dim values_str() As String
									Dim values_byte(2) As Byte
									Dim value_float As Double 'Float
									
									values_str = components(i).Split(Chr(46)) 'Regex.Split("\.", components(i))
									
									If values_str.Length = 2 Then
										values_byte(0) = Convert.ToByte(HexToInt(values_str(1).Trim))
										values_byte(1) = Convert.ToByte(HexToInt(values_str(0).Trim)) 
										
										value_float = values_byte(0) * 0.0625
										value_float = value_float + values_byte(1)
										
										If rbtn_DegF.Checked Then
											value_float = (value_float * 1.8) + 32
										End If
										
										components(i) = value_float.ToString 
									End If
								ElseIf i > 4 And ((i - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
									If components(i).Length = 2 Then
										components(i) = HexToInt(components(i).Trim).ToString 
										components(i) = (Convert.ToInt32(components(i)) - 127).ToString 
									End If
								ElseIf i > 5 And ((i - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
									If components(i).Length = 2 Then
										components(i) = HexToInt(components(i).Trim).ToString 
										components(i) = (Convert.ToInt32(components(i)) - 127).ToString
									End If
								ElseIf i > 6 And ((i - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
									If components(i).Length = 2 Then
										Dim batt_f As Double : batt_f = HexToInt(components(i).Trim)
										batt_f = batt_f * 0.004
										batt_f = batt_f + 3.5
										components(i) = batt_f.ToString 
										
										If components(i).Length > 6 Then
											components(i) = components(i).Substring(0, components(i).IndexOf(".") + 4)
										End If
									End If
								ElseIf i > 7 And ((i - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
									If components(i).Length = 2 Then
										Dim charg_f As Double : charg_f = HexToInt(components(i).Trim)
										charg_f = charg_f * 0.1
										charg_f = charg_f + 7.0
										components(i) = charg_f.ToString 
										
										If components(i).Length > 6 Then
											components(i) = components(i).Substring(0, components(i).IndexOf(".") + 4)
										End If
									End If
								End If
								'							End If
							Next
							
							For i = components.Length - 3 To components.Length - 1 ' event data
								'Log("[event data]")
								If i = (components.Length - 3) Then ' Event Date
									'Log("Event Date")
									buffer = HexToInt(components(i).Substring(4)).ToString 
									buffer = buffer & HexToInt(components(i).Substring(2, 2))
									buffer = buffer & "20" & HexToInt(components(i).Substring(0, 2))
									components(i) = buffer
								ElseIf i = (components.Length - 2) Then ' Event Time
									Log("Event Time")
									If components(i).Length = 4 Then
										Dim hour As String = HexToInt(components(i).Substring(0, 2)).ToString 
										Dim minute As String = HexToInt(components(i).Substring(2, 2)).ToString 
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & minute & "00"
										
										components(i) = buffer
									Else
										Log("Event Time, components(i).Length <> 4")
									End If
								ElseIf i = (components.Length - 1) Then ' Event Desc.
									components(i) = HexToInt(components(i).Trim).ToString 
								End If
							Next
						End If
						
						component_index = 0
						
						For Each data_string In components
							Dim Col0Based As Integer = component_index + 1
							Dim Row0Based As Integer = LineCounter + 1
							
							If Row0Based >= 1048576 Then
								MsgBox("Maximum line number reached: 1048576", , "Error")
								Return
							End If
							
							If LineCounter > 1 Then
								If component_index = 0 Then ' Index
									If data_string <> "" Then
										Dim val_number As Double : val_number = Convert.ToDouble(data_string)
										'sheet1.PutNumber(XLAddress1, val_number)
										sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
									End If
								Else
									Dim i As Integer = component_index
									'								If (cbxCh1.Checked And (i >= 1 And i <= 8)) Or _
									'									(cbxCh2.Checked And (i >= 9 And i <= 16)) Or _
									'									(cbxCh3.Checked And (i >= 17 And i <= 24)) Or _
									'									(cbxCh4.Checked And (i >= 25 And i <= 32)) Or _
									'									(cbxCh5.Checked And (i >= 33 And i <= 40)) Or _
									'									(cbxCh6.Checked And (i >= 41 And i <= 48)) Or _
									'									(cbxCh7.Checked And (i >= 49 And i <= 56)) Or _
									'									(cbxCh8.Checked And (i >= 57 And i <= 64)) Then
									If component_index > 0 And _
										component_index < (components.Length - 4) And _
										((component_index - 1) Mod 8) = 0 Then ' CHx: Date
										If data_string <> "" Then
											'sheet1.PutFormula(XLAddress1, "=TEXT(" & Chr(34) & data_string & _
											' Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
											'sheet1.Cell(Row0Based, Col0Based).SetValue("=TEXT(" & Chr(34) & data_string & _
											'	Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
											sheet1.Cell(Row0Based, Col0Based).SetFormulaA1("=TEXT(" & Chr(34) & data_string & _
												Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
											'sheet1.Cell(Row0Based, Col0Based).SetValue(data_string)
											'sheet1.Cell(Row0Based, Col0Based).Style.Numberformat.Format = "dd/mm/yyy"
											sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("dd/mm/yyyy")
											
											'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("dd/mm/yyyy")
											'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
										End If
									ElseIf component_index > 1 And _
										component_index < (components.Length - 4) And _
										((component_index - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3)
										If data_string <> "" Then
											'Log("[XLS_File_Export] CHx: Time (GMT-3): " & data_string)
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
											
											sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("00:00:00")
											'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("00:00:00")
											'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
										End If
									ElseIf component_index > 2 And _
										component_index < (components.Length - 4) And _
										((component_index - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 3 And _
										component_index < (components.Length - 4) And _
										((component_index - 4) Mod 8) = 0 Then ' CHx: Sensor ID (label)
										
										'sheet1.PutString(XLAddress1, data_string)
										sheet1.Cell(Row0Based, Col0Based).SetValue(data_string)
									ElseIf component_index > 4 And _
										component_index < (components.Length - 4) And _
										((component_index - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 5 And _
										component_index < (components.Length - 4) And _
										((component_index - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 6 And _
										component_index < (components.Length - 4) And _
										((component_index - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 7 And _
										component_index < (components.Length - 4) And _
										((component_index - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									End If
									'								End If
								End If
								
								If component_index = (components.Length - 3) Then ' Event Date
									If data_string <> "" Then
										'sheet1.PutFormula(XLAddress1, "=TEXT(" & Chr(34) & data_string & _
										'Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
										sheet1.Cell(Row0Based, Col0Based).SetFormulaA1("=TEXT(" & Chr(34) & data_string & _
											Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0")
										
										sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("dd/mm/yyyy")
										
										'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("dd/mm/yyyy")
										'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
									End If
								ElseIf component_index = (components.Length - 2) Then ' Event Time
									If data_string <> "" Then
										'Log("[XLS_File_Export] Event Time: " & data_string)
										Dim val_number As Double : val_number = Convert.ToDouble(data_string)
										'sheet1.PutNumber(XLAddress1, val_number)
										sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										
										sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("00:00:00")
										'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("00:00:00")
										'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
									End If
								ElseIf component_index = (components.Length - 1) Then ' Event Desc.
									If data_string <> "" Then
										Dim val_number As Double : val_number = Convert.ToDouble(data_string)
										'sheet1.PutNumber(XLAddress1, val_number)
										sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										
										If col_max < Col0Based Then
											col_max = Col0Based
										End If
									End If
								End If
								
							Else
								'sheet1.PutString(XLAddress1, data_string)
								'sheet1.Cell(Row0Based, Col0Based).SetValue(data_string) '1048576
								If data_string <> "" Then
									sheet1.Cell(Row0Based, Col0Based).SetValue(data_string) '1048576
								End If
							End If
							
							component_index = component_index + 1
							
							'							If component_index > 100 Then
							'								Exit For
							'							End If
							
							If lowRAMmemory Then
								'Exit
							End If
						Next
					End If
				End If
				
				LineCounter = LineCounter + 1
				
				updateProgressBar(LineCounter / TotalLineCounter)
				
				Application.DoEvents
				
				'Sleep(10)
				
				If lowRAMmemory Then
					'Exit
				End If
			Next
			
			If lowRAMmemory Then
				
			Else				
				updateProgressBar(0.2)
				
				Try
					'save the workbook
					Workbook1.SaveAs(SourceFileFolderSave & "\" & SourceFileNameSave) '& ".xlsx")
					
					updateProgressBar(1)
					
					MsgBox("Export finished.", , "File exported")
				Catch ex As SecurityException
					msgbox("User does not have permission to write files" & vbCrLf & vbCrLf & "SecurityException:" & ex.Message,,"OpenFile")
				Catch ex As Exception
					msgbox("File cannot be read (permission error)" & vbCrLf & vbCrLf & "Exception:" & ex.Message,,"OpenFile")
				End Try
			End If
			
		End If
		
		enable_buttons()
	End Sub
	
	Sub XLS_File_Export64()
		Dim ch_counter As Integer = 0
		Dim sensor_ID(8) As String
		If export_enable Then
			Dim Workbook1 As XLWorkbook = New XLWorkbook() 'XLWorkbookWriter = XL.CreateWriterBlank
			Dim sheet1 = Workbook1.Worksheets.Add("Sheet1") 'XLSheetWriter = Workbook.CreateSheetWriterByName("Sheet1")
			
			'Dim XL As XLUtils
			Dim components() As String '= new Array As String("")
			'Dim XLAddress1 As XLAddress
			Dim component_index As Integer = 0
			Dim LineCounter As Integer = 0
			
			
			'Dim TitleStyle As Workbook 'As XLStyle = Workbook.CreateStyle
			
			Dim buffer As String = ""
			Dim buff2 As String = ""
			
			'TitleStyle.ForegroundColor(XL.COLOR_GREY_80_PERCENT).FontBoldColor(12, XL.COLOR_WHITE).HorizontalAlignment("CENTER")
			
			'Dim n As Long = Convert.ToInt32(DateTime.Now.ToString())
			
			updateProgressBar(0)
			
			export_enable = False
			
			Dim col_max As Integer = 0
			
			'XL.Initialize()
			'XLAddress1.Initialize()
			
			'Log("[XLS_File_Export] lines.Size: " & lines.Count)
			
			For Each line As String In lines
				If (line <> "") Then
					components = line.Split(Chr(59)) 'Regex.Split("\t", line)
					
					'Log("[XLS_File_Export] Line " & LineCounter & ", components: " & components.Length)
					
					If (components.Length > 0) Then
						If (LineCounter > 1) Then
							If components(0).Length > 0 Then ' Index
								components(0) = (Convert.ToInt32(HexToInt(components(0))) + 1).ToString 
							End If
							
							For i = 1 To components.Length - 4 ' without event data					
								If ((i - 1) Mod 8) = 0 Then ' CHx: Date (0B1415) mmddyy
									If components(i).Length = 4 Then									
										buff2 = (base64to10(components(i).Substring(3, 1))).ToString ' day
										
										If buff2.Length = 1 Then
											buff2 = "0" & buff2
										End If
										
										buffer = buff2
										
										buff2 = (base64to10(components(i).Substring(2, 1))).ToString ' month
										
										If buff2.Length = 1 Then
											buff2 = "0" & buff2
										End If
										
										buffer = buffer & buff2
										
										If Asc(components(i).Substring(0, 1)) = Asc("A") Then
											buffer = buffer & "20" & base64to10(components(i).Substring(1, 1)) ' year
										Else
											buffer = buffer & "20" & base64to10(components(i).Substring(0, 2)) ' year
										End If
										
										components(i) = buffer
									End If
								ElseIf i > 1 And ((i - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3) (1017) hhmm
									If components(i).Length = 2 Then
										Dim hour As String = (base64to10(components(i).Substring(1, 1))).ToString
										Dim minute As String = (base64to10(components(i).Substring(0, 1))).ToString
										
										If hour.Length = 1 Then
											hour = "0" & hour
										End If
										
										If minute.Length = 1 Then
											minute = "0" & minute
										End If
										
										buffer = hour & minute & "00"
										
										components(i) = buffer
										
										'Log("1- CHx: Time " & components(i))
									End If
								ElseIf i > 2 And ((i - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
									Dim values_str() As String
									Dim values_byte(2) As Byte
									Dim value_float As Double 'Float
									
									values_str = components(i).Split(Chr(46)) 'Regex.Split("\.", components(i))
									
									If values_str.Length = 2 Then
										values_byte(0) = Convert.ToByte(base64to10(values_str(1).Trim))
										values_byte(1) = Convert.ToByte(base64to10(values_str(0).Trim)) 
										
										value_float = values_byte(0) * 0.0625
										value_float = value_float + values_byte(1)
										
										If rbtn_DegF.Checked Then
											value_float = (value_float * 1.8) + 32
										End If
										
										components(i) = value_float.ToString 
									End If
								Else If i > 3 And ((i - 4) Mod 8) = 0 Then ' CHx: Sensor ID (864866715576104)
									components(i) = (base64to10(components(i).Trim)).ToString
									Dim ID_bytes(8) As Integer
									'Dim result As Int64
									Dim divider As Int64
									Dim tmp_num As Int64 = Val(components(i))
									
									'If components(i).IsNumber = True Then
									For j = 1 To 7
										divider = (2 ^ (48 - ((j - 1) * 8)))
										'Log((2 ^ (48 - ((j - 1) * 8))).ToString)
										ID_bytes(j) = tmp_num \ divider
										
										
										'Log("tmp_num: " & tmp_num & " / divider: " & divider)
										'Log("Dec: " & ID_bytes(j))
										
										tmp_num = tmp_num - (ID_bytes(j) * divider)
										'Log("tmp_num: " & tmp_num)
									Next
									'End If
									
									components(i) = ""
									
									For j = 1 To 7
										'Log("Dec: " & ID_bytes(j))
										'Log("Hex: " & Hex(ID_bytes(j)))
										
										If Hex(ID_bytes(j)).Length = 2 Then
											components(i) = components(i) & Hex(ID_bytes(j))
										Else
											components(i) = components(i) & "0" & Hex(ID_bytes(j))
										End If
									Next
									
									'Log(" ")
									
									If ID_bytes(2) > 0 And ID_bytes(3) > 0 Then
										sensor_ID(ch_counter) = components(i)
									Else
										components(i) = sensor_ID(ch_counter)
									End If
								ElseIf i > 4 And ((i - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
									'If components(i).Length = 2 Then
									components(i) = base64to10(components(i).Trim).ToString 
									components(i) = (Convert.ToInt32(components(i)) - 127).ToString 
									'End If
								ElseIf i > 5 And ((i - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
									'If components(i).Length = 2 Then
									components(i) = base64to10(components(i).Trim).ToString 
									components(i) = (Convert.ToInt32(components(i)) - 127).ToString
									'End If
								ElseIf i > 6 And ((i - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
									'If components(i).Length = 2 Then
									Dim batt_f As Double : batt_f = base64to10(components(i).Trim)
									batt_f = batt_f * 0.004
									batt_f = batt_f + 3.5
									components(i) = batt_f.ToString 
									
									If components(i).Length > 6 Then
										components(i) = components(i).Substring(0, components(i).IndexOf(".") + 4)
									End If
									'End If
								ElseIf i > 7 And ((i - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
									'If components(i).Length = 2 Then
									Dim charg_f As Double : charg_f = base64to10(components(i).Trim)
									charg_f = charg_f * 0.1
									charg_f = charg_f + 7.0
									components(i) = charg_f.ToString 
									
									If components(i).Length > 6 Then
										components(i) = components(i).Substring(0, components(i).IndexOf(".") + 4)
									End If
									'End If
									ch_counter = ch_counter + 1
								End If
								'							End If
								
							Next
							
							For i = components.Length - 4 To components.Length - 2 ' event data
								'Log("[event data]")
								If i = (components.Length - 4) Then ' Event Date
									'Log("Event Date")
									buffer = HexToInt(components(i).Substring(4)).ToString 
									buffer = buffer & HexToInt(components(i).Substring(2, 2))
									
									If Asc(components(i).Substring(0, 1)) = Asc("A") Then
										buffer = buffer & "20" & base64to10(components(i).Substring(1, 1)) ' year
									Else
										buffer = buffer & "20" & base64to10(components(i).Substring(0, 2)) ' year
									End If
									
									components(i) = buffer
								ElseIf i = (components.Length - 3) Then ' Event Time
									'Log("Event Time")
									'If components(i).Length = 4 Then
									Dim hour As String = base64to10(components(i).Substring(0, 1)).ToString 
									Dim minute As String = base64to10(components(i).Substring(1, 1)).ToString 
									
									If hour.Length = 1 Then
										hour = "0" & hour
									End If
									
									If minute.Length = 1 Then
										minute = "0" & minute
									End If
									
									buffer = hour & minute & "00"
									
									components(i) = buffer
									'Else
									'	Log("Event Time, components(i).Length <> 4")
									'End If
								ElseIf i = (components.Length - 2) Then ' Event Desc.
									components(i) = HexToInt(components(i).Trim).ToString 
									ch_counter = 0
								End If
							Next
						End If
						
						component_index = 0
						
						For Each data_string In components
							Dim Col0Based As Integer = component_index + 1
							Dim Row0Based As Integer = LineCounter + 1
							
							If Row0Based >= 1048576 Then
								MsgBox("Maximum line number reached: 1048576", , "Error")
								Return
							End If
							
							If LineCounter > 1 Then
								If component_index = 0 Then ' Index
									If data_string <> "" Then
										Dim val_number As Double : val_number = Convert.ToDouble(data_string)
										'sheet1.PutNumber(XLAddress1, val_number)
										sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
									End If
								Else
									Dim i As Integer = component_index
									'								If (cbxCh1.Checked And (i >= 1 And i <= 8)) Or _
									'									(cbxCh2.Checked And (i >= 9 And i <= 16)) Or _
									'									(cbxCh3.Checked And (i >= 17 And i <= 24)) Or _
									'									(cbxCh4.Checked And (i >= 25 And i <= 32)) Or _
									'									(cbxCh5.Checked And (i >= 33 And i <= 40)) Or _
									'									(cbxCh6.Checked And (i >= 41 And i <= 48)) Or _
									'									(cbxCh7.Checked And (i >= 49 And i <= 56)) Or _
									'									(cbxCh8.Checked And (i >= 57 And i <= 64)) Then
									If component_index > 0 And _
										component_index < (components.Length - 4) And _
										((component_index - 1) Mod 8) = 0 Then ' CHx: Date
										If data_string <> "" Then
											'sheet1.PutFormula(XLAddress1, "=TEXT(" & Chr(34) & data_string & _
											' Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
											'sheet1.Cell(Row0Based, Col0Based).SetValue("=TEXT(" & Chr(34) & data_string & _
											'	Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
											sheet1.Cell(Row0Based, Col0Based).SetFormulaA1("=TEXT(" & Chr(34) & data_string & _
												Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
											'sheet1.Cell(Row0Based, Col0Based).SetValue(data_string)
											'sheet1.Cell(Row0Based, Col0Based).Style.Numberformat.Format = "dd/mm/yyy"
											sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("dd/mm/yyyy")
											
											'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("dd/mm/yyyy")
											'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
										End If
									ElseIf component_index > 1 And _
										component_index < (components.Length - 4) And ((component_index - 2) Mod 8) = 0 Then ' CHx: Time (GMT-3)
										If data_string <> "" Then
											'Log("2- CHx: Time " & data_string)
											
											'Log("[XLS_File_Export] CHx: Time (GMT-3): " & data_string)
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
											
											sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("00:00:00")
											'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("00:00:00")
											'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
										End If
									ElseIf component_index > 2 And _
										component_index < (components.Length - 4) And _
										((component_index - 3) Mod 8) = 0 Then ' CHx: Temp. *C (label)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 3 And _
										component_index < (components.Length - 4) And _
										((component_index - 4) Mod 8) = 0 Then ' CHx: Sensor ID (label)
										
										'sheet1.PutString(XLAddress1, data_string)
										sheet1.Cell(Row0Based, Col0Based).SetValue(data_string)
									ElseIf component_index > 4 And _
										component_index < (components.Length - 4) And _
										((component_index - 5) Mod 8) = 0 Then ' CHx: ACC_x(*)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 5 And _
										component_index < (components.Length - 4) And _
										((component_index - 6) Mod 8) = 0 Then ' CHx: ACC_y(*)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 6 And _
										component_index < (components.Length - 4) And _
										((component_index - 7) Mod 8) = 0 Then ' CHx: Bat.(V)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									ElseIf component_index > 7 And _
										component_index < (components.Length - 4) And _
										((component_index - 8) Mod 8) = 0 Then ' CHx: Carreg.(V)
										
										If data_string <> "" Then
											Dim val_number As Double : val_number = Convert.ToDouble(data_string)
											'sheet1.PutNumber(XLAddress1, val_number)
											sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										End If
									End If
									'								End If
								End If
								
								If component_index = (components.Length - 4) Then ' Event Date
									If data_string <> "" Then
										'sheet1.PutFormula(XLAddress1, "=TEXT(" & Chr(34) & data_string & _
										'Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0") ' 34:"
										sheet1.Cell(Row0Based, Col0Based).SetFormulaA1("=TEXT(" & Chr(34) & data_string & _
											Chr(34) & ", " & Chr(34) & "00-00-0000" & Chr(34) & ")+0")
										
										sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("dd/mm/yyyy")
										
										'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("dd/mm/yyyy")
										'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
									End If
								ElseIf component_index = (components.Length - 3) Then ' Event Time
									If data_string <> "" Then
										'Log("[XLS_File_Export] Event Time: " & data_string)
										Dim val_number As Double : val_number = Convert.ToDouble(data_string)
										'sheet1.PutNumber(XLAddress1, val_number)
										sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										
										sheet1.Cell(Row0Based, Col0Based).Style.NumberFormat.SetFormat("00:00:00")
										'Dim TimeStyle As XLStyle = Workbook.CreateStyle.DataFormat("00:00:00")
										'sheet1.SetStyles(sheet1.LastAccessed, Array(TimeStyle))
									End If
								ElseIf component_index = (components.Length - 2) Then ' Event Desc.
									If data_string <> "" Then
										Dim val_number As Double : val_number = Convert.ToDouble(data_string)
										'sheet1.PutNumber(XLAddress1, val_number)
										sheet1.Cell(Row0Based, Col0Based).SetValue(val_number)
										
										If col_max < Col0Based Then
											col_max = Col0Based
										End If
									End If
								End If
								
							Else
								'sheet1.PutString(XLAddress1, data_string)
								'sheet1.Cell(Row0Based, Col0Based).SetValue(data_string) '1048576
								If data_string <> "" Then
									sheet1.Cell(Row0Based, Col0Based).SetValue(data_string) '1048576
								End If
							End If
							
							component_index = component_index + 1
							
							'							If component_index > 100 Then
							'								Exit For
							'							End If
							
							If lowRAMmemory Then
								'Exit
							End If
						Next
					End If
				End If
				
				LineCounter = LineCounter + 1
				
				updateProgressBar(LineCounter / TotalLineCounter)
				
				Application.DoEvents
				
				'Sleep(10)
				
				If lowRAMmemory Then
					'Exit
				End If
			Next
			
			If lowRAMmemory Then
				
			Else				
				updateProgressBar(0.2)
				
				Try
					'save the workbook
					Workbook1.SaveAs(SourceFileFolderSave & "\" & SourceFileNameSave) '& ".xlsx")
					
					updateProgressBar(1)
					
					MsgBox("Export finished.", , "File exported")
				Catch ex As SecurityException
					msgbox("User does not have permission to write files" & vbCrLf & vbCrLf & "SecurityException:" & ex.Message,,"OpenFile")
				Catch ex As Exception
					msgbox("File cannot be read (permission error)" & vbCrLf & vbCrLf & "Exception:" & ex.Message,,"OpenFile")
				End Try
			End If
			
		End If
		
		enable_buttons()
	End Sub
	
	Sub AboutToolStripMenuItem1Click(sender As Object, e As EventArgs)
		msgbox("Datalogger_2039 File Converter (*.dat)" & vbCrLf & "To Spreadsheet Editor (*.csv or *.xls)" & vbCrLf & vbCrLf _
			& "by Rtek1000 - 2022" & vbCrLf & "            Written in SharpDevelop v4.4.1", , "About")
		
	End Sub
	
	Public function getAvailableRAM() As String
		Dim ComputerInfo1 As New ComputerInfo()
		Return "Free RAM: " & (ComputerInfo1.AvailablePhysicalMemory / (1024 * 1024 * 1024)).ToString("F1") & " GB"
	End function
	
End Class
