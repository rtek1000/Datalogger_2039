﻿'
' Created by SharpDevelop.
' User: UserZ
' Date: 09/05/2022
' Time: 19:53
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
		Me.cbxCh8 = New System.Windows.Forms.CheckBox()
		Me.cbxCh7 = New System.Windows.Forms.CheckBox()
		Me.cbxCh4 = New System.Windows.Forms.CheckBox()
		Me.cbxCh3 = New System.Windows.Forms.CheckBox()
		Me.cbxCh6 = New System.Windows.Forms.CheckBox()
		Me.cbxCh5 = New System.Windows.Forms.CheckBox()
		Me.cbxCh2 = New System.Windows.Forms.CheckBox()
		Me.cbxCh1 = New System.Windows.Forms.CheckBox()
		Me.label10 = New System.Windows.Forms.Label()
		Me.panel4 = New System.Windows.Forms.Panel()
		Me.pictureBox1 = New System.Windows.Forms.PictureBox()
		Me.panel3 = New System.Windows.Forms.Panel()
		Me.rbtn_FileXLS = New System.Windows.Forms.RadioButton()
		Me.rbtn_FileCSV = New System.Windows.Forms.RadioButton()
		Me.label8 = New System.Windows.Forms.Label()
		Me.panel2 = New System.Windows.Forms.Panel()
		Me.rbtn_Dot = New System.Windows.Forms.RadioButton()
		Me.rbtn_Comma = New System.Windows.Forms.RadioButton()
		Me.label7 = New System.Windows.Forms.Label()
		Me.panel1 = New System.Windows.Forms.Panel()
		Me.rbtn_DegF = New System.Windows.Forms.RadioButton()
		Me.rbtn_DegC = New System.Windows.Forms.RadioButton()
		Me.label6 = New System.Windows.Forms.Label()
		Me.label5 = New System.Windows.Forms.Label()
		Me.cbbx_date1 = New System.Windows.Forms.ComboBox()
		Me.txtfMemID = New System.Windows.Forms.TextBox()
		Me.label4 = New System.Windows.Forms.Label()
		Me.txtfUcID = New System.Windows.Forms.TextBox()
		Me.label3 = New System.Windows.Forms.Label()
		Me.btnGen = New System.Windows.Forms.Button()
		Me.btnLoad = New System.Windows.Forms.Button()
		Me.label9 = New System.Windows.Forms.Label()
		Me.txtfVersion = New System.Windows.Forms.TextBox()
		Me.label12 = New System.Windows.Forms.Label()
		Me.txtfLines = New System.Windows.Forms.TextBox()
		Me.label1 = New System.Windows.Forms.Label()
		Me.panel5 = New System.Windows.Forms.Panel()
		Me.panel6 = New System.Windows.Forms.Panel()
		Me.progressBar1 = New System.Windows.Forms.ProgressBar()
		Me.label2 = New System.Windows.Forms.Label()
		Me.menuStrip1 = New System.Windows.Forms.MenuStrip()
		Me.menuToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.loadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.generateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.exitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.aboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.languageToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.englishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.spanishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.portugueseBrToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.aboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.statusStrip1 = New System.Windows.Forms.StatusStrip()
		Me.toolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
		Me.button2 = New System.Windows.Forms.Button()
		Me.cbxSaveDefault = New System.Windows.Forms.CheckBox()
		Me.timer1 = New System.Windows.Forms.Timer(Me.components)
		Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
		Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
		Me.timer2 = New System.Windows.Forms.Timer(Me.components)
		Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
		Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.timer3 = New System.Windows.Forms.Timer(Me.components)
		CType(Me.pictureBox1,System.ComponentModel.ISupportInitialize).BeginInit
		Me.panel3.SuspendLayout
		Me.panel2.SuspendLayout
		Me.panel1.SuspendLayout
		Me.menuStrip1.SuspendLayout
		Me.statusStrip1.SuspendLayout
		Me.SuspendLayout
		'
		'cbxCh8
		'
		Me.cbxCh8.Location = New System.Drawing.Point(280, 385)
		Me.cbxCh8.Name = "cbxCh8"
		Me.cbxCh8.Size = New System.Drawing.Size(37, 20)
		Me.cbxCh8.TabIndex = 70
		Me.cbxCh8.Text = "8"
		Me.toolTip1.SetToolTip(Me.cbxCh8, "Not implemented")
		Me.cbxCh8.UseVisualStyleBackColor = true
		'
		'cbxCh7
		'
		Me.cbxCh7.Location = New System.Drawing.Point(198, 385)
		Me.cbxCh7.Name = "cbxCh7"
		Me.cbxCh7.Size = New System.Drawing.Size(42, 20)
		Me.cbxCh7.TabIndex = 69
		Me.cbxCh7.Text = "7"
		Me.toolTip1.SetToolTip(Me.cbxCh7, "Not implemented")
		Me.cbxCh7.UseVisualStyleBackColor = true
		'
		'cbxCh4
		'
		Me.cbxCh4.Location = New System.Drawing.Point(280, 359)
		Me.cbxCh4.Name = "cbxCh4"
		Me.cbxCh4.Size = New System.Drawing.Size(37, 20)
		Me.cbxCh4.TabIndex = 68
		Me.cbxCh4.Text = "4"
		Me.toolTip1.SetToolTip(Me.cbxCh4, "Not implemented")
		Me.cbxCh4.UseVisualStyleBackColor = true
		'
		'cbxCh3
		'
		Me.cbxCh3.Location = New System.Drawing.Point(198, 359)
		Me.cbxCh3.Name = "cbxCh3"
		Me.cbxCh3.Size = New System.Drawing.Size(42, 20)
		Me.cbxCh3.TabIndex = 67
		Me.cbxCh3.Text = "3"
		Me.toolTip1.SetToolTip(Me.cbxCh3, "Not implemented")
		Me.cbxCh3.UseVisualStyleBackColor = true
		'
		'cbxCh6
		'
		Me.cbxCh6.Location = New System.Drawing.Point(116, 385)
		Me.cbxCh6.Name = "cbxCh6"
		Me.cbxCh6.Size = New System.Drawing.Size(44, 20)
		Me.cbxCh6.TabIndex = 66
		Me.cbxCh6.Text = "6"
		Me.toolTip1.SetToolTip(Me.cbxCh6, "Not implemented")
		Me.cbxCh6.UseVisualStyleBackColor = true
		'
		'cbxCh5
		'
		Me.cbxCh5.Location = New System.Drawing.Point(34, 385)
		Me.cbxCh5.Name = "cbxCh5"
		Me.cbxCh5.Size = New System.Drawing.Size(41, 20)
		Me.cbxCh5.TabIndex = 65
		Me.cbxCh5.Text = "5"
		Me.toolTip1.SetToolTip(Me.cbxCh5, "Not implemented")
		Me.cbxCh5.UseVisualStyleBackColor = true
		'
		'cbxCh2
		'
		Me.cbxCh2.Location = New System.Drawing.Point(116, 359)
		Me.cbxCh2.Name = "cbxCh2"
		Me.cbxCh2.Size = New System.Drawing.Size(44, 20)
		Me.cbxCh2.TabIndex = 64
		Me.cbxCh2.Text = "2"
		Me.toolTip1.SetToolTip(Me.cbxCh2, "Not implemented")
		Me.cbxCh2.UseVisualStyleBackColor = true
		'
		'cbxCh1
		'
		Me.cbxCh1.Location = New System.Drawing.Point(34, 359)
		Me.cbxCh1.Name = "cbxCh1"
		Me.cbxCh1.Size = New System.Drawing.Size(41, 20)
		Me.cbxCh1.TabIndex = 63
		Me.cbxCh1.Text = "1"
		Me.toolTip1.SetToolTip(Me.cbxCh1, "Not implemented")
		Me.cbxCh1.UseVisualStyleBackColor = true
		'
		'label10
		'
		Me.label10.Location = New System.Drawing.Point(11, 339)
		Me.label10.Name = "label10"
		Me.label10.Size = New System.Drawing.Size(67, 17)
		Me.label10.TabIndex = 62
		Me.label10.Text = "Channels:"
		'
		'panel4
		'
		Me.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.panel4.Location = New System.Drawing.Point(349, 39)
		Me.panel4.Name = "panel4"
		Me.panel4.Size = New System.Drawing.Size(2, 380)
		Me.panel4.TabIndex = 61
		'
		'pictureBox1
		'
		Me.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.pictureBox1.InitialImage = Nothing
		Me.pictureBox1.Location = New System.Drawing.Point(14, 76)
		Me.pictureBox1.Name = "pictureBox1"
		Me.pictureBox1.Size = New System.Drawing.Size(320, 240)
		Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.pictureBox1.TabIndex = 60
		Me.pictureBox1.TabStop = false
		Me.toolTip1.SetToolTip(Me.pictureBox1, "Screenshot made in Datalogger 2039")
		'
		'panel3
		'
		Me.panel3.Controls.Add(Me.rbtn_FileXLS)
		Me.panel3.Controls.Add(Me.rbtn_FileCSV)
		Me.panel3.Controls.Add(Me.label8)
		Me.panel3.Location = New System.Drawing.Point(589, 76)
		Me.panel3.Name = "panel3"
		Me.panel3.Size = New System.Drawing.Size(64, 74)
		Me.panel3.TabIndex = 98
		'
		'rbtn_FileXLS
		'
		Me.rbtn_FileXLS.Location = New System.Drawing.Point(3, 48)
		Me.rbtn_FileXLS.Name = "rbtn_FileXLS"
		Me.rbtn_FileXLS.Size = New System.Drawing.Size(51, 17)
		Me.rbtn_FileXLS.TabIndex = 45
		Me.rbtn_FileXLS.Text = "*.xlsx"
		Me.toolTip1.SetToolTip(Me.rbtn_FileXLS, "Spreadsheet file")
		Me.rbtn_FileXLS.UseVisualStyleBackColor = true
		AddHandler Me.rbtn_FileXLS.CheckedChanged, AddressOf Me.Rbtn_FileXLSCheckedChanged
		'
		'rbtn_FileCSV
		'
		Me.rbtn_FileCSV.Checked = true
		Me.rbtn_FileCSV.Location = New System.Drawing.Point(3, 25)
		Me.rbtn_FileCSV.Name = "rbtn_FileCSV"
		Me.rbtn_FileCSV.Size = New System.Drawing.Size(51, 17)
		Me.rbtn_FileCSV.TabIndex = 44
		Me.rbtn_FileCSV.TabStop = true
		Me.rbtn_FileCSV.Text = "*.csv"
		Me.toolTip1.SetToolTip(Me.rbtn_FileCSV, "Plain text file")
		Me.rbtn_FileCSV.UseVisualStyleBackColor = true
		'
		'label8
		'
		Me.label8.Location = New System.Drawing.Point(3, 2)
		Me.label8.Name = "label8"
		Me.label8.Size = New System.Drawing.Size(58, 20)
		Me.label8.TabIndex = 43
		Me.label8.Text = "File type:"
		'
		'panel2
		'
		Me.panel2.Controls.Add(Me.rbtn_Dot)
		Me.panel2.Controls.Add(Me.rbtn_Comma)
		Me.panel2.Controls.Add(Me.label7)
		Me.panel2.Location = New System.Drawing.Point(515, 76)
		Me.panel2.Name = "panel2"
		Me.panel2.Size = New System.Drawing.Size(64, 74)
		Me.panel2.TabIndex = 97
		'
		'rbtn_Dot
		'
		Me.rbtn_Dot.Location = New System.Drawing.Point(3, 48)
		Me.rbtn_Dot.Name = "rbtn_Dot"
		Me.rbtn_Dot.Size = New System.Drawing.Size(51, 17)
		Me.rbtn_Dot.TabIndex = 45
		Me.rbtn_Dot.Text = "0.00"
		Me.toolTip1.SetToolTip(Me.rbtn_Dot, "Decimal separator: dot (0.0)")
		Me.rbtn_Dot.UseVisualStyleBackColor = true
		'
		'rbtn_Comma
		'
		Me.rbtn_Comma.Checked = true
		Me.rbtn_Comma.Location = New System.Drawing.Point(3, 25)
		Me.rbtn_Comma.Name = "rbtn_Comma"
		Me.rbtn_Comma.Size = New System.Drawing.Size(51, 17)
		Me.rbtn_Comma.TabIndex = 44
		Me.rbtn_Comma.TabStop = true
		Me.rbtn_Comma.Text = "0,00"
		Me.toolTip1.SetToolTip(Me.rbtn_Comma, "Decimal separator: comma (0,0)")
		Me.rbtn_Comma.UseVisualStyleBackColor = true
		'
		'label7
		'
		Me.label7.Location = New System.Drawing.Point(3, 2)
		Me.label7.Name = "label7"
		Me.label7.Size = New System.Drawing.Size(58, 20)
		Me.label7.TabIndex = 43
		Me.label7.Text = "Separator:"
		'
		'panel1
		'
		Me.panel1.Controls.Add(Me.rbtn_DegF)
		Me.panel1.Controls.Add(Me.rbtn_DegC)
		Me.panel1.Controls.Add(Me.label6)
		Me.panel1.Location = New System.Drawing.Point(438, 76)
		Me.panel1.Name = "panel1"
		Me.panel1.Size = New System.Drawing.Size(67, 74)
		Me.panel1.TabIndex = 96
		'
		'rbtn_DegF
		'
		Me.rbtn_DegF.Location = New System.Drawing.Point(3, 48)
		Me.rbtn_DegF.Name = "rbtn_DegF"
		Me.rbtn_DegF.Size = New System.Drawing.Size(51, 17)
		Me.rbtn_DegF.TabIndex = 45
		Me.rbtn_DegF.TabStop = true
		Me.rbtn_DegF.Text = "°F"
		Me.toolTip1.SetToolTip(Me.rbtn_DegF, "Degrees Fahrenheit")
		Me.rbtn_DegF.UseVisualStyleBackColor = true
		'
		'rbtn_DegC
		'
		Me.rbtn_DegC.Checked = true
		Me.rbtn_DegC.Location = New System.Drawing.Point(3, 25)
		Me.rbtn_DegC.Name = "rbtn_DegC"
		Me.rbtn_DegC.Size = New System.Drawing.Size(51, 17)
		Me.rbtn_DegC.TabIndex = 44
		Me.rbtn_DegC.TabStop = true
		Me.rbtn_DegC.Text = "°C"
		Me.toolTip1.SetToolTip(Me.rbtn_DegC, "Degrees Celsius")
		Me.rbtn_DegC.UseVisualStyleBackColor = true
		'
		'label6
		'
		Me.label6.Location = New System.Drawing.Point(3, 2)
		Me.label6.Name = "label6"
		Me.label6.Size = New System.Drawing.Size(61, 20)
		Me.label6.TabIndex = 43
		Me.label6.Text = "Temp unit:"
		'
		'label5
		'
		Me.label5.Location = New System.Drawing.Point(365, 52)
		Me.label5.Name = "label5"
		Me.label5.Size = New System.Drawing.Size(67, 17)
		Me.label5.TabIndex = 95
		Me.label5.Text = "Date format:"
		'
		'cbbx_date1
		'
		Me.cbbx_date1.FormattingEnabled = true
		Me.cbbx_date1.Location = New System.Drawing.Point(438, 49)
		Me.cbbx_date1.Name = "cbbx_date1"
		Me.cbbx_date1.Size = New System.Drawing.Size(215, 21)
		Me.cbbx_date1.TabIndex = 94
		AddHandler Me.cbbx_date1.SelectedIndexChanged, AddressOf Me.Cbbx_date1SelectedIndexChanged
		'
		'txtfMemID
		'
		Me.txtfMemID.Location = New System.Drawing.Point(439, 260)
		Me.txtfMemID.Name = "txtfMemID"
		Me.txtfMemID.Size = New System.Drawing.Size(215, 20)
		Me.txtfMemID.TabIndex = 82
		Me.toolTip1.SetToolTip(Me.txtfMemID, "Memory IC identifier")
		'
		'label4
		'
		Me.label4.Location = New System.Drawing.Point(365, 263)
		Me.label4.Name = "label4"
		Me.label4.Size = New System.Drawing.Size(48, 20)
		Me.label4.TabIndex = 81
		Me.label4.Text = "Mem ID:"
		'
		'txtfUcID
		'
		Me.txtfUcID.Location = New System.Drawing.Point(439, 234)
		Me.txtfUcID.Name = "txtfUcID"
		Me.txtfUcID.Size = New System.Drawing.Size(215, 20)
		Me.txtfUcID.TabIndex = 80
		Me.toolTip1.SetToolTip(Me.txtfUcID, "IC MCU Identifier")
		'
		'label3
		'
		Me.label3.Location = New System.Drawing.Point(365, 237)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(48, 20)
		Me.label3.TabIndex = 79
		Me.label3.Text = "uC UID:"
		'
		'btnGen
		'
		Me.btnGen.Enabled = false
		Me.btnGen.Location = New System.Drawing.Point(561, 375)
		Me.btnGen.Name = "btnGen"
		Me.btnGen.Size = New System.Drawing.Size(94, 36)
		Me.btnGen.TabIndex = 74
		Me.btnGen.Text = "Generate"
		Me.btnGen.UseVisualStyleBackColor = true
		AddHandler Me.btnGen.Click, AddressOf Me.BtnGenClick
		'
		'btnLoad
		'
		Me.btnLoad.Location = New System.Drawing.Point(439, 375)
		Me.btnLoad.Name = "btnLoad"
		Me.btnLoad.Size = New System.Drawing.Size(94, 35)
		Me.btnLoad.TabIndex = 73
		Me.btnLoad.Text = "Load"
		Me.btnLoad.UseVisualStyleBackColor = true
		AddHandler Me.btnLoad.Click, AddressOf Me.BtnLoadClick
		'
		'label9
		'
		Me.label9.Location = New System.Drawing.Point(12, 52)
		Me.label9.Name = "label9"
		Me.label9.Size = New System.Drawing.Size(319, 17)
		Me.label9.TabIndex = 99
		Me.label9.Text = "Chart (Demonstration):"
		AddHandler Me.label9.Click, AddressOf Me.Label9Click
		'
		'txtfVersion
		'
		Me.txtfVersion.Location = New System.Drawing.Point(439, 208)
		Me.txtfVersion.Name = "txtfVersion"
		Me.txtfVersion.Size = New System.Drawing.Size(215, 20)
		Me.txtfVersion.TabIndex = 102
		Me.toolTip1.SetToolTip(Me.txtfVersion, "Datalogger 2039 formware version")
		'
		'label12
		'
		Me.label12.Location = New System.Drawing.Point(366, 211)
		Me.label12.Name = "label12"
		Me.label12.Size = New System.Drawing.Size(67, 20)
		Me.label12.TabIndex = 101
		Me.label12.Text = "Version:"
		'
		'txtfLines
		'
		Me.txtfLines.Location = New System.Drawing.Point(439, 286)
		Me.txtfLines.Name = "txtfLines"
		Me.txtfLines.Size = New System.Drawing.Size(215, 20)
		Me.txtfLines.TabIndex = 104
		'
		'label1
		'
		Me.label1.Location = New System.Drawing.Point(365, 289)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(48, 20)
		Me.label1.TabIndex = 103
		Me.label1.Text = "Lines:"
		'
		'panel5
		'
		Me.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.panel5.Location = New System.Drawing.Point(363, 195)
		Me.panel5.Name = "panel5"
		Me.panel5.Size = New System.Drawing.Size(310, 2)
		Me.panel5.TabIndex = 105
		'
		'panel6
		'
		Me.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.panel6.Location = New System.Drawing.Point(366, 321)
		Me.panel6.Name = "panel6"
		Me.panel6.Size = New System.Drawing.Size(310, 2)
		Me.panel6.TabIndex = 106
		'
		'progressBar1
		'
		Me.progressBar1.Location = New System.Drawing.Point(439, 339)
		Me.progressBar1.Name = "progressBar1"
		Me.progressBar1.Size = New System.Drawing.Size(214, 20)
		Me.progressBar1.TabIndex = 107
		'
		'label2
		'
		Me.label2.Location = New System.Drawing.Point(366, 339)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(57, 20)
		Me.label2.TabIndex = 108
		Me.label2.Text = "Progress:"
		'
		'menuStrip1
		'
		Me.menuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuToolStripMenuItem1, Me.aboutToolStripMenuItem})
		Me.menuStrip1.Location = New System.Drawing.Point(0, 0)
		Me.menuStrip1.Name = "menuStrip1"
		Me.menuStrip1.Size = New System.Drawing.Size(691, 24)
		Me.menuStrip1.TabIndex = 109
		Me.menuStrip1.Text = "menuStrip1"
		'
		'menuToolStripMenuItem1
		'
		Me.menuToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.loadToolStripMenuItem, Me.generateToolStripMenuItem, Me.exitToolStripMenuItem})
		Me.menuToolStripMenuItem1.Name = "menuToolStripMenuItem1"
		Me.menuToolStripMenuItem1.Size = New System.Drawing.Size(35, 20)
		Me.menuToolStripMenuItem1.Text = "File"
		AddHandler Me.menuToolStripMenuItem1.Click, AddressOf Me.MenuToolStripMenuItem1Click
		'
		'loadToolStripMenuItem
		'
		Me.loadToolStripMenuItem.Name = "loadToolStripMenuItem"
		Me.loadToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
		Me.loadToolStripMenuItem.Text = "Load"
		AddHandler Me.loadToolStripMenuItem.Click, AddressOf Me.LoadToolStripMenuItemClick
		'
		'generateToolStripMenuItem
		'
		Me.generateToolStripMenuItem.Name = "generateToolStripMenuItem"
		Me.generateToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
		Me.generateToolStripMenuItem.Text = "Generate"
		AddHandler Me.generateToolStripMenuItem.Click, AddressOf Me.GenerateToolStripMenuItemClick
		'
		'exitToolStripMenuItem
		'
		Me.exitToolStripMenuItem.Name = "exitToolStripMenuItem"
		Me.exitToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
		Me.exitToolStripMenuItem.Text = "Exit"
		AddHandler Me.exitToolStripMenuItem.Click, AddressOf Me.ExitToolStripMenuItemClick
		'
		'aboutToolStripMenuItem
		'
		Me.aboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.languageToolStripMenuItem1, Me.aboutToolStripMenuItem1})
		Me.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem"
		Me.aboutToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
		Me.aboutToolStripMenuItem.Text = "Help"
		AddHandler Me.aboutToolStripMenuItem.Click, AddressOf Me.AboutToolStripMenuItemClick
		'
		'languageToolStripMenuItem1
		'
		Me.languageToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.englishToolStripMenuItem, Me.spanishToolStripMenuItem, Me.portugueseBrToolStripMenuItem})
		Me.languageToolStripMenuItem1.Name = "languageToolStripMenuItem1"
		Me.languageToolStripMenuItem1.Size = New System.Drawing.Size(121, 22)
		Me.languageToolStripMenuItem1.Text = "Language"
		AddHandler Me.languageToolStripMenuItem1.Click, AddressOf Me.LanguageToolStripMenuItem1Click
		'
		'englishToolStripMenuItem
		'
		Me.englishToolStripMenuItem.Name = "englishToolStripMenuItem"
		Me.englishToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
		Me.englishToolStripMenuItem.Text = "[EN] English"
		AddHandler Me.englishToolStripMenuItem.Click, AddressOf Me.EnglishToolStripMenuItemClick
		'
		'spanishToolStripMenuItem
		'
		Me.spanishToolStripMenuItem.Name = "spanishToolStripMenuItem"
		Me.spanishToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
		Me.spanishToolStripMenuItem.Text = "[ES] Spanish"
		AddHandler Me.spanishToolStripMenuItem.Click, AddressOf Me.SpanishToolStripMenuItemClick
		'
		'portugueseBrToolStripMenuItem
		'
		Me.portugueseBrToolStripMenuItem.Name = "portugueseBrToolStripMenuItem"
		Me.portugueseBrToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
		Me.portugueseBrToolStripMenuItem.Text = "[PT-BR] Portuguese"
		AddHandler Me.portugueseBrToolStripMenuItem.Click, AddressOf Me.PortugueseBrToolStripMenuItemClick
		'
		'aboutToolStripMenuItem1
		'
		Me.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1"
		Me.aboutToolStripMenuItem1.Size = New System.Drawing.Size(121, 22)
		Me.aboutToolStripMenuItem1.Text = "About"
		AddHandler Me.aboutToolStripMenuItem1.Click, AddressOf Me.AboutToolStripMenuItem1Click
		'
		'statusStrip1
		'
		Me.statusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripStatusLabel1})
		Me.statusStrip1.Location = New System.Drawing.Point(0, 422)
		Me.statusStrip1.Name = "statusStrip1"
		Me.statusStrip1.Size = New System.Drawing.Size(691, 22)
		Me.statusStrip1.TabIndex = 110
		Me.statusStrip1.Text = "statusStrip1"
		'
		'toolStripStatusLabel1
		'
		Me.toolStripStatusLabel1.Name = "toolStripStatusLabel1"
		Me.toolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
		'
		'button2
		'
		Me.button2.Location = New System.Drawing.Point(561, 156)
		Me.button2.Name = "button2"
		Me.button2.Size = New System.Drawing.Size(92, 22)
		Me.button2.TabIndex = 111
		Me.button2.Text = "Save settings"
		Me.button2.UseVisualStyleBackColor = true
		AddHandler Me.button2.Click, AddressOf Me.Button2Click
		'
		'cbxSaveDefault
		'
		Me.cbxSaveDefault.Location = New System.Drawing.Point(366, 158)
		Me.cbxSaveDefault.Name = "cbxSaveDefault"
		Me.cbxSaveDefault.Size = New System.Drawing.Size(68, 21)
		Me.cbxSaveDefault.TabIndex = 112
		Me.cbxSaveDefault.Text = "Default"
		Me.toolTip1.SetToolTip(Me.cbxSaveDefault, "Not implemented")
		Me.cbxSaveDefault.UseVisualStyleBackColor = true
		'
		'timer1
		'
		Me.timer1.Enabled = true
		Me.timer1.Interval = 250
		AddHandler Me.timer1.Tick, AddressOf Me.Timer1Tick
		'
		'openFileDialog1
		'
		Me.openFileDialog1.FileName = "openFileDialog1"
		'
		'timer2
		'
		Me.timer2.Enabled = true
		AddHandler Me.timer2.Tick, AddressOf Me.Timer2Tick
		'
		'imageList1
		'
		Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"),System.Windows.Forms.ImageListStreamer)
		Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
		Me.imageList1.Images.SetKeyName(0, "2023.06.26_05.19.46.bmp")
		Me.imageList1.Images.SetKeyName(1, "2023.06.26_05.24.07.bmp")
		Me.imageList1.Images.SetKeyName(2, "2023.06.26_05.09.31.bmp")
		'
		'timer3
		'
		Me.timer3.Interval = 250
		AddHandler Me.timer3.Tick, AddressOf Me.Timer3Tick
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(691, 444)
		Me.Controls.Add(Me.cbxSaveDefault)
		Me.Controls.Add(Me.button2)
		Me.Controls.Add(Me.statusStrip1)
		Me.Controls.Add(Me.label2)
		Me.Controls.Add(Me.progressBar1)
		Me.Controls.Add(Me.panel6)
		Me.Controls.Add(Me.panel5)
		Me.Controls.Add(Me.txtfLines)
		Me.Controls.Add(Me.label1)
		Me.Controls.Add(Me.txtfVersion)
		Me.Controls.Add(Me.label12)
		Me.Controls.Add(Me.label9)
		Me.Controls.Add(Me.panel3)
		Me.Controls.Add(Me.panel2)
		Me.Controls.Add(Me.panel1)
		Me.Controls.Add(Me.label5)
		Me.Controls.Add(Me.cbbx_date1)
		Me.Controls.Add(Me.txtfMemID)
		Me.Controls.Add(Me.label4)
		Me.Controls.Add(Me.txtfUcID)
		Me.Controls.Add(Me.label3)
		Me.Controls.Add(Me.btnGen)
		Me.Controls.Add(Me.btnLoad)
		Me.Controls.Add(Me.cbxCh8)
		Me.Controls.Add(Me.cbxCh7)
		Me.Controls.Add(Me.cbxCh4)
		Me.Controls.Add(Me.cbxCh3)
		Me.Controls.Add(Me.cbxCh6)
		Me.Controls.Add(Me.cbxCh5)
		Me.Controls.Add(Me.cbxCh2)
		Me.Controls.Add(Me.cbxCh1)
		Me.Controls.Add(Me.label10)
		Me.Controls.Add(Me.panel4)
		Me.Controls.Add(Me.pictureBox1)
		Me.Controls.Add(Me.menuStrip1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.MainMenuStrip = Me.menuStrip1
		Me.MaximizeBox = false
		Me.MinimizeBox = false
		Me.Name = "MainForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		AddHandler Load, AddressOf Me.MainFormLoad
		CType(Me.pictureBox1,System.ComponentModel.ISupportInitialize).EndInit
		Me.panel3.ResumeLayout(false)
		Me.panel2.ResumeLayout(false)
		Me.panel1.ResumeLayout(false)
		Me.menuStrip1.ResumeLayout(false)
		Me.menuStrip1.PerformLayout
		Me.statusStrip1.ResumeLayout(false)
		Me.statusStrip1.PerformLayout
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private timer3 As System.Windows.Forms.Timer
	Private toolTip1 As System.Windows.Forms.ToolTip
	Private imageList1 As System.Windows.Forms.ImageList
	Private exitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private timer2 As System.Windows.Forms.Timer
	Private portugueseBrToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private spanishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private englishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private aboutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Private languageToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Private saveFileDialog1 As System.Windows.Forms.SaveFileDialog
	Private openFileDialog1 As System.Windows.Forms.OpenFileDialog
	Private timer1 As System.Windows.Forms.Timer
	Private toolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
	Private aboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private generateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private loadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private cbxSaveDefault As System.Windows.Forms.CheckBox
	Private menuToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Private button2 As System.Windows.Forms.Button
	Private statusStrip1 As System.Windows.Forms.StatusStrip
	Private menuStrip1 As System.Windows.Forms.MenuStrip
	Private label2 As System.Windows.Forms.Label
	Private progressBar1 As System.Windows.Forms.ProgressBar
	Private panel6 As System.Windows.Forms.Panel
	Private panel5 As System.Windows.Forms.Panel
	Private txtfLines As System.Windows.Forms.TextBox
	Private label12 As System.Windows.Forms.Label
	Private txtfVersion As System.Windows.Forms.TextBox
	Private label9 As System.Windows.Forms.Label
	Private btnLoad As System.Windows.Forms.Button
	Private btnGen As System.Windows.Forms.Button
	Private label1 As System.Windows.Forms.Label
	Private label3 As System.Windows.Forms.Label
	Private txtfUcID As System.Windows.Forms.TextBox
	Private label4 As System.Windows.Forms.Label
	Private txtfMemID As System.Windows.Forms.TextBox
	Private cbbx_date1 As System.Windows.Forms.ComboBox
	Private label5 As System.Windows.Forms.Label
	Private label6 As System.Windows.Forms.Label
	Private rbtn_DegC As System.Windows.Forms.RadioButton
	Private rbtn_DegF As System.Windows.Forms.RadioButton
	Private panel1 As System.Windows.Forms.Panel
	Private label7 As System.Windows.Forms.Label
	Private rbtn_Comma As System.Windows.Forms.RadioButton
	Private rbtn_Dot As System.Windows.Forms.RadioButton
	Private panel2 As System.Windows.Forms.Panel
	Private label8 As System.Windows.Forms.Label
	Private rbtn_FileCSV As System.Windows.Forms.RadioButton
	Private rbtn_FileXLS As System.Windows.Forms.RadioButton
	Private panel3 As System.Windows.Forms.Panel
	Private pictureBox1 As System.Windows.Forms.PictureBox
	Private panel4 As System.Windows.Forms.Panel
	Private label10 As System.Windows.Forms.Label
	Private cbxCh1 As System.Windows.Forms.CheckBox
	Private cbxCh2 As System.Windows.Forms.CheckBox
	Private cbxCh5 As System.Windows.Forms.CheckBox
	Private cbxCh6 As System.Windows.Forms.CheckBox
	Private cbxCh3 As System.Windows.Forms.CheckBox
	Private cbxCh4 As System.Windows.Forms.CheckBox
	Private cbxCh7 As System.Windows.Forms.CheckBox
	Private cbxCh8 As System.Windows.Forms.CheckBox

End Class
