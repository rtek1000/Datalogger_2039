/*
 * IWDG_Delay.c
 *
 *  Created on: Jun 21, 2021
 *      Author: r
 */
#include "main.h"
#include "IWDG_Delay.h"

extern IWDG_HandleTypeDef hiwdg;
extern uint8_t rtos_is_started;

void IWDG_reset(void) {
	/* Refresh IWDG: reload counter */
	if (HAL_IWDG_Refresh(&hiwdg) != HAL_OK) {
		/* Refresh Error */
		Error_Handler();
	}
}

void IWDG_delay_ms(uint32_t delay) {
	if(rtos_is_started == 0) {
		IWDG_reset();
		while (delay--) {
			IWDG_reset();
			HAL_Delay(1);
		}
	} else {
#if INCLUDE_vTaskDelay
	IWDG_osDelay(delay);
#else
	IWDG_reset();
	while (delay--) {
		IWDG_reset();
		HAL_Delay(1);
	}
#endif
	}

}

osStatus IWDG_osDelay(uint32_t millisec) {
	IWDG_reset();

#if INCLUDE_vTaskDelay
	TickType_t ticks = millisec / portTICK_PERIOD_MS;

	vTaskDelay(ticks ? ticks : 1); /* Minimum delay = 1 tick */

	return osOK;
#else
  (void) millisec;

  return osErrorResource;
#endif
}
