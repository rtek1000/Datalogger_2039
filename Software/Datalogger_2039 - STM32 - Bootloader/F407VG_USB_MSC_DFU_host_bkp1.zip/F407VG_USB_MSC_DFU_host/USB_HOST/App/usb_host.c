/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file            : usb_host.c
 * @version         : v1.0_Cube
 * @brief           : This file implements the USB Host
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under Ultimate Liberty license
 * SLA0044, the "License"; You may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 *                             www.st.com/SLA0044
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "usb_host.h"
#include "usbh_core.h"
#include "usbh_msc.h"

/* USER CODE BEGIN Includes */
#include "flash_if.h"
#include "fatfs.h"
#include "ff.h"
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
static void COMMAND_ProgramFlashMemory(void);
FATFS USBH_fatfs;
FIL MyFile;
FRESULT res;
uint32_t bytesWritten;
uint8_t rtext[200];
uint8_t wtext[] = "USB Host Library : Mass Storage Example";
uint8_t name[10]; //name of the file
uint16_t counter = 0;
uint32_t i = 0;
extern char USBHPath[]; /* USBH logical drive path */
//extern UART_HandleTypeDef huart3;
//uint8_t uart_tx_buffer[100];
//#define DOWNLOAD_FILENAME          "0:image.BIN"
#define DOWNLOAD_FILENAME          "0:DFU.bin"
FIL MyFileR; /* File object for download operation */
FILINFO MyFileInfo; /* File object information */
#define BUFFER_SIZE        ((uint16_t)512*64)
static uint32_t TmpReadSize = 0x00;
static uint32_t RamAddress = 0x00;
static __IO uint32_t LastPGAddress = APPLICATION_ADDRESS;
static uint8_t RAM_Buf[BUFFER_SIZE] = { 0x00 };

//FATFS USBDISKFatHs; /* File system object for USB disk logical drive */
//char USBDISKPath[4] = { 48, 58, 47, 0 }; /* USB Host logical drive path */

/* USER CODE END PV */

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USB Host core handle declaration */
USBH_HandleTypeDef hUsbHostHS;
ApplicationTypeDef Appli_state = APPLICATION_IDLE;

/*
 * -- Insert your variables declaration here --
 */
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*
 * user callback declaration
 */
static void USBH_UserProcess(USBH_HandleTypeDef *phost, uint8_t id);

/*
 * -- Insert your external function declaration here --
 */
/* USER CODE BEGIN 1 */
/*
 * user callback declaration
 */
static void USBH_UserProcess(USBH_HandleTypeDef *phost, uint8_t id);

/*
 * -- Insert your external function declaration here --
 */
/* USER CODE BEGIN 1 */
void userFunction(void) {
	if (Appli_state == APPLICATION_READY) {
		UsrLog("Press and release user button to start FW update");
		while (HAL_GPIO_ReadPin(BUTTON1_GPIO_Port, BUTTON1_Pin)
				== GPIO_PIN_RESET) {
		}
		while (HAL_GPIO_ReadPin(BUTTON1_GPIO_Port, BUTTON1_Pin)
				!= GPIO_PIN_RESET) {
		}

//		/* Register the file system object to the FatFs module */
//		if (f_mount(&USBDISKFatHs, (TCHAR const*) USBDISKPath, 0)
//				!= FR_OK) {
//			/* FatFs Initialization Error */
////			USB_Error_Handler(0);
//
//			UsrLog("FatFs Initialization Error");
//			return;
//		}

		/* Open the binary file to be downloaded */
		if (f_open(&MyFileR, DOWNLOAD_FILENAME, FA_READ) != FR_OK) {
			/*read size of binary file*/
			f_stat(DOWNLOAD_FILENAME, &MyFileInfo);
			/* The binary file is not available: Turn LED1, LED2 and LED4 On and Toggle
			 * LED3 in infinite loop */
			UsrLog("The binary file is not available");
			while (1) {
			}
		}
		if (MyFileInfo.fsize > USER_FLASH_SIZE) {
			/* No available Flash memory size for the binary file: Turn LED4 On and
			 * Toggle LED3 in infinite loop */
			UsrLog("No available Flash memory size for the binary file");
			while (1) {
			}
		}

		/* Download On Going: Turn LED4 On */
		UsrLog("Download On Going");
		// Begin T ODO 1 MSC_DFU_HOST_HANDS_ON: Erase the flash sector to download the image
//#warning "T ODO 1 MSC_DFU_HOST_HANDS_ON: Erase the flash sector to download the image"
		FLASH_If_FlashUnlock();
		if (FLASH_If_EraseSectors(APPLICATION_ADDRESS) != 0) {
			UsrLog("Erase failed");
			while (1)
				;
		}
		// End MSC_DFU_HOST_HANDS_ON: Erase the flash sector to download the image
		/* Program flash memory */
		COMMAND_ProgramFlashMemory();

		/* Download Done: Turn LED4 Off and LED2 On */
		UsrLog("Download Done");
		/* Close file */
		f_close(&MyFileR);
		UsrLog("Application going to be reset in 5 seconds");
		HAL_Delay(5000);
		NVIC_SystemReset();
	}
}

static void COMMAND_ProgramFlashMemory(void) {
	uint32_t programcounter = 0x00;
	uint8_t readflag = TRUE;
	uint16_t bytesread;

	/* RAM Address Initialization */
	RamAddress = (uint32_t) &RAM_Buf;
	/* Erase address init */
	LastPGAddress = APPLICATION_ADDRESS;
	/* While file still contain data */
	while ((readflag == TRUE)) {
		/* Read maximum 512 Kbyte from the selected file */
		f_read(&MyFileR, RAM_Buf, BUFFER_SIZE, (void*) &bytesread);

		/* Temp variable */
		TmpReadSize = bytesread;
		/* The read data < "BUFFER_SIZE" Kbyte */
		if (TmpReadSize < BUFFER_SIZE) {
			readflag = FALSE;
		}
		/* Program flash memory */
		for (programcounter = 0; programcounter < TmpReadSize; programcounter +=
				4) {
			// Begin T ODO 2 MSC_DFU_HOST_HANDS_ON: Write word from ram into flash memory
//#warning "T ODO 2 MSC_DFU_HOST_HANDS_ON: Write word into flash memory"
			if (FLASH_If_Write((LastPGAddress + programcounter),
					*(uint32_t*) (RamAddress + programcounter)) != 0) {
				//UsrLog("Flash write failed");
				while (1)
					;
			}

			// End MSC_DFU_HOST_HANDS_ON: Write word into flash memory

		}
		/* Update last programmed address value */
		LastPGAddress += TmpReadSize;
	}
}

/* USER CODE END 1 */

/**
  * Init USB host library, add supported class and start the library
  * @retval None
  */
void MX_USB_HOST_Init(void)
{
  /* USER CODE BEGIN USB_HOST_Init_PreTreatment */

  /* USER CODE END USB_HOST_Init_PreTreatment */

  /* Init host Library, add supported class and start the library. */
  if (USBH_Init(&hUsbHostHS, USBH_UserProcess, HOST_HS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_RegisterClass(&hUsbHostHS, USBH_MSC_CLASS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_Start(&hUsbHostHS) != USBH_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_HOST_Init_PostTreatment */

  /* USER CODE END USB_HOST_Init_PostTreatment */
}

/*
 * Background task
 */
void MX_USB_HOST_Process(void)
{
  /* USB Host Background task */
  USBH_Process(&hUsbHostHS);
}
/*
 * user callback definition
 */
static void USBH_UserProcess  (USBH_HandleTypeDef *phost, uint8_t id)
{
  /* USER CODE BEGIN CALL_BACK_1 */
	switch (id) {
	case HOST_USER_SELECT_CONFIGURATION:
		//UsrLog("application select configuration");
		break;

	case HOST_USER_DISCONNECTION:
		Appli_state = APPLICATION_DISCONNECT;
		//UsrLog("application disconnect");
		break;

	case HOST_USER_CLASS_ACTIVE:
		Appli_state = APPLICATION_READY;
		//UsrLog("application ready");

		if (f_mount(&USBH_fatfs, USBHPath, 0) != FR_OK) {
			//UsrLog("f_mount fail \n");
		}

		break;

	case HOST_USER_CONNECTION:
		Appli_state = APPLICATION_START;
		//UsrLog("application start");
		break;

	default:
		break;
	}
  /* USER CODE END CALL_BACK_1 */
}

/**
  * @}
  */

/**
  * @}
  */

